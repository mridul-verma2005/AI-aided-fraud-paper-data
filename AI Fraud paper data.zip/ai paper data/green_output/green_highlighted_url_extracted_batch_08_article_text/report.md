# Report: green_highlighted_url_extracted_batch_08_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 170 / 170 (none truncated or short; 8351 is navigation text only) |
| Articles removed | **18** (4 advisories/policy, 10 explainers/features/opinion, 3 not AI-related, 1 extraction failure) |
| **Records in incidents.json** | **136** (29 merged with earlier events; 5 articles split into two cases each: 8238, 8263, 8278, 8282, 8760) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 100 | AI-Confirmed-in-text 20 · AI-Suspected 72 · No-AI-Evidence 8 · AI-as-Lure 0 |
| AI Misinformation | 14 | Political Deepfake 11 · Issue-Based 2 · Hoax 1 |
| Public Panic / AI Harassment & Abuse | 0 / 0 | |
| Unverified Claims | 4 | |
| Out of Scope | 18 | 1 party content, 17 outside India |

Victims: 107 of 156 victim objects have a stated gender and 60 a stated age. The event registry now has 607 events (107 new). A cross-batch name check of the new events found no duplicates of earlier events.

**This batch is dominated by digital-arrest scams:** 69 Authority Impersonation records in AI-Suspected. None of these articles says AI was used. They are AI-Suspected only under the rule.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (100)
├─ AI-Confirmed-in-text (20)
│  ├─ Impersonation (19): Individual 19 · Organization 2 (voice clones: Powai son-in-Dubai, Lucknow judge-relative, Andheri US nephew, Jalgaon MLC fund attempt;
│  │    ads: Premanand Maharaj, BSE CEO deepfake ×4, Murthy/Ambani Bengaluru cases, CV Raman Nagar FM deepfake, Seema Haider voice calls; merged Sunil Mittal, Kartikeya, Canada nephew, Kohli betting…)
│  ├─ Commerce & Platform (6) · Financial (5): Investment 5 · Others (3) · Identity & Account (2)
│  └─ harms: FinancialLoss 12 · ReputationalHarm 7 · IdentityTheft 1 · Extortion 1
├─ AI-Suspected (72): Authority Impersonation 69 (digital arrests) · Sextortion 2 · Individual Impersonation 1 · Investment / Fake Platform 1 · Account Takeover 1
│    largest: Mumbai 86-year-old Rs 20 cr; Rohini engineer Rs 10 cr; Andheri Rs 8 cr; Ahmedabad doctor Rs 8 cr; Hyderabad Agarwal family Rs 5.5 cr; Kolkata Rs 4.4 cr;
│    SIMBOX syndicate (~Rs 100 cr, 7 arrested); Cambodia call-centre case (16 arrested)
├─ AI-as-Lure (0)
└─ No-AI-Evidence (8): KYC/APK bank frauds (Renu Viswanath Rs 47 lakh, Paytm 2020, Jamtara APK syndicate, Dhanbad SBI impersonators), Delhi CEO-WhatsApp frauds (Rs 7 cr),
     Manesar fake army order, DSP photo misuse, forged-signature company takeover
AI Misinformation (14)
├─ Political Deepfake (11): Kajol and Kumar Sanu suits, Amitabh AI-voice communal video, CDS Anil Chauhan, Col Sofia Qureshi, Roshni Nadar fake meeting,
│    + merged Suniel Shetty, Supriya Sule audio, Tharoor (T20 clip), Gambhir, Punjab CM Mann
├─ Issue-Based (2): Sora 'Bangladeshis will rule Bengal' video, Musk 'BJP-RSS Arunachal' deepfake
└─ Hoax (1): 'India gets UNSC veto' with deepfake Sudhir Chaudhary voice
Unverified Claims (4): Patiala SSP audio (police say AI), Instagram '25 August' Rs 500 reveal, + merged Mamata SIR-AI, Mann video (EV-0230)
Out of Scope (18): NCP's AI Ajit Pawar campaign clips; 17 outside India
```

## Merges by event_id (29)
- **Fraud (19):**
  - EV-0174 Indore deepfake kidnapping (8092, 8151) · EV-0358 Ambala forged-SC-order case (8152, 8153: SC hearings)
  - EV-0013 Kozhikode deepfake call (8190) · EV-0340 Changanassery doctor (8197) · EV-0446 Ankush Bahuguna (8125, 8274)
  - EV-0018 Sunil Mittal (4 articles) · EV-0455 Goa ED probe (8132) · EV-0255 Deshram (8256)
  - **EV-0007 Taneja couple (8101, 8105, 8110)**: 8101 (WSJ) is matched to Dr Indra Taneja; link to check
  - EV-0109 Canada nephew (8386, 8448) · EV-0177 Bharti Singh (8359) · EV-0050 Kerala ADGP (8435) · EV-0014 Kartikeya (8455)
  - EV-0064 Quantum AI / Sudha Murty (8449) · EV-0188 Kurukshetra Bal Krishna (8531) · EV-0047 Babydoll Archi (8667)
  - EV-0207 Kohli betting deepfake (8294) · EV-0005 Rs 58 cr chargesheet (9048) · EV-0450 Operation Chakra V (9019)
- **Misinformation (5):** EV-0476 Suniel Shetty (7945) · EV-0208 Sule/Patole audio (8366) · EV-0278 Tharoor (8356, 8520) · EV-0055 Gambhir (8421) · EV-0293 Mann deepfake (8691)
- **Unverified (2):** EV-0314 Mamata (8445) · EV-0230 Mann video (8418: the Akal Takht says the video is authentic, Mann says AI/actor)
- **Out of Scope (3):** EV-0142 Arup $25 m (8174, 8347, 8764) · EV-0239 Jay Shooster (8388) · EV-0326 Rubio (8420)

## Splits (5 articles → 10 records)
- **8238:** Lalapet pastor (Rs 22.8 lakh) / Punjagutta doctor (Rs 12 lakh)
- **8263:** Mokila businessman (Rs 1.82 cr) / Somajiguda 74-year-old (Rs 39.3 lakh)
- **8278:** Raj Nagar woman (Rs 45 lakh) / Saidabad professor (Rs 15 lakh)
- **8282:** Bachupally engineer (Rs 1.33 cr) / Secunderabad 78-year-old (Rs 46 lakh)
- **8760:** Banashankari woman (Murthy deepfake) / second victim (Ambani deepfake)

Each pair is two separate police cases reported in one article.

## Unverified Claims (4)
- **INC-117 (8246):** Punjab Police call a SAD-released audio clip of Patiala SSP Varun Sharma AI-generated; SAD says it is real; the SEC ordered a probe.
- **INC-118 (8201):** an Instagram page allegedly collected Rs 500 each from about 1.66 lakh people for a 'reveal' that was an AI motivational video. These are social-media claims only.
- INC-115 Mamata and INC-116 Mann video: merged.

## Out of Scope (18)
- **Party content (1):** 8412, NCP's AI voice/video of the late Ajit Pawar in ZP polls.
- **Outside India (17):**
  - Anthropic Claude test breach (7923 + 7934), Meta AI agent (7949), Mythos access (8013)
  - BBC AI-CSAM trade (8086), China deepfake calls (8123), Zelensky deepfake (8149)
  - Wall Street AI vishing (8326), Biden robocall (8353), 2019 UK CEO audio deepfake (8466)
  - US father $3,000 attempt (8493), Darktrace CEO (8742), Musk YouTube crypto (8749), WPP CEO (8752), Buffett (8759)
  - Merged: Arup, Jay Shooster, Rubio

## Removed (18)
- Advisories/policy (4): 8096, 8133, 8372, 8782
- Explainers/features/opinion without a qualifying case (10): 8100, 8107, 8229, 8300, 8336, 8350, 8376, 8419, 8751, 8758
- Not AI-related (3): 7928 (Aland voter deletions), 8438 (AP liquor scam), 8221 (Philippine bait-link fact check; AI only in the headline)
- Extraction failure (1): 8351

## Ambiguous cases
1. **Digital arrests dominate (69 records, 51% of this file).** None of them mentions AI. They follow the AI-Suspected rule, but their volume now skews the fraud tree. See the proposal below.
2. **EV-0007 / 8101:** the WSJ story's "77-year-old retired paediatrician, Rs 13 crore, fake judge" fits Dr Indra Taneja (Rs 14.85 cr) but isn't named. Merged as a link to check.
3. **Prevented or recovered cases** (Vuyyuru 8113, Bareilly 8239/8298, Miyapur 8281, Thrissur 8198) are attempt_only = true. Neredmet (8287) and the MP's wife (8203) lost money that was later frozen or recovered, so they are recorded as losses with a note.
4. **8322 Ghatkopar:** the headline says "deepfake-style video calls" but the text doesn't say AI, so it stays AI-Suspected.
5. **8283 Hyderabad WhatsApp takeover:** "maybe AI voice" in the article, so AI-Suspected.
6. **Seema Haider voice calls (8503):** a thinly sourced 2023 report with no police case. Kept as AI-Confirmed because the text says AI voice.

## Proposed new second-level categories
Carried over (not yet decided): Lottery / Prize Fraud, Virtual Kidnapping, Tax / GST Fraud, AI-Assisted Cyber Intrusion, Personality-rights court-action flag.

Declined in review: the proposed separate digital-arrest sub-bucket or flag. Digital arrests stay in AI-Suspected per the existing rule, and no data was changed.
