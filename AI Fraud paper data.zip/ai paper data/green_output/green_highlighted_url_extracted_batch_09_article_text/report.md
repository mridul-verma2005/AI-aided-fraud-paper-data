# Report: green_highlighted_url_extracted_batch_09_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 24 / 24 (a small file; none truncated or short) |
| Articles removed | **0** |
| **Records in incidents.json** | **15** (3 merged with earlier events; 1 article split: 10551) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 15 | AI-Suspected 13 (all digital arrests) · No-AI-Evidence 2 |
| AI Misinformation / Public Panic / AI Harassment & Abuse / Unverified Claims / Out of Scope | 0 | |

Victims: 14 of 17 victim objects have a stated gender and 6 a stated age. The event registry now has 619 events (12 new). The cross-batch name check found no duplicates; three repeats were merged as shown below.

**None of the 24 articles says AI was used.** The file is almost entirely digital-arrest coverage.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (15)
├─ AI-Confirmed-in-text (0) · AI-as-Lure (0)
├─ AI-Suspected (13): Authority Impersonation 13 (digital arrests)
│    Belagavi Ajit Saraf Rs 15.45 cr (2 arrested) · Kollam 79-year-old Rs 3.72 cr · Navi Mumbai Rs 1.55 cr (SIM smuggler to Cambodia arrested) ·
│    Whitefield: 62-year-old Rs 39.4 lakh / 52-year-old woman Rs 60 lakh (split) · Goa Canacona Rs 42.6 lakh · Delhi retired Colonel Rs 15.5 lakh ·
│    Rohini case with Pakistan-linked kingpin Rs 15.3 lakh · Balussery Rs 20,000 · Himmatnagar attempt stopped by bank (feature) ·
│    + merged: Bengaluru Rs 24 cr (EV-0003), Bengaluru IT executive Rs 31.83 cr (EV-0089), Goa ED probe (EV-0455)
│  harms: FinancialLoss · Extortion
└─ No-AI-Evidence (2): fake 'Kerala CM loan scheme' WhatsApp scam; Om Birla impersonation (2022)
```

## Merges by event_id (3)
| Record | event_id | Batch 09 articles added |
|---|---|---|
| INC-001 Bengaluru retired teacher Rs 24 cr | EV-0003 | 10541, 10559, 10569 (names of the six arrested) |
| INC-002 Bengaluru IT executive Rs 31.83 cr | EV-0089 | 10599 |
| INC-003 Goa Rs 2.6 cr digital arrest / ED probe | EV-0455 | 11521, 11524, 11525, 11526, 11538, 11543 (Rs 17 cr seized, 400+ accounts frozen, two arrests) |

## Split
- **10551:** two Whitefield cases (a 62-year-old man, Rs 39.4 lakh; a 52-year-old woman, Rs 60 lakh).

## Removed
None.

## Ambiguous cases
1. **10545/10574:** headlined as a Karnataka bust, but the text says the case was handled by Delhi's Rohini cyber police and the fake officer posed as a Bengaluru SI. Location is recorded as Delhi, with the accused in Kannauj/Faridabad and the handler in Pakistan.
2. **11567:** an Indian Express feature on Gujarat losses. Its lead case (Himmatnagar, stopped by bank staff) is kept as an attempt under the feature rule; the article's state-wide figures are not recorded.

## Proposed new second-level categories
None new. Still open from earlier: Lottery / Prize Fraud, Virtual Kidnapping, Tax / GST Fraud, AI-Assisted Cyber Intrusion, Personality-rights court-action flag. The digital-arrest flag was declined.
