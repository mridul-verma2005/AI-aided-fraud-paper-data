# Report: green_highlighted_url_extracted_batch_15_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 166 / 166 (15744 has site boilerplate only) |
| Articles removed | **12** (6 statistics/trend reports, 2 explainers, 1 election-image analysis, 1 AI training-data story, 1 boilerplate page, 1 search-trend piece) |
| **Records in incidents.json** | **145** (36 merged with earlier events; 3 articles split into extra cases) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 131 | AI-Suspected 99 · No-AI-Evidence 28 · AI-Confirmed-in-text 3 · AI-as-Lure 1 |
| Out of Scope | 13 | 12 outside India (USA, UK, Australia ×2, Hong Kong, Philippines, China, Singapore, global) · 1 AI used by investigators |
| Unverified Claims | 1 | Sukesh Chandrashekhar's 'AI-cloned voice' claim (merged, EV-0407) |
| AI Misinformation / Public Panic / AI Harassment & Abuse | 0 | |

Victims: 143 of 172 victim objects have a stated gender and 77 a stated age. The event registry now has 1,136 events (109 new). The file is mostly digital arrests. The tail (IDs 16859 onward) is international AI-fraud coverage, coded Out of Scope or removed.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (131)
├─ AI-Confirmed-in-text (3): Faridabad AI voice clone of a friend (Rs 30,000) · + merged Lucknow AI 'uncle' voice (EV-0014) · Ambani 'stock forum' deepfake (EV-0201)
├─ AI-Suspected (99): Authority Impersonation 98 (digital arrests) · Authority Impersonation + Sextortion 1 (merged Borivali)
│    Largest new: Hyderabad Rs 10.61 cr · Girgaum 85-year-old Rs 9 cr · Rajasthan SOG gang Rs 6.25 cr · Nashik Rs 6 cr + Rs 72 lakh · Ahmedabad doctor Rs 4 cr ·
│    Goregaon couple ~Rs 4 cr · Mumbai 77-year-old Rs 3.8 cr · Mehdipatnam doctor couple Rs 3 cr · Dehradun teacher Rs 2.27 cr · Ghaziabad 84-year-old Rs 2.2 cr ·
│    Lucknow Canadian NRI sisters Rs 1.9 cr · Surat 72-year-old Rs 1.47 cr · Kothrud Rs 1.44 cr · Hyderabad scientist Rs 1.34 cr · Ahmedabad 'Chief Justice' Rs 1.26 cr ...
│    Deaths: Agra teacher Malti Verma (heart attack, fake 'daughter in sex racket' call)
│    Also: Jabalpur teen mimicking women IPS officers' voices (voice impersonation, AI not stated) · Bathinda fake 'Canadian police' call
│    + merged Mumbai Rs 58 cr (3 more articles; 7 arrested), Taneja couple (4), Gandhinagar Rs 19.24 cr (2), Delhi surgeon (2, total Rs 3.42 cr), Gurugram 'Anjali' Rs 5.85 cr (BBC), ...
├─ AI-as-Lure (1): + merged Pune university 'AI research funding' (EV-0990; Seetaiah Kilaru arrested)
└─ No-AI-Evidence (28): investment apps 8 (New Town Rs 21.6 cr, Mumbai ship captain Rs 11.16 cr, Hanumakonda Rs 1 cr, Noida 'Morgan Stanley', ...) · WhatsApp/Teams boss impersonation 2 ·
     romance/matrimony 3 · e-commerce/OLX 2 · fake call centres 2 (Siliguri card fraud; Goregaon 'Geek Squad' vs US citizens) · tantrik · insurance surrender · MBBS admission ·
     'pregnant job' · task fraud · fake BSF/CRPF callers 2 · bank-staff app fraud · Raja Singh 'Viksit Bharat' loan call · Jay Shah impersonation (attempt) · NEET proxy · 2015 hydro-project fraud
Unverified Claims (1): + merged Sukesh 'AI voice clone' claim (EV-0407)
Out of Scope (13): Profit Connect AI-crypto conviction (USA) · Philadelphia AI 'granddaughter' (merged EV-1027) · Metro Bank Claude-credit fraud (UK) · Andrew Mountbatten-Windsor AI images (UK) ·
     ASIC deepfake ads (Australia) · ATO impersonation 2018 (Australia, no AI) · Quantum AI Musk deepfake (Hong Kong) · Dubai-prince deepfake romance (Philippines) ·
     AI dating profiles (China) · AI-robot investment (Singapore) · AI seed listings and EvilTokens (global) · CBI's AI image search catching a fugitive (AI used by investigators)
```

## Merges by event_id (36)
- **EV-0839 Mumbai Rs 58 cr (3):** 16757, 16762, 16769 (7 arrested, Rs 3.5 cr frozen) · **EV-0007 Taneja couple (4):** 16667-16669, 16787
- EV-0113 Gandhinagar Rs 19.24 cr (16701, 16704) · EV-0945 Delhi 92-year-old surgeon (16647, 16658; total Rs 3.42 cr) · EV-0516 Rohini Rs 10 cr (16685, 16691) · EV-0529 MP Sudhakar's wife (16634, 16732)
- EV-0725 Thane Rs 4.2 cr (15688; victim Vinod Joshi) · EV-0508 Gwalior RK Ashram (15689; kingpin arrested) · **EV-0679 Beed Rs 23.4 lakh (15669; three Jalgaon arrests)**
- EV-0614 Munirka colonel (15785) · EV-0824 Hyderabad Rs 1.07 cr (15882) · EV-0990 Pune university (15895) · EV-0357 Bareilly scientist (15941)
- EV-0852 Delhi 71-year-old Rs 49 lakh (16650 part) · EV-0895 Malkajgiri Rs 53 lakh (16662) · EV-0782 Gurugram Rs 5.85 cr (16670) · EV-0105 Greater Kailash (16674)
- EV-0765 Borivali (16675) · EV-0944 Baliram (16676) · EV-0254 Pulwama firm charge sheet (16690) · EV-0089 Bengaluru Rs 31.83 cr (16718) · EV-0723 Juhu (16725; Rs 3.8 cr)
- EV-0613 Belagavi (16730) · EV-0736 JP Nagar (16741) · EV-0706 Pune octogenarian (16742) · EV-0090 Aurad ex-MLA (16739) · EV-0937 Neredmet judge (16799)
- EV-0753 Putta Sudhakar Yadav (16805) · EV-0446 Ankush Bahuguna (16817) · EV-0746 TV actress (16835) · EV-0792 Bhubaneswar Rs 1.38 cr (16845) · **EV-0520 Ahmedabad Paldi doctor (16696; Rs 8.05 cr)**
- AI/other: EV-0014 Lucknow AI voice (16922) · EV-0201 Ambani deepfake (16919) · EV-0407 Sukesh (16867) · EV-1027 Philadelphia (17035)

## New multi-article events
Ahmedabad builder Ketan Patel Rs 1.05 cr (16697, 16703) · Kothrud Rs 1.44 cr (16744, 16786) · Profit Connect (17080, 17081)

## Splits (3)
- **16758** Nashik: Anil Lalasare Rs 72 lakh · second senior citizen Rs 6 cr
- **16794** Mumbai: 77-year-old woman Rs 3.8 cr (digital arrest) · retired ship captain Rs 11.16 cr (investment, NOAI)
- **16650** Delhi: 71-year-old Rs 49 lakh (merged into EV-0852) · stationery shop owner Rs 39.5 lakh crypto (NOAI)

## Removed (12)
- Statistics/trends: 15958 (Uttarakhand), 16068 (Bihar), 16746 (Bhopal), 17046 (BBB), 17057 (AI identity-fraud searches), 17068 (INTERPOL Africa), 17090 (Australia small firms)
- Explainers/analysis: 16866 (McAfee voice-cloning), 16991 ('crying child' explainer), 16882 (Telangana election AI images, no specific case)
- Other: 16966 (AI training-data book sourcing, not fraud) · 15744 (boilerplate page)

## Ambiguous cases
1. **16780 Surat 72-year-old, Rs 1.47 cr, 28 days (new event):** this matches batch 13's **13127** (MHA cyber wing: 'a 72-year-old Gujarat man, Rs 1.47 crore, 28 days'), which I merged into EV-0110 (Vadodara, 18 days). 16780 shows the 13127 victim is in Surat, so **13127 should move from EV-0110 to this new event**. I haven't changed batch 13; say 'revise' if you want it moved.
2. **15669 → EV-0679 Beed:** the Rs 23.42 lakh Beed case with Jalgaon arrests matched to retired banker Suryakant Munde's Rs 23.4 lakh loss (batch 11).
3. **16696 → EV-0520:** the Ahmedabad Paldi doctor (Rs 8.05 crore) matched the batch 08 elderly Ahmedabad doctor tied to Jet Airways.
4. **16749 Jabalpur voice mimicry:** a human impersonating women IPS officers' voices; coded AI-Suspected per the voice-impersonation rule, though no AI was used.
5. **16849 Agra teacher death:** a fake 'police' call claiming her daughter was in a sex racket (no transfer); coded as a digital-arrest-type Authority Impersonation.
6. **17124 CBI AI image search:** AI was used by investigators, so Out of Scope rather than removed.
7. **16839 Goregaon call centre** targeted US citizens but is run from India, so it's in scope (No-AI-Evidence).

## Proposed new second-level categories
None new. Still open from earlier batches: Lottery / Prize Fraud, Virtual Kidnapping, Tax / GST Fraud, AI-Assisted Cyber Intrusion, Personality-rights court-action flag.
