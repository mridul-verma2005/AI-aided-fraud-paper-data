# Report: green_highlighted_url_extracted_batch_01_article_text.xlsx (rev 2)

## Revision 2 changes
- Three sibling top-level domains: **AI-Aided Fraud**, **AI Misinformation**, **Public Panic**. INC-046 (Jabalpur AI plane-crash hoax) moved from AI Misinformation to Public Panic. No case was deleted.
- **India filter**: 5 incidents (5 articles) left out of incidents.json; they are listed below. Incident IDs are kept stable, so there are gaps at 033, 036, 037, 038 and 051.
- **Victims** now have `gender` and `age`, filled only where the article states them (30 of 56 victim objects have a gender, 17 have an age). Age 73 for Radhakrishnan (INC-013) was removed because it appears only in removed article 197. The complainants in INC-021 and INC-023 were split out as their own victim objects so their stated details could be recorded.
- **Field order**: incident_domain → ai_bucket → scam_categories → fraud_types → ai_capabilities → harms, then the remaining fields as specified. For Misinformation and Panic records, ai_bucket, scam_categories and fraud_types are null and misinformation_type is filled.
- CLAUDE.md updated with the domains, India filter, victim rule, field order and the rev-1 taxonomy.

## Counts
| Item | Count |
|---|---|
| Rows / successful extractions | 147 / 147 |
| Advisory / non-incident articles removed | 72 (unchanged) |
| Incidents built | 51 |
| Excluded: outside India | 5 |
| **Incidents in incidents.json** | **46** (70 articles) |
| AI-Aided Fraud | 42: AI-Confirmed-in-text 20 · AI-Suspected 12 · No-AI-Evidence 6 · AI-as-Lure 4 |
| AI Misinformation | 3 (INC-047, 048, 049) |
| Public Panic | 1 (INC-046) |

## Excluded: outside India
| Article ID | Incident | Location |
|---|---|---|
| 13 | INC-033 OnlyFake AI fake-ID service | Online / global (404 Media report; no Indian link) |
| 925 | INC-036 OpenAI report: ChatGPT dating scam, fake law firms | Indonesia / USA |
| 886 | INC-037 AI orphan images charity scam ('Khmer Khmer') | Cambodia |
| 956 | INC-038 Nikki MacLeod deepfake romance scam | Edinburgh, Scotland, UK |
| 920 | INC-051 EY report with fabricated data/citations (AI Misinformation) | Canada (EY Canada) |

## Taxonomy tree (counts in this file)
```
AI-Aided Fraud (42)
├─ AI-Confirmed-in-text (20)
│  ├─ Financial Fraud (10): Investment 7 · Loan 2 · Banking & Payment 1
│  ├─ Identity & Account Fraud (5): Identity Theft 2 · Account Takeover 2 · Document & Credential Forgery 2
│  ├─ Commerce & Platform Fraud (3): Fake Platform 3
│  ├─ Relationship-Based Fraud (5): Romance 3 · Recruitment 2 · Sextortion 2 · Synthetic Persona Monetisation 1
│  ├─ Impersonation Fraud (15): Individual 11 · Authority 2 · Organization 1 · Examination / Recruitment-Integrity 1
│  ├─ ai_capabilities: voice cloning; deepfake video (liveness/eye-blink, face-swap call, public figures); AI avatars/personas; AI images; AI face morphing; LLM text/translation tooling; AI-assisted malware/app development; AI-generated fake documents
│  └─ harms: FinancialLoss 18 · Extortion 3 · IdentityFraudEnablement 3 · IdentityTheft 2 · ReputationalHarm 2 · HumanTrafficking 2
├─ AI-Suspected (12)
│  ├─ Impersonation Fraud (10): Authority 10 (digital arrests)
│  ├─ Identity & Account Fraud (2): Identity Theft 2
│  ├─ Financial Fraud (1): Banking & Payment 1
│  ├─ Relationship-Based Fraud (1): Recruitment 1
│  ├─ ai_capabilities: suspected face cloning / deepfake for liveness bypass
│  └─ harms: FinancialLoss 10 · Extortion 10 · IdentityTheft 2 · IdentityFraudEnablement 1
├─ AI-as-Lure (4)
│  ├─ Financial Fraud (4): Investment 4
│  ├─ Commerce & Platform Fraud (4): Fake Platform 3 · E-Commerce 1
│  ├─ Impersonation Fraud (2): Individual 1 · Organization 1
│  ├─ ai_capabilities: none (AI only claimed)
│  └─ harms: FinancialLoss 4
└─ No-AI-Evidence (6)
   ├─ Financial Fraud (3): Banking & Payment 1 · Insurance 1 · Charity / Donation 1
   ├─ Identity & Account Fraud (2): Identity Theft 1 · Document & Credential Forgery 1
   ├─ Relationship-Based Fraud (1): Romance 1
   ├─ Impersonation Fraud (1): Individual 1
   ├─ Others (1): Others 1 (tax fraud, INC-050)
   ├─ ai_capabilities: none
   └─ harms: FinancialLoss 6
AI Misinformation (3)   [ai_bucket / scam_categories / fraud_types = null]
├─ Political Deepfake / Manipulated Media of Public Figures (2): INC-047, INC-049
├─ Issue-Based Disinformation (1): INC-048
├─ ai_capabilities: AI-generated images; AI-generated video/images; deepfake voiceover/video
└─ harms: ReputationalHarm 3
Public Panic (1)
├─ Fabricated Event / Hoax (1): INC-046
├─ ai_capabilities: AI-generated video
└─ harms: none
```

## Ambiguous cases
1. **No-AI-Evidence bucket.** Your rev-2 note lists only three fraud buckets, but No-AI-Evidence was approved in rev 1, so I kept it (INC-040, 041, 042, 043, 045, 050) and wrote it into CLAUDE.md. Tell me if these should instead go to another bucket or domain.
2. **India test for cross-border cases.** I kept three incidents with an Indian party: INC-034 (Kerala man trafficked to a Myanmar scam compound), INC-035 (Cambodian scam centre recruiting Indians from India via ChatGPT-made flyers), and INC-039 (Indian medical student running an AI persona aimed at US men). Under a strict "where it happened" test, all three would be excluded.
3. **Gender from gendered words.** Gender was filled from explicit words in the text ("woman", "businessman", "he/his", "wife"), never from names. Kept null: Pradeep Singh (INC-032), Naidu (INC-049), PM Modi (INC-047, text missing), the Rohini couple (INC-008), and all group or organization victims. Non-numeric ages ("middle-aged", "in his 60s", "elderly") are recorded as null.
4. **Public Panic vs Misinformation.** Only INC-046 explicitly reports panic. INC-048 (Kancha Gachibowli) caused a public controversy but not alarm or unrest, so it stays in Misinformation.
5. Carried over: INC-044 (Purnia fingerprint cloning) is AI-Suspected only under the fake-IDs rule; the 10 digital arrests are AI-Suspected by rule only; INC-015 and 016 use hedged AI wording; INC-039 is borderline fraud; ID 924 is truncated and ID 429 failed extraction; some cases mentioned only in passing in removed articles are unrecorded (197, 422, 533, 960, 76, 129).

## Proposed new second-level categories
None. The only remaining "Others" fraud case is INC-050 (tax-evasion fraud, article 857); one case is not enough to justify a "Tax Fraud" category yet. Possible later: a "PublicPanic" harm for Public Panic records (article 139 currently has no harm).

## Post-review changes (batch 03 rev 1)
- Taxonomy migrated to v4 in incidents.json/taxonomy.json: Synthetic Persona Monetisation -> AI Persona Monetisation (Others); Examination / Recruitment-Integrity Fraud -> Exam Proxy Fraud; Charity / Donation Fraud is now its own category; INC-032 (IPL tickets, article 937) -> Counterfeit Ticket Fraud; PublicDeception added to INC-046 (no other harm).
- Every record has an event_id (registry: output_json/event_registry.json). Records whose event recurs in batch 03 point to the merged record there: INC-001, 003, 005, 007, 013, 023, 024, 027, 028, 031, 039, 048.
- Article 721 (listed above as removed) is restored under the specific-AI-ad rule and is part of the Quantum AI campaign record B03-INC-015 (EV-0064).
- Retrofitted (Out of Scope rule): the five non-India incidents are now Out of Scope records in incidents.json, filling the ID gaps: INC-033 (article 13), INC-036 (925), INC-037 (886), INC-038 (956), INC-051 (920). incidents.json now has 51 records.
