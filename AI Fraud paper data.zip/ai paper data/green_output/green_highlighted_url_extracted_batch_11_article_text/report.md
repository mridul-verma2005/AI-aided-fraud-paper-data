# Report: green_highlighted_url_extracted_batch_11_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 179 / 179 (12619 and 12681 have mostly unrelated page text; coded from title and summary line; 12780 is author-bio text, kept for its title) |
| Articles removed | **13** (4 advisories/statements, 8 explainers/statistics/policy, 1 not AI-related) |
| **Records in incidents.json** | **141** (29 merged with earlier events; 32 articles folded into 12 new multi-article events; 4 articles split into extra cases) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 128 | AI-Confirmed-in-text 3 · AI-Suspected 122 · No-AI-Evidence 3 · AI-as-Lure 0 |
| AI Misinformation | 9 | Political Deepfake / Manipulated Media of Public Figures 8 · Fabricated Event / Hoax 1 |
| Public Panic | 1 | Wayanad zipline AI video |
| Unverified Claims | 1 | Raipur 'AI-defaced flag' charge |
| Out of Scope | 2 | 1 outside India (Pakistan), 1 open party campaign content |
| AI Harassment & Abuse | 0 | |

Victims: 134 of 158 victim objects have a stated gender and 70 a stated age. The event registry now has 778 events (112 new). The batch is mostly digital arrests: 124 Authority Impersonation records, 9 of them attempts only (money saved by bank staff, family or neighbours).

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (128)
├─ AI-Confirmed-in-text (3)
│    Bhubaneswar CA Rs 1.5 cr (police: "sophisticated AI tools" showed fake courtrooms) ·
│    + merged SP Oswal fake CJI hearing (EV-0204, ED complaint) · 'Babydoll Archi' AI persona (EV-0047)
├─ AI-Suspected (122): Authority Impersonation 122 (digital arrests; 3 also Sextortion: Naranpura 27-year-old, Bengaluru 'medical exam', Borivali pharma employee)
│    Largest: Rs 1,500 cr Dubai racket (ED, 930 victims) · Mumbai mule bust (142 cases, Rs 114 cr) · Delhi Rs 23 cr (Cambodia) · Gujarat Rs 11.42 cr trust-account gang ·
│    Bengaluru techie Rs 11.83 cr · Pune 82-year-old Rs 10.75 cr · Ahilyanagar paediatrician Rs 7 cr · Hyderabad 81-year-old Rs 7.12 cr ·
│    JP Nagar Rs 4.8 cr (58 days) · Thane Rs 4.2 cr · Mumbai Rs 4 cr · Juhu Rs 3.84 cr · Col Bajwa Rs 3.4 cr · SC advocate Rs 3.29 cr · Kolkata Rs 3.26 cr ·
│    Mangaluru Leni Prabhu Rs 3.09 cr · Dehradun Rs 3 cr · Panchkula Rs 2.98 cr · ...
│    Deaths: Belagavi Nazareth couple (suicide) · Bescom worker (suicide) · Pune 82-year-old · Hyderabad retired doctor (heart attacks)
│    Attempts (6 new): Belthangady, Gurgaon Galleria (Rs 5.9 cr held), Howrah, Lucknow PNB, Maninagar neighbour, Hazratganj daughter
│    In scope though victims abroad: Cybits Solutions, Bengaluru (US/Canada victims, India-based perpetrators)
└─ No-AI-Evidence (3): Goa Pagi UPI debit · Goa Petkar phishing form · Khan Chacha mule account (Rs 3.3 cr)
AI Misinformation (9): PDF 8: Gaya (Nishant Kumar / Maithili Thakur), Odisha CM Majhi, Tripura CM, Yogi deepfake (UP STF),
     + merged Muzaffarpur PM/President (EV-0119), Tabu court action (EV-0387), Sabarimala/Pinarayi (EV-0398), Payal Dhare (EV-0289)
   · Hoax 1: Rishabh Pant AI drone video
Public Panic (1): Wayanad AI zipline accident video (creator arrested)
Unverified Claims (1): Arun Sahu 'AI-defaced national flag' (Raipur)
Out of Scope (2): Maryam Nawaz AI images (Pakistan, FIA) · Stalin AI Periyar video (party content, linked to EV-0485)
```

## Merges by event_id (29)
- **Fraud (25):**
  - EV-0003 Bengaluru Rs 24 cr (12719, 12720, 12823) · EV-0005 (12574, 12655, 12812) · EV-0007 (12582, 12666)
  - **EV-0455 (9 articles: 12599, 12600, 12602, 12605, 12618, 12627, 12628, 12629, 12630)**: ED arrests incl. Kerala man Rijas K
  - EV-0047 Babydoll Archi (12558) · EV-0089 (12708, 12831) · EV-0115 Mohali gangs (12643, Vitrag Shah bail denied)
  - EV-0204 SP Oswal (12782) · EV-0446 (12716) · EV-0450 Jhunjhunu Rs 7.67 cr (12795) · EV-0503 Jalgaon/Cambodia (12814)
  - EV-0508 (12617) · EV-0511 Ghaziabad mules (12565) · EV-0525 (12679) · EV-0528 (12853) · EV-0537 Bareilly (12606)
  - EV-0549 Ameerpet techie (12615) · EV-0553 Neredmet (12730, 12834) · EV-0557 (12768) · EV-0613 Belagavi (12841)
  - EV-0614 (12690) · EV-0615 Canacona (12632) · EV-0626 Kottayam/CBI (12610, 12631)
  - **EV-0637 (12595)**: identifies the victim as a 35-year-old senior NBCC official (Rs 55 lakh); amount and victim updated
  - EV-0640 (12657)
- **Misinformation (4):** EV-0119 Muzaffarpur (12559, 12562) · EV-0387 Tabu (12596) · EV-0398 Sabarimala (12726) · EV-0289 Payal Dhare (12775)

## New multi-article events (12)
Pune Rs 10.75 cr (12585, 12762, 12807) · Alaknanda Rs 1.4 cr (12578, 12763) · Dahisar retired I-T officer (12581, 12867) · Borivali stripping (12594, 12650) ·
Ahmedabad 17 held incl. 4 Taiwanese (12614, 12800) · Belagavi Nazareth couple (12620, 12718) · Col Bajwa (12625, 12802) · Hyderabad retired doctor (12760, 12848) ·
Odisha CM morphed images (12780, 12786) · IIT Delhi student (12801, 12805) · Pinjore Rs 80.09 lakh (12824, 12840) · Hyderabad 81-year-old Rs 7.12 cr (12835, 12839, 12845)

## Splits
- **12603** (Goa, six cases reported): D'Silva digital arrest Rs 5 lakh · Pagi UPI debit Rs 95,000 · Petkar phishing Rs 2 lakh (three detailed cases only)
- **12650** (Navi Mumbai): Borivali pharma employee (merged with 12594) · Nerul music therapist Rs 32 lakh · Koparkhairane 80-year-old Rs 22 lakh (Rs 12 lakh saved)
- **12683** (Lucknow): retired engineer Rs 1.18 cr (43 days) · LIC officer and wife Rs 12.9 lakh
- **12822** (Hyderabad): Nadergul 72-year-old Rs 5 lakh · Malkajgiri septuagenarian ~Rs 4 lakh

## Removed (13)
- Advisories/statements (4): 12827 Hyderabad police advisory, 12854 CP message to banks, 12855 officer interview, 12863 UP Police short film
- Explainers/statistics/policy (8): 12560 political metaphor, 12568 Bihar overview, 12613 Nagpur stats, 12678 anonymous feature, 12701 Scroll explainer, 12808 SC order (policy), 12828 Telangana stats, 12833 explainer
- Not AI-related (1): 12862 (misattributed real video)

## Ambiguous cases
1. **12742 Bhubaneswar CA:** AI-Confirmed only on a police officer's statement that callers used "sophisticated AI tools" to show fake courtrooms. Review note added.
2. **12643 → EV-0115:** the Rs 80 lakh Mohali victim is not named in batch 03; merged because Vitrag Shah is one of the six arrested in that gang bust.
3. **12604 Gurgaon e-SIM:** police call it the "largest" digital-arrest network; kept separate from EV-0515 (Gurgaon Rs 2.9 cr, 16 arrests) because the victim (Palam Vihar 75-year-old, Rs 17.8 lakh) and arrest count differ.
4. **12653 / 12830 / 12838 / 12822:** the caller alias 'Vijay Khanna' (also in EV-0005) recurs; it is a common script name, so not merged. Noted on 12653.
5. **12620/12718 Nazareth couple:** the suicide note says Rs 5 lakh; later reports say nearly Rs 60 lakh. Rs 60 lakh is used and the note records both.
6. **12852 Nagarjuna family:** no complaint and no loss; kept as a reported digital arrest with null amount.
7. **12619 and 12681:** page text is mostly unrelated; coded from the title only.
8. **12804 Cybits Solutions:** victims are in the US and Canada, but the perpetrators are in Bengaluru, so in scope.

## Proposed new second-level categories
None new. Still open from earlier batches: Lottery / Prize Fraud, Virtual Kidnapping, Tax / GST Fraud, AI-Assisted Cyber Intrusion, Personality-rights court-action flag.
