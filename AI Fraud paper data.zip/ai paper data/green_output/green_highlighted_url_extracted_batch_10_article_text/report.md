# Report: green_highlighted_url_extracted_batch_10_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 94 / 94 (none truncated or short; 11704 and 12268 have navigation or unrelated page text) |
| Articles removed | **17** (4 advisories/statements, 10 explainers/reports, 1 not AI-related, 2 extraction failures) |
| **Records in incidents.json** | **67** (20 merged with earlier events; article 12039 split into five cases) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 55 | AI-Confirmed-in-text 14 · AI-Suspected 32 · No-AI-Evidence 9 · AI-as-Lure 0 |
| AI Misinformation | 7 | Political Deepfake 7 |
| Out of Scope | 5 | all outside India |
| Public Panic / AI Harassment & Abuse / Unverified Claims | 0 | |

Victims: 60 of 83 victim objects have a stated gender and 20 a stated age. The event registry now has 666 events (46 new). The cross-batch name check caught one repeat, the Philippine 'Ghost File' scam, which is merged into EV-0242.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (55)
├─ AI-Confirmed-in-text (14)
│  ├─ Impersonation (14): Individual 13 · Organization 2 · Authority 1
│  │    Naidu deepfake audio job racket (Rs 12 lakh), Murmu Rs 21,000 deepfake ad (Jalahalli FIR), Rachana Ranade deepfake (Pune Rs 54 lakh, 5 held),
│  │    Modi/FM deepfake (Kondhwa veteran Rs 1 cr), FM deepfake (Bengaluru student Rs 3.5 lakh), Aviator deepfakes (Kothrud Rs 39.77 lakh),
│  │    Ghaziabad retired IPS sextortion with deepfake ADG (Rs 74,000), + merged Nora Fatehi, Sudha Murty, SpaceX/Pune, Kozhikode, Pune nurse, BSE CEO, Belagavi
│  ├─ Financial (9): Investment 9 · Commerce & Platform (7) · Relationship-Based (2): Recruitment 1 · Sextortion 1
│  └─ harms: FinancialLoss 11 · ReputationalHarm 4 · Extortion 1
├─ AI-Suspected (32): Authority Impersonation 31 (digital arrests) · Sextortion 1 (Madras HC 'morphed images' order)
│    Kolkata Rs 3.7 cr · Jayanagar couple Rs 3.17 cr · Bhubaneswar professor Rs 2.45 cr (Rs 1.1 cr recovered) · Pimpri Rs 2.14 cr · Kerala CBI charge sheet Rs 1.8 cr ·
│    Yamunanagar doctor Rs 1.42 cr · Kolar 90-year-old Rs 1.34 cr · Ratlam couple Rs 1.34 cr · Varanasi Rs 1.10 cr · Rae Bareli Rs 82.5 lakh · Dewas (12 held) ·
│    Rourkela Bishop · Kongad MLA (attempt) · Aligarh ex-mayor (no loss) · + merged Bengaluru Rs 24 cr, Belagavi Rs 15.45 cr, Neredmet, CBI AP-Telangana, Bareilly, Chandigarh Rs 2.5 cr
└─ No-AI-Evidence (9): WhatsApp MD/owner frauds (Rs 4.70 cr, Rs 1.90 cr, Rs 1 cr), fake Viral Bhayani site, fake Meghalaya DIG profile, Naidu Rs 22,000 'fake video'
     (AI not stated), Coimbatore trading-app and two Telegram task scams
AI Misinformation (7): Political Deepfake 7: Kajol 2023 dress-change deepfake, Sara Tendulkar deepfakes, + merged Rashmika, Aman Gupta, Sule/Patole audio, Akira Nandan (Kakinada arrest), Gambhir
Out of Scope (5): Australia six-fingered deepfake romance, China Baotou face swap, Meloni deepfake porn suit, + merged Hong Kong romance ring, Philippines 'Ghost File' (EV-0242)
```

## Merges by event_id (20)
- **Fraud (13):**
  - EV-0003 Bengaluru Rs 24 cr (11686, 11690, 12530) · EV-0613 Belagavi Saraf (11693) · EV-0553 Neredmet (12066)
  - EV-0069 Pune SpaceX deepfake (12247) · EV-0013 Kozhikode (12249) · EV-0359 CBI AP-Telangana (12259)
  - EV-0071 Nora Fatehi (12294) · EV-0064 Sudha Murty / Quantum AI (4 articles) · EV-0355 Pune nurse (12312)
  - EV-0569 BSE CEO deepfake (12317) · EV-0258 Belagavi Prakash Gubbi (12329) · EV-0537 Bareilly Tanmay (12527, 12557)
  - **EV-0522 Chandigarh Rs 2.5 cr (12556)**: names the victim as Sumit Kaur and gives 8 arrests; matched to the batch 08 'retired chief architect, 70' (link to check)
- **Misinformation (5):** EV-0224 Rashmika (5 articles) · EV-0297 Aman Gupta (12284) · EV-0208 Sule audio (12340) · EV-0473 Akira Nandan (12542) · EV-0055 Gambhir (12217, 12220)
- **Out of Scope (2):** EV-0242 Philippines 'Ghost File' (12241) · EV-0492 Hong Kong deepfake romance ring (12223)

## Split
**12039** (Coimbatore) is split into five cases:
- Singanallur digital arrest (Rs 19 lakh)
- Dr Rangaraj digital arrest (Rs 31.54 lakh)
- Vijaygopal trading apps (Rs 47.10 lakh)
- Mariammal Telegram task scam (Rs 6.89 lakh)
- Radha Bharathi Telegram task scam (Rs 10.52 lakh)

## Removed (17)
- Advisories/statements (4): 12096, 12319, 12264, 12265 (Rashmika named cyber-safety ambassador; removed as in B04)
- Explainers/reports (10): 12221, 12224, 12238, 12240, 12306, 12311, 12313, 12314, 12321, 12322
- Not AI-related (1): 12275 (Tanu Rawat clickbait; no AI stated)
- Extraction failure (2): 11704, 12268

## Ambiguous cases
1. **EV-0522:** batch 08 described a 70-year-old retired chief architect with seven accused denied bail; 12556 names Sumit Kaur with eight arrests. Same city, amount and modus. Merged, and her gender and age added.
2. **12263 Naidu Rs 22,000 video:** called a fake video made by distorting an interview, with no AI stated, so No-AI-Evidence.
3. **12341 Murmu Rs 21,000 deepfake (Nov 2025 FIR)** may be the same ad series as EV-0196 (Meta refused removal, Jan 2026). Linked, not merged.
4. **12115 Cyberabad weekly roundup:** one record (seven arrests); only the lead trading case is detailed.
5. **12533 Aligarh ex-mayor:** confined for three days, but no loss stated; amount is null.

## Proposed new second-level categories
None new. Still open from earlier batches: Lottery / Prize Fraud, Virtual Kidnapping, Tax / GST Fraud, AI-Assisted Cyber Intrusion, Personality-rights court-action flag.
