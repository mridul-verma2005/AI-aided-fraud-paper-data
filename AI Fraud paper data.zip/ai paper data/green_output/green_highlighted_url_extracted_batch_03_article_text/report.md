# Report: green_highlighted_url_extracted_batch_03_article_text.xlsx (rev 1)

## What changed in rev 1
1. **Specific-ad rule:** all 12 deepfake-ad fact-checks kept as AI-Aided Fraud; batch 01 article 721 restored under the same rule.
2. **event_id merging:** every record now has a global event_id (registry: `output_json/event_registry.json`, 144 events). The Quantum AI campaign is one record (18 articles). The 14 cross-batch duplicates are merged into one batch 03 record each, carrying the earlier-batch article IDs; the earlier records remain with the same event_id and a pointer note.
3. **Feature rule** applied: lead case names a victim/place with method and outcome. This also brought back 2301 (AI Misinformation), 2568 (Arup, Out of Scope) and 2589 (Baotou, Out of Scope), which had been removed as explainers.
4. **Political party AI videos** moved to Out of Scope.
5. **Unverified Claims** domain created for three allegations.
6. **Article 3108 split** into two records with separate event_ids.
7. **Taxonomy v4** applied, **PublicDeception** harm added, victim gender/age kept, field order per CLAUDE.md, non-India incidents kept as Out of Scope records.
8. Batches 01 and 02 got a light migration: event_ids, renamed types (Synthetic Persona Monetisation -> AI Persona Monetisation; Examination / Recruitment-Integrity Fraud -> Exam Proxy Fraud), recodes of the named articles (1914 -> Political Post / Ticket Fraud; Kerala AI camera 2028 -> Public-Works / Government Reporting Fraud; B01 IPL tickets 937 -> Counterfeit Ticket Fraud), and PublicDeception on misinformation/panic records with no harm. No records were added or deleted there.

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 166 / 166 |
| Advisory / non-incident articles removed | **28** (10 advisories/statements, 5 policy/judicial, 4 explainers, 9 reports) |
| Batch 03 articles in records | 138 (plus 15 earlier-batch articles in merged records, including 721) |
| **Records in incidents.json** | **96** |

| Top-level domain | Records | ai_bucket |
|---|---|---|
| AI-Aided Fraud | 68 | AI-Confirmed-in-text 47 · AI-Suspected 14 · No-AI-Evidence 4 · AI-as-Lure 3 |
| AI Misinformation | 9 | none |
| Public Panic | 0 | none |
| Unverified Claims | 3 | none |
| Out of Scope | 16 | none (13 outside India, 3 political party videos) + 1 not fraud = 16 |

Victims: 54 of 125 victim objects have a stated gender and 22 have a stated age.

## Taxonomy tree (v4, counts in this file)
```
AI-Aided Fraud (68)
├─ AI-Confirmed-in-text (47)
│  ├─ Financial Fraud (25): Investment 20 · Banking & Payment 2 · Loan 2 · Counterfeiting 1 · Insurance 0
│  ├─ Charity / Donation Fraud (0)
│  ├─ Identity & Account Fraud (9): Document & Credential Forgery 7 · Identity Theft 3 · Account Takeover 1 · Fake Identity Document Service 0
│  ├─ Commerce & Platform Fraud (16): Fake Platform 10 · E-Commerce 5 · Counterfeit Ticket 1
│  ├─ Relationship-Based Fraud (3): Romance 2 · Sextortion 1 · Recruitment 0 · Political Post / Ticket 0
│  ├─ Impersonation Fraud (35): Individual 29 · Authority 6 · Organization 4 · Exam Proxy 1
│  ├─ Others (3): AI Persona Monetisation 2 · Occult / Spiritual Healer 1
│  ├─ ai_capabilities: deepfake video / AI voice clones of public figures; voice cloning of relatives; AI-forged IDs,
│  │                    documents, passes and notes; eye-blink deepfakes; AI-edited QR codes; AI personas
│  └─ harms: FinancialLoss 30 · ReputationalHarm 17 · Extortion 5 · IdentityFraudEnablement 4 · IdentityTheft 2
├─ AI-Suspected (14): Authority Impersonation 14 (digital arrests) · Organization Impersonation 1
│  └─ harms: FinancialLoss 14 · Extortion 14
├─ AI-as-Lure (3): Investment 3 · Fake Platform 3
│  └─ harms: FinancialLoss 3
└─ No-AI-Evidence (4): Investment 1 · Fake Platform 1 · Recruitment 1 + Political Post / Ticket 1 · Individual 1 · Organization 1 · Public-Works / Government Reporting 1
   └─ harms: FinancialLoss 4
AI Misinformation (9)
├─ Issue-Based Disinformation (3): INC-069 Kancha Gachibowli (merged), 072 Dharmasthala YouTuber, 075 fake RSS video
├─ Political Deepfake / Manipulated Media (2): INC-070 Bratya Basu bribe video, 071 Muzaffarpur PM/President fakes
├─ Fabricated Event / Hoax (2): INC-073 fake 'occupancy tax' article, 074 AI image of Chinese troops
├─ AI-Fabricated Data / Citations (2): INC-076 GST order with AI case law, 077 SC: trial court relied on AI judgments
└─ harms: ReputationalHarm 6 · PublicDeception 3
Public Panic (0)
Unverified Claims (3): INC-078 'AI road' contractor, 079 Khandwa IAS award, 080 'AI Patna' video
Out of Scope (16): see below
```
Full v4 taxonomy (all categories, including types with no cases in this file) is in taxonomy.json and CLAUDE.md.

## Out of Scope
| Record | Article IDs | Location | Reason |
|---|---|---|---|
| INC-081 | 2439 | India (X) | Congress 'Modi selling tea' AI video: party satire/campaign content |
| INC-082 | 2963, 2960, 2964 | Bihar | Bihar Congress AI video of PM Modi's mother: party satire/campaign content |
| INC-083 | 2966 | Bihar | Bihar BJP 'Gangs of Ghotalaabaz' AI song: party campaign content |
| INC-084 | 2438, 2691 | China / USA | Outside India: Gemini-built phishing kits ('Outsider Enterprise') |
| INC-085 | 2440 | USA | Outside India: Chris Colocousis $400k catfishing |
| INC-086 | 2450 | USA | Outside India: iLearning fake-revenue fraud |
| INC-087 | 2485 | Canada | Outside India: Mark Carney deepfake crypto scam |
| INC-088 | 2505 | USA | Outside India: AI-song streaming royalty fraud |
| INC-089 | 2578 | Pakistan / South Asia | Outside India: AI bait clips leading to phishing |
| INC-090 | 2865 | Wales, UK | Outside India: AI-fronted fake jewellery shop |
| INC-091 | 2868, 2869 | UK | Outside India: AI-faked 'family-run' boutiques |
| INC-092 | 2875 | Guernsey | Outside India: chief-minister deepfake ad |
| INC-093 | 2880 | France | Outside India: fake Brad Pitt romance scam |
| INC-094 | 2568 | Hong Kong | Outside India: Arup $25M deepfake video meeting (kept by feature rule) |
| INC-095 | 2589 | China | Outside India: Baotou 4.3M yuan face-swap call (kept by feature rule) |
| INC-096 | 2444 | India | Not fraud: Reddit criticism of 'AI Fiesta' app |

## Unverified Claims
| Record | Article | Claim | Why unverified |
|---|---|---|---|
| INC-078 | 2682 | Contractor used an AI image of a paved road to get a bill approved | Only a viral Instagram video; no official statement, names, location or proof of payment |
| INC-079 | 2893 | Khandwa officers used AI images to win the National Water Award | Allegation by Dainik Bhaskar and MP Congress; both officers deny; no inquiry finding |
| INC-080 | 2956 | BJP posted an AI-generated 'developed Patna' video | Partisan Congress/TMC claim about a deleted post; no independent forensic check |

## Merges by event_id
| Record | event_id | Articles merged | Earlier record(s) |
|---|---|---|---|
| INC-015 Quantum AI deepfake-ad campaign | EV-0064 | 2317, 2427, 2463, 2527, 2478, 2488, 2537, 2495, 2515, 2533, 2580, 2584, 2654, 2794, 2497, 2716, 2837, **721** (B01) | none (721 had been removed in B01) |
| INC-001 Ahmedabad Aadhaar deepfake racket | EV-0001 | 3138, 3103, 2916, 2951, 2952 + 5, 3, 16, 68, 113, 758, 761, 777 | B01-INC-001 |
| INC-002 Kerala Rs 40k deepfake call | EV-0013 | 2574, 2784, 3131 + 314, 316, 293 | B01-INC-013 |
| INC-003 Trump Hotel Rental app | EV-0023 | 2526, 2524, 2754, 2764 + 523 | B01-INC-023 |
| INC-004 Hyderabad police summon Meta | EV-0027 | 2484 + 744 | B01-INC-027 |
| INC-005 Ankur Warikoo deepfakes | EV-0028 | 2742 + 400 | B01-INC-028 |
| INC-006 IBPS exam proxy gang | EV-0031 | 2684 + 413, 649 | B01-INC-031 |
| INC-007 Hyderabad doctor Rs 20 lakh | EV-0024 | 2840 + 727 | B01-INC-024 |
| INC-008 'Emily Hart' AI persona | EV-0035 | 2708 + 965, 968, 1004 | B01-INC-039, B02-INC-008 |
| INC-009 'Babydoll Archi' | EV-0047 | 2947, 2944, 2950 + 1643, 1714 | B02-INC-001 |
| INC-010 Kerala AI camera allegation | EV-0054 | 2569 + 2028 | B02-INC-010 |
| INC-011 Bengaluru Rs 24 cr digital arrest | EV-0003 | 2763, 2756 + 431, 32 | B01-INC-003 |
| INC-012 Delhi GK couple Rs 14.8 cr | EV-0007 | 2733 + 865, 469 | B01-INC-007 |
| INC-013 Rs 58 cr digital arrest | EV-0005 | 2822 + 150 | B01-INC-005 |
| INC-069 Kancha Gachibowli AI content | EV-0044 | 2346, 2363 + 739 | B01-INC-048 |

Also linked by event_id in the migration (not in this file): B01-INC-016 = B02-INC-007 (EV-0016, Hyderabad voice clone).

## Article 3108 split
| Record | event_id | Case |
|---|---|---|
| INC-063 | EV-0112 | Retired St Xavier's professor, Ahmedabad: 82 days, over Rs 11 crore. Uses the alias 'Inspector Vijay Khanna' (Colaba), noted as a possible link to check to the Rs 58 cr case mastermind (EV-0005), not a confirmed identity |
| INC-064 | EV-0113 | Retired gynaecologist, Gandhinagar: 123 days, Rs 19.24 crore. Not merged |

## Removed (advisory / non-incident)
- Advisories/statements (10): 2338, 2374, 2501, 2581, 2597, 2683, 2743, 2812, 2820, 2832
- Policy/judicial (5): 2610, 2655, 3137, 3139, 3141
- Explainers (4): 2502 (one-line case), 2627 (no victim/place), 2694 (hypothetical lead), 2808 (essay, no fraud case)
- Reports/statistics (9): 2393, 2492, 2503, 2593, 2595, 2709, 2918, 3045, 3053

## Ambiguous cases
1. **Where the merged record lives.** Merged records are in batch 03 and the earlier batch records were kept (no deletion), so an event can appear once per batch. Deduplicate on `event_id`. An alternative is to mark the earlier records as superseded, or move canonical records to one file.
2. **Quantum AI campaign membership** is an editorial judgement based on the Rs 21,000-22,000 deposit template. Pichai 'Google Invest' (2478, 2580), Sudha Murty (2584) and the Kerala fake TV videos (2794) don't all use the 'Quantum AI' name. Cases with a named victim (2523, 2625, 2867, 2419, 2840) stay separate events. The record is bucketed AI-Confirmed-in-text, though 721, 2497 and 2716 alone would be AI-as-Lure.
3. **The 14 duplicates have their own event_ids**, not the Quantum AI one; your instruction could be read as putting them in the campaign, but they are different real-world events.
4. **Batches 01 and 02 were not retrofitted** for the new Out of Scope rule: their earlier non-India exclusions (B01: 13, 925, 886, 956, 920; B02: 1025/1891, 1009, 1776, 1876, 1951) and B02's 13 out-of-scope articles are still only listed in their reports. I can add them as Out of Scope records if you want.
5. **Feature rule side effects:** 2301 (advocate's column) became AI Misinformation, and 2568/2589 became Out of Scope records. The same rule was not re-run on batch 01/02 removals.
6. **Exam Proxy vs NTA OMR (INC-051):** fake/AI OMR sheets involve no proxy, so they're coded Document & Credential Forgery only.
7. **Fake Identity Document Service and Charity / Donation Fraud** have no cases in this file (B01 OnlyFake was excluded as non-India; B01 donation cases keep their type under the new Charity category).
8. **Out of Scope fraud_types:** non-India fraud records keep their fraud_types (with ai_bucket/scam_categories null) and the original bucket in review_note. Political videos and 2444 have fraud_types null.
9. **Unverified Claims harms:** kept as reported (e.g. FinancialLoss for the 'AI road' claim) even though the facts are unconfirmed.
10. **Pointer notes in batches 01/02** say "Merged record for this event: B03-INC-xxx"; B01's report still lists 721 as removed (a post-review note was appended).

## Proposed new second-level categories
None new beyond the approved v4 changes.
