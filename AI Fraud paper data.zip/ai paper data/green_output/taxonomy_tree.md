# Taxonomy tree (v6)

Counts in [brackets] are records across all 15 batches (1451 records). A fraud record can have several categories and types, so child counts can add up to more than their parent.

```
Incident
├── AI-Aided Fraud [1087] — fraud cases
│   ├── ai_bucket
│   │   ├── AI-Confirmed-in-text [246] — article states AI was used
│   │   ├── AI-Suspected [692] — AI not stated; digital arrest, voice impersonation, fake IDs, sextortion
│   │   ├── AI-as-Lure [15] — AI claimed as a lure only
│   │   └── No-AI-Evidence [134] — no AI used by fraudsters
│   └── scam_categories → fraud_types
│       ├── Financial Fraud [176]
│       │   ├── Investment Fraud [128]
│       │   ├── Banking & Payment Fraud [26]
│       │   ├── Loan Fraud [11]
│       │   ├── Insurance Fraud [2]
│       │   ├── Counterfeiting [1]
│       │   ├── Lottery / Prize Fraud [5]
│       │   └── Tax / GST Fraud [4]
│       ├── Charity / Donation Fraud [1]
│       │   └── Charity / Donation Fraud [1]
│       ├── Identity & Account Fraud [52]
│       │   ├── Identity Theft [19]
│       │   ├── Account Takeover [9]
│       │   ├── Document & Credential Forgery [29]
│       │   └── Fake Identity Document Service [0]
│       ├── Cyber Intrusion [0]
│       │   └── AI-Assisted Cyber Intrusion [0]
│       ├── Commerce & Platform Fraud [90]
│       │   ├── E-Commerce Fraud [25]
│       │   ├── Fake Platform Fraud [62]
│       │   └── Counterfeit Ticket Fraud [3]
│       ├── Relationship-Based Fraud [114]
│       │   ├── Romance Fraud [25]
│       │   ├── Recruitment Fraud [28]
│       │   ├── Political Post / Ticket Fraud [4] (subtype of Recruitment Fraud)
│       │   └── Sextortion [69]
│       ├── Impersonation Fraud [908]
│       │   ├── Individual Impersonation [171]
│       │   ├── Authority Impersonation [705]
│       │   ├── Organization Impersonation [45]
│       │   ├── Exam Proxy Fraud [9]
│       │   └── Virtual Kidnapping [13]
│       ├── Examination Fraud [9]
│       │   └── Exam Malpractice / Fake Paper Sale [9]
│       └── Others [33]
│           ├── AI Persona Monetisation [12]
│           ├── Occult / Spiritual Healer Fraud [4]
│           ├── Public-Works / Government Reporting Fraud [8]
│           └── Others [9]
├── AI Misinformation [151] — AI misinformation that is not fraud
│   └── misinformation_type
│       ├── Fabricated Event / Hoax [27]
│       ├── Political Deepfake / Manipulated Media of Public Figures [103]
│       ├── Issue-Based Disinformation [15]
│       └── AI-Fabricated Data / Citations [6]
├── Public Panic [4] — AI content causing public alarm
│   └── misinformation_type
│       ├── Fabricated Event / Hoax [3]
│       ├── Political Deepfake / Manipulated Media of Public Figures [0]
│       ├── Issue-Based Disinformation [1]
│       └── AI-Fabricated Data / Citations [0]
├── AI Harassment & Abuse [22] — AI content used to sexually depict, harass or abuse; no extortion
│   └── abuse_type
│       ├── Non-Consensual Intimate Deepfake [19]
│       └── AI-Enabled Harassment [3]
├── Unverified Claims [30] — allegations / unverified claims
│   ├── fraud_type (recorded only): Public-Works / Government Reporting Fraud [5]
│   ├── fraud_type (recorded only): Document & Credential Forgery [5]
│   ├── fraud_type (recorded only): E-Commerce Fraud [1]
│   ├── misinformation_type (claimed): Political Deepfake / Manipulated Media of Public Figures [13]
│   └── misinformation_type (claimed): Issue-Based Disinformation [2]
└── Out of Scope [157] — outside India or outside scope
    ├── fraud_type (recorded only): Individual Impersonation [42]
    ├── fraud_type (recorded only): Romance Fraud [19]
    ├── fraud_type (recorded only): Investment Fraud [19]
    ├── fraud_type (recorded only): AI-Assisted Cyber Intrusion [15]
    ├── fraud_type (recorded only): Account Takeover [10]
    ├── fraud_type (recorded only): Identity Theft [6]
    ├── fraud_type (recorded only): Organization Impersonation [4]
    ├── fraud_type (recorded only): E-Commerce Fraud [4]
    ├── fraud_type (recorded only): Virtual Kidnapping [4]
    ├── fraud_type (recorded only): Sextortion [3]
    ├── fraud_type (recorded only): Insurance Fraud [3]
    ├── fraud_type (recorded only): Document & Credential Forgery [2]
    ├── fraud_type (recorded only): Authority Impersonation [2]
    ├── fraud_type (recorded only): Charity / Donation Fraud [2]
    ├── fraud_type (recorded only): Banking & Payment Fraud [2]
    ├── fraud_type (recorded only): Others [1]
    ├── misinformation_type (claimed): Political Deepfake / Manipulated Media of Public Figures [5]
    ├── misinformation_type (claimed): Fabricated Event / Hoax [2]
    └── misinformation_type (claimed): AI-Fabricated Data / Citations [1]
```

## Applies to every record
```
ai_capabilities  (free-text list, e.g. 'AI voice clone', 'deepfake video')
harms
├── FinancialLoss [950]
├── IdentityTheft [22]
├── ReputationalHarm [290]
├── Extortion [750]
├── HumanTrafficking [5]
├── IdentityFraudEnablement [10]
└── PublicDeception [128]
attempt_only  (true / false)
personality_rights_case  (true / false) — true [49]
```

## Record hierarchy and field order
```
incident_domain → ai_bucket → scam_categories → fraud_types → ai_capabilities → harms
then: incident_id, event_id, news_url, news_source, date_of_publishing, incident_date, location, ai_evidence_in_text, attempt_only, amount_lost, currency, victim_count, accused_count, summary, channels, victims, perpetrators, source_article_ids, source_urls, incident_reported, misinformation_type, abuse_type, personality_rights_case, review_note
victims: description, type (individual | organization | group), gender, age
perpetrators: name, role, status
```

## Type definitions added in v5–v6
- **Lottery / Prize Fraud:** Victim told they won a lottery, prize, KBC draw or gift and made to pay 'fees', 'taxes' or 'customs' to claim it; includes fake lottery apps.
- **Tax / GST Fraud:** Fraud against the tax system: fake GST invoices / bogus input tax credit, shell firms, sales suppression to evade tax.
- **Virtual Kidnapping:** Caller claims a family member has been kidnapped or detained (by criminals or police) and demands ransom or 'bail', often with a cloned or impersonated voice or a fake image; includes self-staged kidnappings.
- **AI-Assisted Cyber Intrusion:** AI used to break into systems or accounts: AI-built malware or phishing kits, AI-automated hacking, AI voice phishing for access. Usually Out of Scope (not fraud or outside India); the type is still recorded.
- **Exam Malpractice / Fake Paper Sale:** AI-assisted cheating, fake 'leaked' papers, AI-made OMR sheets.
- **personality_rights_case:** a court action by or for a public figure or influencer over misuse of their name, face, voice or likeness. It does not change the domain.
