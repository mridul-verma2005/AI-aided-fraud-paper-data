# Report: green_highlighted_url_extracted_batch_04_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 163 / 163 (none truncated; ID 3310 is navigation text only) |
| Advisory / non-incident articles removed | **32** (11 advisories/statements/policy, 12 explainers/opinion/features without a qualifying case, 8 reports, 1 extraction failure) |
| **Records in incidents.json** | **109** (26 merged with earlier events; 2 split records from article 3760) |

| Top-level domain | Records | ai_bucket |
|---|---|---|
| AI-Aided Fraud | 62 | AI-Confirmed-in-text 47 · AI-Suspected 10 · No-AI-Evidence 3 · AI-as-Lure 2 |
| AI Misinformation | 20 | none |
| Public Panic | 0 | none |
| Unverified Claims | 7 | none |
| Out of Scope | 20 | none |

Victims: 54 of 139 victim objects have a stated gender and 17 have a stated age. The event registry now has 225 events.

## Taxonomy tree (v4, counts in this file)
```
AI-Aided Fraud (62)
├─ AI-Confirmed-in-text (47)
│  ├─ Impersonation (33): Individual 27 · Organization 4 · Authority 3 · Exam Proxy 1
│  ├─ Financial (18): Investment 17 · Banking & Payment 1
│  ├─ Commerce & Platform (13): Fake Platform 7 · E-Commerce 5 · Counterfeit Ticket 1
│  ├─ Others (9): Others 4 · AI Persona Monetisation 2 · Public-Works / Government Reporting 2 · Occult / Spiritual Healer 1
│  ├─ Identity & Account (8): Document & Credential Forgery 4 · Identity Theft 3 · Account Takeover 1
│  ├─ Relationship-Based (7): Sextortion 4 · Romance 3 · Recruitment 2
│  └─ harms: FinancialLoss 25 · ReputationalHarm 18 · Extortion 6 · IdentityTheft 4 · IdentityFraudEnablement 1 · HumanTrafficking 1
├─ AI-Suspected (10): Authority Impersonation 9 (digital arrests) · Organization 1 · Romance 1 (voice-changer matrimony)
├─ AI-as-Lure (2): Investment 2 · Fake Platform 2 · Individual 1 (Crystal AI Robot, Datameer)
└─ No-AI-Evidence (3): Kerala AI-camera allegation · BoB GM APK theft · Jagman Samra '5k coin' crypto
AI Misinformation (20)
├─ Political Deepfake / Manipulated Media (8): BJP AI audio of Sule/Patole, DRDO chief, Modi/Shah/Jaishankar apology, Shilpa Shetty, Poonam Pandey/Samay Raina, Vidya Balan, Khaira, Rashmika
├─ Fabricated Event / Hoax (8): Jagannath crane videos, Thar on signboard, AP flood drone, Indore chase, two Assam flood videos, Gujarat lion, Agra plane crash
├─ Issue-Based Disinformation (4): Dharmasthala YouTuber (merged), AI 'Patna' video (merged, now verified), ethanol bees, Assam 'intelligence report' bulletin
└─ harms: PublicDeception 17 · ReputationalHarm 9
Public Panic (0)
Unverified Claims (7) · Out of Scope (20): see below
```

## Merges by event_id (26)
| Record | event_id | Batch 04 articles added | Earlier record(s) |
|---|---|---|---|
| INC-001 Quantum AI deepfake-ad campaign | EV-0064 | 3293 (Rahul Gandhi), 3828 (Modi/FM/Ambani/Sudha Murty four-tile ad), 3834 (Gadkari), 3845 (PIB FM Rs 22,000), 3899, 3918 (Sudha Murty) | B03-INC-015 |
| INC-002 Kerala Rs 40k deepfake call | EV-0013 | 3343 | B01-013, B03-002 |
| INC-003 Indore teacher voice clone | EV-0015 | 3375 | B01-015 |
| INC-004 Rohit Shakya fake APKs | EV-0019 | 3626 | B01-019 |
| INC-005 Happn AI-avatar sextortion | EV-0030 | 3702 | B01-030 |
| INC-006 IBPS exam proxy gang | EV-0031 | 3658 | B01-031, B03-006 |
| INC-007 'Emily Hart' persona | EV-0035 | 3861 | B01-039, B02-008, B03-008 |
| INC-008 'Babydoll Archi' | EV-0047 | 3780, 3783 | B02-001, B03-009 |
| INC-009 Kerala ADGP deepfake | EV-0050 | 3684 | B02-004 |
| INC-010 Ashok Kharat bait clips | EV-0051 | 3920 | B02-005 |
| INC-011 Kerala AI camera allegation | EV-0054 | 3333, 3335 | B02-010, B03-010 |
| INC-012 Delhi GK couple Rs 14.8 cr | EV-0007 | 3832 | B01-007, B03-012 |
| INC-013 Pune ex-IAF officer Rs 1.07 cr | EV-0069 | 3898 | B03-020 |
| INC-014 Sadhguru Delhi HC case | EV-0073 | 3823 | B03-024 |
| INC-015 Crystal AI Robot Trading | EV-0080 | 3316 | B03-031 |
| INC-016 Owaisi deepfake complaint | EV-0086 | 3910 | B03-037 |
| INC-017 Bengaluru techie Rs 31.83 cr | EV-0089 | 3878 | B03-040 |
| INC-018 CBI Operation Chakra-VI | EV-0092 | 3831 | B03-043 |
| INC-019 NTA fake/AI OMR sheets | EV-0100 | 3829 | B03-051 |
| INC-020 Gandhinagar gynaecologist Rs 19 cr | EV-0113 | 3856 (plus split article 3108) | B03-064 |
| INC-063 Dharmasthala YouTuber AI video | EV-0120 | 3762 | B03-072 |
| INC-064 AI 'Patna' video | EV-0128 | 3799, 3803 | B03-080 |
| INC-083 'AI road' contractor (Unverified) | EV-0126 | 3907 | B03-078 |
| INC-084 Khandwa award allegation (Unverified) | EV-0127 | 3352, 3370, 3374, 3390, 3800 | B03-079 |
| INC-090 Congress 'tea' video (Out of Scope) | EV-0129 | 3797 | B03-081 |
| INC-091 Congress video of Modi's mother (Out of Scope) | EV-0130 | 3757 | B03-082 |

Earlier records for these events remain and now carry a pointer to the batch 04 record.

**Split:** article 3760 reports two separate victims of 'FX Road' deepfake ads: INC-046 (Veena K G, Rs 67.1 lakh, EV-0191) and INC-047 (Asok Kumar T S, Rs 19 lakh, EV-0192). They are linked only as a possible same-platform connection.

## Unverified Claims (7)
| Record | Articles | Why unverified |
|---|---|---|
| INC-083 | 2682, 3907 | Viral 'AI road' contractor video; no official confirmation |
| INC-084 | 2893, 3352, 3370, 3374, 3390, 3800 | Allegation that Khandwa officers won the National Water Award with AI images; officers and the ministry deny it. The **verified** teacher uploads are a separate fraud event (INC-027) |
| INC-085 | 3754, 3793 | TMC 'sting video' of Humayun Kabir; he says it is AI-fabricated; no forensic finding |
| INC-086 | 3795 | Prashant Kishor alleges the NDA's Nitish Kumar video is AI-generated |
| INC-087 | 3682 | Mamata Banerjee alleges AI-driven voter deletion in SIR |
| INC-088 | 3869 | Influencer Hetal Parmar says a viral clip is an AI deepfake |
| INC-089 | 3871, 3885 | Punjab CM Mann video row: AI claim vs alleged fake forensic reports |

## Out of Scope (20)
| Record | Articles | Reason |
|---|---|---|
| INC-090 | 2439, 3797 | Congress 'tea' AI video: party satire/campaign content |
| INC-091 | 2963, 2960, 2964, 3757 | Congress AI video of Modi's mother: party content |
| INC-092 | 3761 | DMK AI Karunanidhi videos: party campaign content (feature rule) |
| INC-093 | 3772 | BJP Assam 'Muslim takeover' AI video: party content (**borderline**, SC notice) |
| INC-094 | 3798 | JD(U) AI campaign videos (feature rule) |
| INC-095 | 3926 | BJP Karnataka AI video mocking DK Shivakumar |
| INC-096 | 3648 | BJP Uttarakhand AI 'spy' video of Harish Rawat (**borderline**, FIR filed) |
| INC-097 | 3712 | Non-consensual intimate deepfakes, Gujarat (no extortion) |
| INC-098 | 3778 | AI-morphed obscene photos of a Gurgaon woman (no extortion) |
| INC-099 | 3854 | AI-morphed obscene images of an Ahmedabad woman and her mother (no extortion) |
| INC-100 | 3334 | Outside India: USA (Jay Shooster voice clone) |
| INC-101 | 3791 | Outside India: AI 'Anaconda River' video |
| INC-102 | 3804 | Outside India: USA (YouTube deepfake Medicare ads) |
| INC-103 | 3814 | Outside India: Philippines (influencer AI image bait) |
| INC-104 | 3843 | Outside India: USA (Tom Hanks dental-plan deepfake) |
| INC-105 | 3858 | Outside India: Ireland (Taoiseach deepfake scam) |
| INC-106 | 3906, 3901 | Outside India: Argentina (George Clooney deepfake romance) |
| INC-107 | 3902 | Outside India: global (YouTube CEO deepfake phishing) |
| INC-108 | 3903 | Outside India: Spain/global (Nadal deepfakes) |
| INC-109 | 3909 | Outside India: USA (Trump's AI video of Obama) |

## Removed (32)
- Advisories/statements/policy (11): 3251, 3503, 3596, 3608, 3610, 3654, 3687, 3767, 3837, 3865, 3919
- Explainers/opinion/features without a qualifying case (12): 3235, 3236, 3259, 3264, 3528, 3600, 3696, 3736, 3857, 3862, 3893, 3900
- Reports/surveys (8): 3311, 3341, 3675, 3719, 3722, 3726, 3738, 3739
- Extraction failure (1): 3310 (navigation text only)

## Ambiguous cases
1. **Domain change from new evidence (EV-0128, AI 'Patna' video):** it was Unverified in batch 03; CyberPeace (3799) now confirms it is AI-generated and that the BJP posted it as real development, so it is now AI Misinformation, not Out of Scope party content (it was presented as genuine).
2. **Khandwa split into two events:** the award allegation stays Unverified (EV-0127); the administrative finding that teachers uploaded AI images (3357, 3385, four suspended) is a new verified fraud event (EV-0172). Is that split right?
3. **Party-posted AI content: deception vs campaign.** BJP's AI audio of Sule/Patole (3397, 3404) and the deepfake 'Assam defeat' bulletin (3773) were presented as genuine, so they are Misinformation. BJP Assam's 'Muslim takeover' video (3772) and BJP Uttarakhand's 'spy' video of Harish Rawat (3648) are filed as Out of Scope party content but are borderline (communal/defamatory; court and police action).
4. **Non-consensual intimate deepfakes without extortion** (3712, 3778, 3854) fit no domain, so they're in Out of Scope. Cases with extortion are Sextortion (3501, 3550, 3703, EV-0030). See proposal.
5. **Quantum AI campaign vs named victims:** victims of the Rs 21,000 template ads (3656 Roorkee Rs 66 lakh, 3844 Nagpur Rs 12.3 lakh) are separate events with a note.
6. **Same-platform links (not merged):** 'BXB Market' (3777 and B03 EV-0085), 'FX Road' (both 3760 cases), 'Naka Solutions' (earlier batches).
7. **SP Oswal (3905):** the title says 'deepfake tool' and the text says 'digital impersonation' of the CJI. Bucketed AI-Confirmed-in-text; could be AI-Suspected.
8. **Closest-fit codings:** fake NEET papers (3351/3355) as E-Commerce Fraud; Gadchiroli ChatGPT exam cheating (3394), TN-CM fake-aid scheme (3591) and Dholakia old-coin scheme (3853) as Others; Puri fake VIP darshan (3480) as Counterfeit Ticket Fraud.
9. **'19-minute viral video' (3889, 3886)** is filed as fraud (bait links) like the Kharat case, though it also involves non-consensual AI imagery of named influencers.
10. **Jagman Samra (3556):** the crypto fraud has no AI; he is also linked to the Punjab CM video row (INC-089) but no connection is confirmed.

## Proposed new second-level categories
- **Non-Consensual Intimate Deepfake** (domain or misinformation type): 3712, 3778, 3854 (and the NCII side of 3889/3886, 3869).
- **Exam Malpractice / Fake Paper Sale** (alongside Exam Proxy Fraud): 3394 (ChatGPT cheating racket), 3351/3355 (AI fake NEET papers), and the NTA AI OMR sheets (EV-0100).
- **Advance-Fee / Fake Aid & Get-Rich Schemes**: 3591 (TN CM fake aid), 3853 (old-coin scheme), and the Kerala ADGP old-currency deepfake (EV-0050).
