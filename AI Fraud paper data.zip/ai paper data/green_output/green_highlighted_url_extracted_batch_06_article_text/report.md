# Report: green_highlighted_url_extracted_batch_06_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 179 / 179 (none truncated; 5527 is a video page with navigation text only) |
| Articles removed | **40** (10 advisories/statements/regulatory, 11 explainers/features without a qualifying case, 6 reports, 12 not AI-related, 1 extraction failure) |
| **Records in incidents.json** | **117** (23 merged with earlier events; 1 split: article 4525) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 64 | AI-Confirmed-in-text 31 · AI-Suspected 11 · AI-as-Lure 3 · No-AI-Evidence 19 |
| AI Misinformation | 24 | Political Deepfake 16 · Hoax 4 · Issue-Based 2 · AI-Fabricated Data / Citations 2 |
| Public Panic | 0 | |
| AI Harassment & Abuse | 5 | Non-Consensual Intimate Deepfake 5 |
| Unverified Claims | 7 | |
| Out of Scope | 17 | |

Victims: 68 of 140 victim objects have a stated gender and 15 a stated age. The event registry now has 427 events (94 new).

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (64)
├─ AI-Confirmed-in-text (31)
│  ├─ Impersonation (19): Individual 16 · Authority 2 · Organization 2 · Exam Proxy 1
│  ├─ Financial (12): Investment 11 · Loan 1
│  ├─ Commerce & Platform (7): Fake Platform 6 · E-Commerce 1
│  ├─ Identity & Account (6): Document & Credential Forgery 4 · Identity Theft 2 · Account Takeover 1
│  ├─ Relationship-Based (5): Sextortion 5 (Faridabad suicide, Rabbani Abbas, Kumar Sankrit, Belagavi, merged Nikhil Singh)
│  ├─ Examination Fraud (2): TSPSC ChatGPT answers, merged NTA AI OMR sheets
│  ├─ Others (2): merged Babydoll Archi (AI Persona Monetisation) · Gorakhpur AI fake-kidnapping image
│  └─ harms: FinancialLoss 15 · ReputationalHarm 12 · Extortion 9 · IdentityTheft 2
├─ AI-Suspected (11): Authority Impersonation 11 (digital arrests; Ambala forged SC order also Forgery; Delhi network also Investment)
├─ AI-as-Lure (3): merged AV Solutions, Delhi Rs 14 cr 'AI-powered' forex-crypto, Ajit Pawar 'will' AI-platform ads
└─ No-AI-Evidence (19): WhatsApp boss/CEO impersonation (Mumbai Rs 10.4 cr, Hyderabad Rs 1.2 cr and Rs 75 lakh, Bengaluru gift cards), MEIL vendor Rs 5.47 cr,
     KBC/lottery (Vile Parle, Somajiguda, RBI-governor email, Delhi gift gang), GST fake ITC (Lucknow, 2018), loan apps 2020, Bihar TRE-3 proxies, SIR bait, TGCHE calls,
     Hyderabad trading app, Meerpet FM-name ad, Operation Octopus mule accounts, merged Kerala AI-camera allegation
AI Misinformation (24)
├─ Political Deepfake / Manipulated Media (16): personality-rights suits (Raghav Chadha, Aishwarya/Abhishek Bachchan, Tabu, Raj Shamani), Mrunal Thakur, Kerala G7 deepfake complaint,
│    Modi coconut image, Kerala CM–Sabarimala image, Seema Haider, Muskan Karia, @crazyashfan Bollywood nudes, + merged Tharoor, Rashmika, Rukmini, Payal, Meta-head FIR
├─ Fabricated Event / Hoax (4): Phoenix mall leopard, TNSTC 'Dubai' ticket (TOI retraction), Noida airport flooding, 'Lubna Qureshi' image
├─ Issue-Based Disinformation (2): Pakistan-linked AI-face accounts, + merged Dharmasthala YouTuber
├─ AI-Fabricated Data / Citations (2): SC flags AI petitions citing fake judgments; AP trial court order on AI fake judgments
└─ harms: PublicDeception 23 · ReputationalHarm 17
AI Harassment & Abuse (5): Non-Consensual Intimate Deepfake: Guwahati schoolboys (64 victims, sold online), Delhi HC influencer order, Kasargod (150+ women), Chhindwara minors, + merged Sumit Sharma
Unverified Claims (7) · Out of Scope (17): see below
```

## Merges by event_id (23)
| Record | event_id | Batch 06 articles added | Note |
|---|---|---|---|
| INC-001 Babydoll Archi / Pratim Bora | EV-0047 | 4412, 4413, 4442 | |
| INC-002 Fake IAS Lalit Kumar | EV-0095 | 4565 | listicle; other fake officers not split |
| INC-003 Pune SpaceX/FM deepfake Rs 1.07 cr | EV-0069 | 4798 | ID 4798 calls him a businessman |
| INC-004 Nikhil AI-nude extortion | EV-0189 | 6675 | ID 6675 gives age 24 |
| INC-005 NTA AI OMR sheets | EV-0100 | 5172 | NEET UG 2026 warning |
| INC-006 Kerala AI-camera allegation | EV-0054 | 5003 | |
| INC-007 Delhi GK doctor couple Rs 14.85 cr | EV-0007 | 6335 | |
| INC-008 Quantum AI campaign | EV-0064 | 4743, 4754 (Sudha Murty), 4990 (Ambani) | |
| INC-009 AI Trump video scam, Karnataka | EV-0023 | 4525 (Haveri advocate Rs 5.93 lakh) | split article |
| INC-010 Sunil Mittal voice clone | EV-0018 | 4530 | |
| INC-011 Chawla nephew voice clone | EV-0106 | 4606 | |
| INC-012 AV Solutions 'AI predictions' | EV-0020 | 4769 | |
| INC-013 SBI deepfake AI-platform alert | EV-0077 | 4888, 5009 | |
| INC-065 Tharoor deepfakes | EV-0278 | 4378, 6743 | HC injunction 8 May 2026 |
| INC-066 Rashmika deepfake | EV-0224 | 4384, 4385, 4391, 4393, 4431, 4443, 6599, 6664, 6670 | FIR, uploaders traced, creator Eemani Naveen arrested |
| INC-067 Rukmini Vasanth | EV-0290 | 4434 | 29 accounts booked |
| INC-068 Dharmasthala YouTuber | EV-0120 | 4403 | |
| INC-069 Payal Gaming | EV-0289 | 6634 | |
| INC-070 Hyderabad FIR vs Meta India head | EV-0280 | 6433 | |
| INC-089 Sumit Sharma | EV-0238 | 6673 | |
| INC-094 Mamata SIR-AI claim | EV-0314 | 4460 | |
| INC-095 Khandwa award allegation | EV-0127 | 5012, 5537 | Jal Shakti denial |
| INC-096 Hetal Parmar | EV-0229 | 6635 | |

**Split:** 4525. Its lead case is a Sambhajinagar digital arrest (INC-021, new event). Its second case, a Haveri advocate's loss to the AI Trump video, is merged into EV-0023.

## Unverified Claims (7)
- INC-094 Mamata (SIR and AI), INC-095 Khandwa award, INC-096 Hetal Parmar: merged, still unverified.
- **INC-097 (6341):** Sukesh Chandrasekhar says his voice in leaked chats was AI-cloned.
- **INC-098 (6346):** AAP's Gopal Italia says a BJP MLA's photo linking him to CM Rekha Gupta's attacker is AI-edited.
- **INC-099 (6376):** fake sexual allegations against IUML chief Thangal; leaders say AI imagery was used, police have not confirmed.
- **INC-100 (6691, 6721, 6730):** Rajanya Haldar says semi-nude images circulated by TMC members are AI deepfakes. The claimed type, Non-Consensual Intimate Deepfake, is in review_note because `abuse_type` is null outside its domain.

## Out of Scope (17)
- **India, not fraud/misinfo/abuse (3):** 6261 (Modi's Lil Yachty AI spoof and the Mamata spoof, open satire), 6098 (CBSE portal breached with AI tools), 6110 (Transparent Tribe AI-made malware against India).
- **Outside India (14 records):**
  - 4465 (South Korea, Lee Jung Jae romance scam)
  - 4494 (Indian diaspora in the US; diplomat-impersonation calls)
  - 4499 (Philippines/UAE, crown-prince deepfake romance)
  - 4625 (UK insurance claims)
  - 4705 (UAE minister deepfake ads)
  - 5896 (Australia, Musk 'Quantum AI')
  - 6020 (Iran AI malware)
  - 6071 (JadePuffer ransomware)
  - 6178 (FortiGate attacker)
  - 6254 (Anthropic / China espionage)
  - 6537 + 6640 (Taylor Swift)
  - 6548 (UK MP Jess Asato v xAI)
  - 6659 + 6711 (New Jersey school)
  - 6710 (Florida school)

## Removed (40)
- Advisories/statements/regulatory (10): 4415, 4495, 4541, 4768, 5417, 5672, 5807, 5872, 6538, 6689
- Explainers/features without a qualifying case (11): 4406, 4419, 4440, 4513, 4522, 5098, 5776, 6668, 6690, 6701, 6702 (6690/6701/6702: NZ MP's self-made demo image)
- Reports (6): 4773, 5035, 6600, 6688, 6692, 6696
- Not AI-related (12): 6142, 6265, 6340, 6362, 6368, 6370, 6371, 6384, 6385, 6494, 6529, 6531
- Extraction failure (1): 5527

## Ambiguous cases
1. **Many non-AI fraud articles (19 No-AI-Evidence records).** These are WhatsApp CEO scams, KBC lotteries, GST fake ITC (including a 2018 case), 2020 loan apps and similar. They are kept under the existing rule. Should old non-AI fraud articles stay in the dataset?
2. **EV-0069 merge:** B04 called the Pune victim a retired IAF officer and 4798 calls him a businessman. Age (56), city, amount and the SpaceX pitch all match.
3. **EV-0189 merge:** 6675 gives the accused's age as 24 and a different Delhi area (21 in earlier sources). The modus, victim type and date match.
4. **5620** (CBI, Rs 1.6 cr senior citizen, Telangana/AP accused) may be the same victim as EV-0254 (CBI, Rs 1.6 cr Delhi senior, Pulwama accused). It is linked, not merged.
5. **Guwahati schoolboys (4882)** sold the deepfakes online. I coded it Non-Consensual Intimate Deepfake. The 'Babydoll Archi' precedent (AI Persona Monetisation, fraud) could apply instead.
6. **Radha Devi (4528)** is kept under the feature rule, but the explainer gives no police details, so the case may be illustrative.
7. **Pakistan-linked AI-face accounts (4480)** come from a partisan outlet summarising an X thread.
8. **FM-name ad, Meerpet (4847):** no deepfake is stated, so No-AI-Evidence. Most such cases elsewhere are deepfakes.
9. **Specific-ad records** (PIB FM video 4883, Jaishankar 4986, Adani 5130, Anjana Om Kashyap/Devi Shetty 6681) are kept as separate events. 4883 may belong to the Quantum AI campaign.

## Proposed new second-level categories
- **Lottery / Prize Fraud:** 5860, 5882 (fake KBC), 5877 (RBI-governor lottery email), 5870 (gift/lottery gang). Currently Organization Impersonation.
- **Virtual Kidnapping** (a cloned voice or AI image used to fake a kidnapping): 4514, 4528, EV-0106 (Chawla), 6503 (self-staged). Currently Individual Impersonation or Others.
- **Tax / GST Fraud:** 5841, 5843. Currently Others + Document & Credential Forgery.
- **AI-Assisted Cyber Intrusion** (a category for Out of Scope, or a new domain): 6098 (CBSE), 6110 (Transparent Tribe), and the foreign cases 6020, 6071, 6178, 6254.
