# Report: green_highlighted_url_extracted_batch_14_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 168 / 168 (15262 short but usable; 15044 and 13622 have site boilerplate only) |
| Articles removed | **8** (4 explainers/reviews, 2 trend features with no specific case, 1 NCRB statistics, 1 boilerplate page) |
| **Records in incidents.json** | **134** (28 merged with earlier events; 4 articles split into extra cases) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 129 | AI-Suspected 90 · No-AI-Evidence 33 · AI-Confirmed-in-text 5 · AI-as-Lure 1 |
| AI Misinformation | 2 | Political Deepfake / Manipulated Media of Public Figures 2 (Gambhir and Anjana Om Kashyap court orders) |
| Out of Scope | 3 | Thailand (Bitkub deepfake ad), USA ×2 (AI voice-clone scams) |
| Public Panic / AI Harassment & Abuse / Unverified Claims | 0 | |

Victims: 109 of 145 victim objects have a stated gender and 60 a stated age. The event registry now has 1,027 events (106 new). The first half of the file is digital arrests. The second half (IDs 13644 onward) is mixed: morphed-image sextortion, job and recruitment impersonation, WhatsApp 'MD' frauds, investment apps and a few AI items.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (129)
├─ AI-Confirmed-in-text (5)
│    Sribhumi AI explicit video blackmail (Sextortion) · Mangaluru AI/morphed videos, Rs 2 cr demand (extortion, 'Others') · NSE CEO deepfake stock-tip videos (Investment + Individual Impersonation)
│    + merged Ghaziabad retired IPS deepfake sextortion (EV-0653) · SP Oswal fake CJI hearing (EV-0204)
├─ AI-Suspected (90)
│  ├─ Authority Impersonation (digital arrests) 74, 5 of them attempts: Mylapore Rs 4.15 cr · Palghar Rs 3.5 cr · Thane Rs 3.04 cr · Dehradun Rajpur Rs 3 cr · Faridabad CAG Rs 2.13 cr ·
│  │    Jayanagar Rs 2.1 cr · Bengaluru Rs 1.77 cr · Neredmet retired judge Rs 1.66 cr · Medchal Rs 1.6 cr · Andheri 'Justice Gavai' courtroom Rs 1.57 cr · Hyderabad three-victim spree Rs 1.89 cr · ...
│  │    Deaths: Bhopal advocate Shiv Kumar Verma (suicide)
│  │    Attempts: Nalgonda, AIADMK MP Shanmugam, Bareilly (son used flight mode), Mulki couple, + merged Lucknow widow
│  ├─ Sextortion with morphed images (AI not stated; per rule) 13: loan-app morphing (Gowliguda Rs 1.45 lakh, Tarnaka Rs 9.8 lakh, Bengaluru 'Credit Guru'),
│  │    Gurugram Class 10 girl Rs 80 lakh, Chandigarh judge Rs 1.5 cr demand, Amritsar Rs 5 lakh demand, Vadodara, Mylavaram, Puducherry minor, Mumbai minor, Jamkhandi BJP leader, Hubballi ex-MLA's son, Bengaluru model
│  ├─ Authority Impersonation + Sextortion 2: Dwarka fake 'CBI officer' Rs 4.84 lakh · Vasant Kunj fake 'Rakesh Asthana' Rs 7.34 lakh
│  └─ Voice impersonation 1: Bengaluru HAL homemaker, fake son on the line (Rs 1.25 lakh)
├─ AI-as-Lure (1): Pune university paid Rs 2.46 cr for fake 'drones and AI technology' research funding
└─ No-AI-Evidence (33): job/recruitment impersonation 12 (fake IAS/SI/NIA/RAW/Navy/KMF officers, Akasa Air, visa racket; Vivek Mishra Rs 80 cr) ·
     WhatsApp 'MD' impersonation 3 (Gujral Rs 7.8 cr, Puducherry Rs 5.1 cr, Mumbai Rs 1.9 cr) · investment apps 6 (Morgan Stanley, Aditya Birla, Orionex, Pune ×2, Hyderabad, Bailhongal) ·
     exam proxy 3 (Infosys tests, Infosys interview, Vyapam 2008) · e-commerce/rental 3 · romance/matrimony 2 · Goethe exam seats · Jamtara customer care · pension-officer ATM fraud · Priyanka Gandhi aide (attempt)
AI Misinformation (2): Anjana Om Kashyap deepfake YouTube channel (court order) · + merged Gambhir HC takedown (EV-0055)
Out of Scope (3): Bitkub CEO deepfake ad (Thailand) · AFP US voice-clone kidnapping scams · Philadelphia AI 'granddaughter' scam
```

## Merges by event_id (28)
- **EV-0007 Taneja couple Rs 14.85 cr (8 articles):** 13516, 13518, 13593, 13600, 13608, 15450, 15453, 15457 · **EV-0614 Munirka colonel (7):** 13480-13485, 13500, 13527
- **EV-0762 Delhi Rs 22.92 cr (5):** 13539, 13568 (SC writ against seven banks), 13631, 15462, 15471 · **EV-0783 Gajarla Avinash (4):** 13528, 13531, 13554, 13559 (victim: Balanagar 66-year-old, Rs 42 lakh)
- EV-0669 Gujarat Rs 11.42 cr (13477) · EV-0919 Lucknow widow (13478) · EV-0739 Chandigarh Sunita (13491) · EV-0797 T Ramasamy (13513) · EV-0089 Bengaluru Rs 31.83 cr (13515)
- EV-0553 Neredmet (13522) · EV-0751 Pinjore (13538) · EV-0756 Hyderabad Rs 7.12 cr (13565, 13590) · EV-0787 Bijnor (13602, 13604) · EV-0850 Saidabad Rs 59 lakh (13607, 15158)
- EV-0745 Dehradun woman Rs 3.09 cr (13625) · EV-0796 Gurugram Rs 42.92 lakh (13626, 13630) · **EV-0543 Delhi SIMBOX (13638; Taiwanese I-Tsung Chen arrested)** · EV-0446 Ankush Bahuguna (13579)
- EV-0518 Andheri 'Chandrachud' Rs 3.71 cr (14834) · **EV-0502 Behala couple (13566; Kolkata SIM-box arrest)** · EV-0653 Ghaziabad retired IPS (15247) · EV-0204 SP Oswal (15359) · EV-0823 Delhi Rs 1.16 cr (15373)
- EV-0455 Goa ED (15423) · EV-0105 Greater Kailash (15449) · EV-0379 Noida's first digital arrest (15517) · EV-0859 New Thippasandra (15604) · EV-0055 Gambhir (13644)

## New multi-article events
Neredmet retired judge Rs 1.66 cr (13532 part, 13546, 13552, 13562) · Mylapore Rs 4.15 cr (13595, 13597) · Dehradun Rajpur Rs 3 cr (13628, 13629) · Gowliguda loan-app sextortion (15252, 15274, 15278)

## Splits (4)
- **13523 / 13524** Hyderabad: Malkajgiri 74-year-old Rs 88.8 lakh · Sainikpuri Rs 68.8 lakh · Kondapur pastor Rs 31.61 lakh
- **13535** Hyderabad: Kompally Rs 38 lakh · Kukatpally Rs 27.5 lakh
- **14031** Pune: Hadapsar Bitcoin Rs 12.11 lakh (NOAI) · Katraj trading app Rs 10.86 lakh (NOAI) · Wanawadi digital arrest Rs 12 lakh
- **13532** Malkajgiri roundup: digital-arrest arrests (grouped with the retired judge) · Rs 1.16 cr investment case (NOAI)

## Removed (8)
- Explainers/reviews: 13490 (IVR calls), 13540 (DGP review), 13610 (SC directions) · Media: 13622 (Pulitzer; boilerplate only)
- No specific case: 13637 (Cambodia scam-centre feature), 15503 (fake army callers trend) · Statistics: 15194 (NCRB) · Extraction: 15044 (boilerplate only)

## Ambiguous cases
1. **Morphed-image sextortion (13 records):** none says AI was used. Per the rule that any threat or demand makes a case Sextortion, and Sextortion goes to AI-Suspected, they are AI-Suspected with a note. You may prefer No-AI-Evidence for old cases (2021, 2023).
2. **15226 Mangaluru:** 'morphed and AI-generated videos' with a Rs 2 crore demand, but the content isn't described as sexual, so type 'Others' with Extortion harm.
3. **15316 Pune university:** coded **AI-as-Lure** because the bait was 'research funding in drones and AI technology'. No-AI-Evidence is the alternative.
4. **13532 → retired judge:** a May roundup reports Suryapet arrests in a 'Rs 1.66 crore' Malkajgiri digital arrest. Matched to the February retired-judge case on amount and police unit.
5. **13552** gives the judge's age as 69 and 'over Rs 1 crore'; the other three articles say 73 and Rs 1.66 crore. Grouped.
6. **13566 → EV-0502 Behala couple** and **13638 → EV-0543 Delhi SIMBOX**: matched on place, modus and Taiwanese link; later arrests in the same cases.
7. **13646 NSE CEO deepfakes:** an exchange warning about specific videos, coded as fraud like the BSE CEO case (EV-0569).
8. **Job/recruitment impersonation (12 records, NOAI):** in-person cons with no AI or digital-arrest element. Kept as fraud per the no-AI-evidence bucket, but they could be removed as off-topic if you prefer.

## Proposed new second-level categories
None new. Still open from earlier batches: Lottery / Prize Fraud, Virtual Kidnapping, Tax / GST Fraud, AI-Assisted Cyber Intrusion, Personality-rights court-action flag.
