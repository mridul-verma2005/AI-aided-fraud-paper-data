# Report: green_highlighted_url_extracted_batch_13_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 163 / 163 (none truncated or short) |
| Articles removed | **5** (2 policy items on WhatsApp bans, 1 CBI probe with no specific case, 1 awareness film, 1 Pulitzer award) |
| **Records in incidents.json** | **132** (30 merged with earlier events; 6 articles split into extra cases) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 132 | AI-Suspected 130 · No-AI-Evidence 2 · AI-Confirmed-in-text 0 · AI-as-Lure 0 |
| Misinformation / Panic / Harassment / Unverified / Out of Scope | 0 | |

Victims: 126 of 142 victim objects have a stated gender and 76 a stated age. The event registry now has 921 events (102 new). This batch is digital arrests only, and **no article states AI use** by the fraudsters. The only AI-related sentence (13276, removed) is about WhatsApp using large language models to detect scams.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (132)
├─ AI-Suspected (130): Authority Impersonation 130 (digital arrests), 12 of them attempts only
│    Largest new: Mumbai retired pharma executive Rs 58 cr (3 articles) · Chembur Rs 12.81 cr · Khar social worker Rs 8.6 cr · Mumbai govt doctor Rs 7 cr ·
│    Southeast Delhi Kerala-Cambodia syndicate (10 held, Rs 50 cr) · Bengaluru 94-year-old Rs 4.9 cr · Dadar Rs 4.82 cr · Kharghar Rs 4.38 cr · Pune 'CBI Director' Rs 3.46 cr ·
│    Coimbatore doctor Rs 2.9 cr · Pimpri-Chinchwad (6 held, Rs 2.8 cr) · Gwalior 90-year-old Rs 2.5 cr · Vizag Rs 2.5 cr · Mangaluru Rs 2.07 cr · Bengaluru single mother Rs 2.05 cr ·
│    Hyderabad three-case spree Rs 1.73 cr · Indore Rs 1.60 cr (17 held) · Lucknow doctor Rs 1.55 cr · Payyoli Rs 1.51 cr · Pathanamthitta NRI couple Rs 1.40 cr · ...
│    Deaths: Veraval builder's wife (suicide)
│    Attempts (12): Bareilly, Kannur, Thiruvalla, Sultanpur MLC, Indore couple, Bhopal Oberoi (first live rescue), Bhopal Anirudh, Bhadrachalam, Bhubaneswar NALCO couple, Lucknow Usha Shukla, + merged Gurgaon Galleria, Kongad MLA
│    + merged Pune Rs 10.75 cr (5 articles), Chakra-VI (3), Jalandhar/PSPCL Rs 2.07 cr (3), Rourkela Bishop (3), Bhubaneswar Rs 1.38 cr (3), Gandhinagar Rs 19.24 cr (2), Bengaluru Rs 24 cr (2), ...
└─ No-AI-Evidence (2): Mayur Vihar fake trading-app fraud Rs 42.96 lakh · Cuttack investment fraud Rs 2.58 cr (split from 13459)
```

## Merges by event_id (30)
- **Fraud (30):**
  - EV-0677 Pune Rs 10.75 cr (13229, 13247, 13275, 13398, 13418) · EV-0092 Chakra-VI (13202, 13248, 13375) · EV-0728 Jalandhar Rs 2.07 cr (13201, 13436, 13460; victim named as Sukhmander Singh)
  - EV-0629 Rourkela Bishop (13440, 13461, 13463) · EV-0792 Bhubaneswar Rs 1.38 cr (13451, 13457, 13462) · EV-0113 Gandhinagar doctor (13207, 13400)
  - EV-0705 Bengaluru techie Rs 11.8 cr (13215, 13435) · EV-0626 Kottayam (13252, 13260) · EV-0675 Dahisar retired I-T officer (13244, 13249 part) · EV-0628 Bhubaneswar professor (13445, 13464)
  - EV-0553 Neredmet Rs 85.2 lakh, fully recovered (13265, 13281) · EV-0003 Bengaluru Rs 24 cr (13286, 13314)
  - EV-0718 Bagalkot (13218) · EV-0536 Punjagutta doctor (13191) · EV-0539 Jaipur ex-judge (13232) · EV-0699 SC advocate (13194) · EV-0358 Ambala SC letter (13474)
  - EV-0731 Delhi Yes Bank case (13234) · EV-0627 Kongad MLA (13251) · EV-0688 Ahilyanagar paediatrician (13426) · EV-0722 Gurgaon Galleria (13335) · EV-0670 Rs 1,500 cr racket / Chirag Kapoor (13371)
  - EV-0799 Ruchika Tandon (13372) · EV-0742 Cybits (13380) · EV-0525 Mumbai 86-year-old Rs 20.25 cr (13368) · EV-0643 Kalyan Rs 28 lakh (13402) · EV-0756 Hyderabad Rs 7.12 cr (13270)
  - EV-0613 Belagavi Saraf (13268) · EV-0089 Bengaluru Rs 31.8 cr (13327) · EV-0252 Indore J&K 'SP' (13324)

## New multi-article events (9)
Mumbai Rs 58 cr (13238, 13367, 13395) · Khar / Ankush More (13200, 13332) · Chandigarh Krishna Chand Rs 38 lakh (13197, 13406) · Southeast Delhi syndicate (13235, 13271) ·
Coimbatore doctor (13228, 13237) · Bommanahalli Rs 98.4 lakh (13287, 13315) · New Thippasandra Rs 2.05 cr (13309, 13310, 13311, 13318) · Berhampur VC (13449, 13456, 13471) ·
Bhubaneswar scientist (13452, 13455, 13459)

## Splits (6)
- **13219** Mira Road: Rs 22.54 lakh · second septuagenarian Rs 15.49 lakh
- **13249** Mumbai: retired I-T officer (EV-0675) · Shejimon MK case (~Rs 28 lakh)
- **13261** Hyderabad: Sheikpet Rs 54 lakh · Begumpet Rs 60.2 lakh · Saidabad Rs 59 lakh
- **13339** Pune: Aundh Rs 14.5 lakh · retired woman Rs 25 lakh
- **13355** Indore: Rs 46 lakh (Delhi call centre) · Rs 12.10 lakh (Telangana-Rajasthan network)
- **13459** Odisha CID: scientist (merged with 13452 group) · Cuttack investment fraud Rs 2.58 cr (No-AI-Evidence)

## Removed (5)
- Policy: 13276, 13282 (WhatsApp bans 9,400 accounts) · 13258 (CBI probe into Kozhikode mules, no specific case)
- Awareness / media: 13417 (Maharashtra Cyber film launch) · 13465 (Pulitzer for 'trAPPed')

## Ambiguous cases
1. **13200 + 13332 Khar social worker:** both name Ankush More and a Dec 2024 West Cyber case, but give Rs 8.60 crore vs Rs 1.6 crore. Grouped, using the larger figure, with a note.
2. **13327 → EV-0089:** batch 03 calls the victim a 'techie'; this article says a 57-year-old MNC executive. Same 187 transfers and Rs 31.8 crore.
3. **13283 Pimpri-Chinchwad six arrests (two cases)** may include EV-0559 (Pimpri lawyer, Rs 1.8 crore). Kept separate.
4. **13452/13455/13459 Bhubaneswar scientist:** amounts differ (Rs 1.06 cr vs Rs 1.68 cr). Rs 1.07 crore is used and the note records both.
5. **13249 second case:** the amount (~Rs 28 lakh) is the article's Rs 79 lakh total minus the I-T officer's Rs 51 lakh.
6. **13199 Mayur Vihar:** the headline says 'digital arrest and investment' racket, but the detailed case is investment fraud, so No-AI-Evidence.
7. **13334 Chennai:** a 'digital arrest' of a daughter abroad (fake High Commission), close to virtual kidnapping. Coded Authority Impersonation.
8. **13246 Scroll first-person feature:** the victim is placed (the author's father), with method and outcome, so kept.

## Proposed new second-level categories
None new. Still open from earlier batches: Lottery / Prize Fraud, Virtual Kidnapping, Tax / GST Fraud, AI-Assisted Cyber Intrusion, Personality-rights court-action flag.
