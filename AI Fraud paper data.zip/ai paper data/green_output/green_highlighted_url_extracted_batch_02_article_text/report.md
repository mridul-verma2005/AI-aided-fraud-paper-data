# Report: green_highlighted_url_extracted_batch_02_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `extraction_status == "success"` | 70 / 70 |
| Advisory / non-incident articles removed | **31** (14 advisories, 10 explainers/analysis, 7 reports/statistics) |
| Excluded: out of scope (AI-related but not fraud, misinformation or panic) | **13** articles (needs your decision, see below) |
| Incidents built | 23 (from 26 articles) |
| Excluded: outside India | 5 incidents (6 articles) |
| **Incidents in incidents.json** | **18** (20 articles) |

| Domain | Incidents | Buckets |
|---|---|---|
| AI-Aided Fraud | 10 | AI-Confirmed-in-text 8 · No-AI-Evidence 2 · AI-Suspected 0 · AI-as-Lure 0 |
| AI Misinformation | 7 | none |
| Public Panic | 1 | none |

Victims: 10 of 25 victim objects have a stated gender and 2 have a stated age.

**Text quality:** ID 1714 is **truncated** (32,767 characters). ID 1891 is site navigation only (title-only evidence). ID 1645 is a short video blurb.

## Taxonomy tree (India incidents)
```
AI-Aided Fraud (10)
├─ AI-Confirmed-in-text (8)
│  ├─ Relationship-Based (5): Synthetic Persona Monetisation 2 · Romance 2 · Recruitment 2
│  ├─ Impersonation (4): Individual 3 · Authority 1
│  ├─ Identity & Account (3): Identity Theft 2 · Document & Credential Forgery 1
│  ├─ Financial (1): Investment 1
│  ├─ Others (1): Others 1
│  ├─ ai_capabilities: face-swap/deepfake images & video; AI image generation; AI-forged documents;
│  │                    deepfake video from photo+voice; voice cloning; AI persona images; LLM chat/translation
│  └─ harms: FinancialLoss 5 · ReputationalHarm 4 · IdentityTheft 2 · HumanTrafficking 1
└─ No-AI-Evidence (2)
   ├─ Impersonation (1): Individual 1 · Authority 1 · Commerce (1): E-Commerce 1   [INC-006]
   ├─ Others (1): Others 1   [INC-010]
   └─ harms: FinancialLoss 1
AI Misinformation (7)   [ai_bucket / scam_categories / fraud_types = null]
├─ Political Deepfake / Manipulated Media of Public Figures (4): INC-011 Gambhir, 012 Abhishek Sharma, 013 Akshay Kumar, 016 CM Vijay image
├─ Fabricated Event / Hoax (1): INC-014 AI hailstorm, Maharashtra
├─ Issue-Based Disinformation (1): INC-015 AI border-fencing video, West Bengal
├─ AI-Fabricated Data / Citations (1): INC-017 fake Air India 171 crash report
└─ harms: ReputationalHarm 4
Public Panic (1)
└─ Fabricated Event / Hoax (1): INC-018 AI leopard images, Lucknow (schools shut, police loudspeakers)
```

## Incidents (India)
| ID | Domain / bucket | Case | Articles |
|---|---|---|---|
| INC-001 | Fraud / AI-Confirmed | 'Babydoll Archi' deepfake persona built on an Assam woman's face and monetised (about Rs 10 lakh) | 1643, 1714 |
| INC-002 | Fraud / AI-Confirmed | Fake PSI cheats about 20 women via matrimonial sites using AI-forged documents | 1908 |
| INC-003 | Fraud / AI-Confirmed | AI videos impersonating CM Naidu and Devineni Uma to sell posts to TDP leaders | 1914 |
| INC-004 | Fraud / AI-Confirmed | Deepfake of Kerala ADGP P. Vijayan promoting an old-currency scheme | 2024 |
| INC-005 | Fraud / AI-Confirmed | AI 'Ashok Kharat' clips used as bait for data-stealing links | 1744 |
| INC-006 | Fraud / No-AI-Evidence | 'Army transfer' cheap-goods scam; the target used ChatGPT to trace the scammer (attempt only) | 1076, 1090 |
| INC-007 | Fraud / AI-Confirmed | Hyderabad 72-year-old, Rs 1.97 lakh voice clone (**duplicate of B01-INC-016**) | 2060 |
| INC-008 | Fraud / AI-Confirmed | 'Emily Hart' AI MAGA persona (**duplicate of B01-INC-039**) | 1004 |
| INC-009 | Fraud / AI-Confirmed | Indian man trafficked to a Laos scam compound (AI-assisted romance/crypto scams) | 996 |
| INC-010 | Fraud / No-AI-Evidence | Kerala Rs 232 cr 'AI camera scam' (opposition allegation) | 2028 |
| INC-011 to 017 | AI Misinformation | see tree | 1945, 1605, 1863, 1728, 1817, 2042, 1954 |
| INC-018 | Public Panic | AI leopard hoax, Lucknow | 1858 |

## Excluded: outside India
| Article ID | Incident | Location |
|---|---|---|
| 1025, 1891 | INC-019 Thai PM targeted by a voice clone of a world leader | Thailand |
| 1009 | INC-020 'ChaChat' AI companion app: blackmail/scam reports | Online / global (Google Play app) |
| 1776 | INC-021 Fake AI-service Facebook pages spreading password stealers | Online / global (Facebook) |
| 1876 | INC-022 Suspected AI Trump crypto 'double your money' broadcast | USA |
| 1951 | INC-023 AI-faked damage photos for refunds | China |

## Excluded: out of scope (need your decision)
These involve AI but are not AI fraud, AI misinformation or public panic, and they are not advisories. They are kept out of incidents.json rather than forced into a domain:

| Article ID | Location | Why |
|---|---|---|
| 1629 | Bengaluru, India | Pronto head-mounted cameras / AI training-data privacy controversy |
| 1635 | New Delhi, India | Theft of AI wearables at the AI Impact Summit (ordinary theft) |
| 1819 | West Bengal, India | TMC MP questions EC's AI app for the electoral roll (political controversy) |
| 1833 | India | Nano Banana 'mole' privacy scare (Google: coincidence) |
| 993 | New Jersey, USA | Man died travelling to meet a Meta chatbot that claimed to be real |
| 1013 | Florida, USA | Teen suicide linked to a Character.AI chatbot |
| 1007, 1675 | Mexico | Hacker used Claude to breach Mexican government systems |
| 1677, 1756 | USA | Vercel breach via a compromised third-party AI tool |
| 1701 | USA | Ex-Google engineer's AI trade-secret theft case |
| 1852 | USA | OpenAI test models breached Hugging Face |
| 1854 | USA | McDonald's AI hiring chatbot data exposure |

## Removed (advisory / non-incident)
- Advisories (14): 1015, 1016, 1620, 1622, 1716, 1733, 1743, 1762, 1770, 1788, 1790, 1793, 1801, 1813
- Explainers / analysis (10): 997, 1001, 1645, 1671, 1682, 1799, 1832, 1860, 1877, 1907
- Reports / statistics (7): 1017, 1033, 1655, 1779, 1947, 2003, 2025

## Ambiguous cases
1. **Out-of-scope category** (13 articles above). This exclusion type isn't in CLAUDE.md. Options: keep excluding (and add the rule to CLAUDE.md), add a 4th domain (e.g. "Other AI Harm"), or force each into an existing domain.
2. **Cross-batch duplicates:** INC-007 = B01-INC-016 and INC-008 = B01-INC-039. `event_id` is still null; a shared event_id could link them across batches.
3. **INC-009 (Laos trafficking)** is kept under the India rule (Indian victim lured by a fake job offer), but the article doesn't say explicitly that he was recruited in India.
4. **INC-010 (Kerala 'AI camera scam')** is a political corruption allegation where AI is only the product; kept as No-AI-Evidence fraud, but it could be out of scope.
5. **INC-005 (Ashok Kharat)** is both misinformation and data-theft fraud; filed under Fraud.
6. **INC-006**: the target used AI against the scammer, so No-AI-Evidence. The covert location/photo capture is legally questionable.
7. **Removed roundups with specific mentions:** 1877 (Operation Sindoor; the cited fakes aren't AI), 1682 (AI video of PM Modi's mother), 1799 (celebrity deepfake suits), 1671 (Arup), 2025 (Kerala deepfake investment stats).
8. INC-001 cites a second case in 1714 (a teenager's stolen reels) that is not split out. INC-017 mentions fraudulent fundraising without specifics.
9. **Harms:** 5 misinformation/panic incidents and INC-006 have no listed harm (none of the six fits public alarm or plain misinformation).

## Proposed new second-level categories
- **Political Post / Favour Fraud** (selling posts or appointments): article 1914 (INC-003), currently Recruitment Fraud. Only one case, so a weak proposal.
- **Fake Get-Rich Schemes** (e.g. old-currency sale): article 2024 (INC-004), currently Others. One case, also weak.
- **A harm for misinformation/panic** (e.g. "PublicPanic" / "PublicDeception"): articles 1858, 1728, 1817, 1954 have no fitting harm.
- If you want the out-of-scope cases recorded: a domain such as **"Other AI Harm"** for articles 993, 1013, 1629, 1833 and the AI-assisted hacking cases 1007/1675.

## Post-review changes (batch 03 rev 1)
- Taxonomy migrated to v4 in incidents.json/taxonomy.json: INC-001 and INC-008 -> AI Persona Monetisation; INC-003 (article 1914) adds Political Post / Ticket Fraud; INC-010 (Kerala AI camera, article 2028) -> Public-Works / Government Reporting Fraud; PublicDeception added to INC-014, 015, 017, 018.
- Every record has an event_id. INC-007 shares EV-0016 with B01-INC-016; INC-008 shares EV-0035 with B01-INC-039. INC-001, 008 and 010 point to merged records in batch 03.
- Retrofitted (Out of Scope rule): the five non-India incidents are now Out of Scope records INC-019 to 023, and the 13 out-of-scope articles are Out of Scope records INC-024 to 034 (1007+1675 and 1677+1756 are one record each). incidents.json now has 34 records.
