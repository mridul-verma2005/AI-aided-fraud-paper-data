# Report: green_highlighted_url_extracted_batch_07_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 164 / 164 (none truncated; 6952 and 7426 are short; 6778 and 7453 are mostly unrelated page text and are kept in their events by title) |
| Articles removed | **43** (4 advisories, 24 explainers/reports/trend pieces, 15 not AI-related) |
| **Records in incidents.json** | **100** (27 merged with earlier events, including 2 duplicate-event fixes; no splits) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 51 | AI-Confirmed-in-text 25 · AI-Suspected 13 · AI-as-Lure 1 · No-AI-Evidence 12 |
| AI Misinformation | 22 | Political Deepfake 21 · AI-Fabricated Data / Citations 1 |
| Public Panic | 0 | |
| AI Harassment & Abuse | 1 | Non-Consensual Intimate Deepfake 1 (merged Palam case) |
| Unverified Claims | 4 | |
| Out of Scope | 22 | 1 party content, 21 outside India |

Victims: 71 of 113 victim objects have a stated gender and 25 a stated age. The event registry now has 500 entries (73 new; 2 older entries marked `merged_into`).

## Duplicate-event fixes (earlier batches)
Checking public-figure names across all batches found two events I had recorded twice:
- **Gautam Gambhir suit:** EV-0295 (B05-INC-065) duplicates EV-0055 (B02). Folded into EV-0055 as B07-INC-052, with B07's 7885.
- **'Nanditha' bxbmarket.com case:** EV-0349 (B06-INC-029) duplicates EV-0194 (B04). Folded into EV-0194 as B07-INC-001.

The old records stay, with a note "Duplicate event: merged into …", and the registry marks EV-0295 and EV-0349 as `merged_into`.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (51)
├─ AI-Confirmed-in-text (25)
│  ├─ Relationship-Based (14): Sextortion 12 · Romance 3 (Rashmi Kar AI male voice, Jhansi 'AI brides', merged Happn)
│  ├─ Impersonation (8): Individual 8 (Aviator ads, Ambani AI-app deepfake, Assam AI-voice WhatsApp takeovers, merged Pooja Shali, Chawla-type nephew clone…)
│  ├─ Financial (5): Investment 5 (Mumbai doctor/Ambani, Bengaluru homemaker/FM, merged Nanditha…)
│  ├─ Commerce & Platform (4): Fake Platform 4
│  ├─ Examination Fraud (1): HNGU AI exam cheating
│  ├─ Others (2): merged Emily Hart (AI Persona Monetisation), merged Gorakhpur fake kidnapping
│  └─ harms: Extortion 14 · ReputationalHarm 14 · FinancialLoss 12
├─ AI-Suspected (13): Sextortion 9 (real or 'morphed' images, no AI stated) · Authority Impersonation 4 (digital arrests)
├─ AI-as-Lure (1): Hyderabad 'Shoonya' AI-trading WhatsApp group (Rs 2.36 cr)
└─ No-AI-Evidence (12): Trade with Jazz (Rs 500 cr), Gain Bitcoin (Rs 20,000 cr), 'Money Heist' gang (Rs 150 cr), Vihaan MLM, AMANSA app, Tantan romance (Rs 1.66 cr),
     'Anushka' dating theft, 'Payatm' spoof UPI app, biryani tax suppression (defender AI only), GST fake invoices 2019, Manav Bharti fake degrees, merged Kerala AI-camera allegation
AI Misinformation (22)
├─ Political Deepfake / Manipulated Media (21): Rahul/Priyanka placard, Preity Zinta, Harsha Richhariya, Kriti Sanon nude fake, Aishwarya pool deepfake (2023), Kavya Maran, Yusuf Pathan,
│    Neha Kakkar 'arrest', Akira Nandan AI film; personality-rights suits: Yuvraj Singh, Suniel Shetty, Asha Bhosle, Jubin Nautiyal, Aniruddhacharya, Arijit Singh, Anil Kapoor, Sonakshi Sinha;
│    + merged Gambhir, Rashmika, Naga Chaitanya, Abhishek Sharma
├─ AI-Fabricated Data / Citations (1): merged AP trial-court fake citations (adds AP HC order)
└─ harms: ReputationalHarm 21 · PublicDeception 19
AI Harassment & Abuse (1): merged Palam ex-girlfriend case
Unverified Claims (4): PTR vs Annamalai audios, A Raja audio, + merged Rajanya Haldar, Mamata SIR-AI claim
Out of Scope (22): see below
```

## Merges by event_id (27)
- **Fraud (13):**
  - EV-0194 Nanditha (dup fix) · EV-0054 Kerala AI camera (6840, 6841, 7431)
  - EV-0265 Sourav (6852, 6967) · EV-0381 Faridabad Rahul Bharti (6 articles)
  - EV-0263 Bhopal Class 11 (6944, 6998) · EV-0270 Bhadohi (6945, 6987)
  - EV-0383 Kumar Sankrit (6950) · EV-0266 IIIT Naya Raipur (6952)
  - EV-0030 Happn 'Ishani' (7273) · EV-0035 Emily Hart (7426, 7698)
  - EV-0378 Gorakhpur fake kidnapping (7517) · EV-0109 Canada-nephew voice clone (7514)
  - EV-0076 Pooja Shali (7835)
- **Misinformation (5):** EV-0055 Gambhir (dup fix + 7885) · EV-0224 Rashmika (6771, 7002, 7003) · EV-0275 Naga Chaitanya (7453) · EV-0394 AP fake citations (7852) · EV-0056 Abhishek Sharma (7886)
- **Abuse (1) / Unverified (2):** EV-0305 Palam (6956) · EV-0410 Rajanya Haldar (6778) · EV-0314 Mamata (7536)
- **Out of Scope (6):** EV-0239 Jay Shooster (6879) · EV-0421 JadePuffer (7131, 7132) · EV-0414 Lee Jung-jae (7212) · EV-0416 Dubai-prince deepfake (7231, 7235) · EV-0141 fake Brad Pitt (7260, 7261) · EV-0325 Naga Munchetty (7286)

## Unverified Claims (4)
- **INC-077 (7009):** TN FM PTR says audio clips released by BJP's Annamalai are AI-fabricated (2023).
- **INC-078 (7504):** DMK's A Raja says an audio clip attributed to him is AI-made (2026 polls).
- INC-075 Rajanya Haldar and INC-076 Mamata (SIR and AI): merged, still unverified.

## Out of Scope (22)
- **Party content (1):** 6765, TVK's AI video of Annadurai endorsing Vijay.
- **Outside India (21):**
  - 6777 (Spain), 6779 (Scotland), 6975 (Malaysia, deepfake-porn extortion emails)
  - 6990 (Vienna: an Indian influencer blackmailing a woman there with AI nudes)
  - 7030 (Shreya Datta, US), 7055 (XRP Las Vegas), 7062 + 7268 (Hong Kong deepfake romance ring)
  - 7067 (Myanmar compounds), 7087 (Commonwealth prize), 7180 (Claude ransomware), 7214 (Chicago)
  - 7393 (Lee Ji Hye), 7456 (Penny Mordaunt), 7693 (Google v Outsider Enterprise), 7784 (Massachusetts)
  - Merged: Jay Shooster, JadePuffer, Lee Jung-jae, Dubai prince, Brad Pitt, Naga Munchetty

## Removed (43)
- Advisories (4): 6997, 7028, 7213, 7427
- Explainers/reports/trend pieces (24): 6989, 7029, 7037, 7038, 7039, 7045, 7061, 7064, 7065, 7066, 7103, 7145, 7148, 7149, 7150, 7163, 7168, 7193, 7215, 7220, 7695, 7855, 7892, 7903
- Not AI-related (15): 6941, 6953, 7133 (police used AI), 7172, 7192, 7240, 7344, 7345, 7346, 7347, 7348, 7349, 7350, 7383, 7384

## Ambiguous cases
1. **Sextortion without AI (9 AI-Suspected records).** Several involve real recorded videos (Datia rape case 6999, Amravati 350 videos 7001, Bokaro 6976, Antop Hill 6995) or 'morphed' images with no AI stated (7011, 7012, 7013). They are AI-Suspected per the sextortion rule, but the Datia and Amravati cases are really sexual-assault cases.
2. **Mirzapur gym case (6942, 6973):** AI videos used to coerce religious conversion. Coded Sextortion (AI-Confirmed-in-text).
3. **EV-0109 location:** 7514 says Hyderabad; earlier sources say Delhi. Same victim profile (59, Rs 1.4 lakh, Canada nephew, Punjabi).
4. **EV-0394:** the AP High Court order (7852) and the Supreme Court cognisance (6230) are treated as one fake-citation event. The SC article doesn't name the case.
5. **Vienna case (6990):** the perpetrator is Indian but lived and acted in Austria, so it is Out of Scope.
6. **Non-AI frauds** again make up 12 records, including very large but unrelated schemes (Gain Bitcoin, Trade with Jazz) and a 2022 report of fake degrees. This is still an open question from B06.
7. **Duplicate-event risk:** the two fixes above show that cross-batch matching by event ID can miss repeats. From now on I'll run a name check against all batches before assigning new event IDs.

## Proposed new second-level categories
Carried over from B06 (not yet decided): **Lottery / Prize Fraud**, **Virtual Kidnapping**, **Tax / GST Fraud** (adds 7515 biryani tax suppression and 7607 GST invoices), **AI-Assisted Cyber Intrusion**. One new proposal:
- **Personality-rights suit (court action)** as a flag or misinformation subtype. Celebrity court actions are now about 25 records under Political Deepfake, even though many cover merchandise or voice tools rather than deceptive media. Examples here: Asha Bhosle, Arijit Singh, Jubin Nautiyal, Sonakshi Sinha.
