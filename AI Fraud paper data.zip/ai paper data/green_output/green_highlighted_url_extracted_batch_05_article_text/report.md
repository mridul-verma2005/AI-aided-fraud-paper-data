# Report: green_highlighted_url_extracted_batch_05_article_text.xlsx (rev 1)

## Revision 1 changes
- **4149 / 4197 / 4202 (Samreen Ayoub)** moved from Out of Scope to **AI Misinformation, Issue-Based Disinformation** (communal disinformation using an AI voiceover).
- **Taxonomy v5** (approved proposals), applied here and retrofitted to batches 01–04:
  - New domain **AI Harassment & Abuse** with a new field `abuse_type` (after `misinformation_type`, null elsewhere):
    - **Non-Consensual Intimate Deepfake:** 10 records here, plus B04-INC-097/098/099 moved from Out of Scope.
    - **AI-Enabled Harassment:** 4127, 4306, and 4168/4174 (moved from "other AI-related").
  - New fraud category **Examination Fraud: Exam Malpractice / Fake Paper Sale.** This covers 3962 here, plus the retrofitted EV-0170 (fake NEET papers; E-Commerce kept), EV-0176 (Gadchiroli ChatGPT racket; Others replaced) and EV-0100 (NTA AI OMR sheets; Forgery kept).
  - Exam Proxy Fraud stays under Impersonation Fraud.
  - Rule: intimate deepfakes of public figures stay in AI Misinformation, and any threat or demand makes a case Sextortion.
- **Two duplicates found during the retrofit and merged:**
  - 4292/4309/4310 → **EV-0066** (the Air India cabin crew case, B03-INC-017).
  - 4210 → **EV-0047** (the Pratim Bora 'Babydoll Archi' case).
- taxonomy.json is rewritten as v5 in all five batch folders, and CLAUDE.md is updated.

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 171 / 171 (none truncated; 4001 and 4220 are navigation text only and are kept in their events by title) |
| Advisory / non-incident articles removed | **22** (9 advisories/statements, 8 explainers/opinion, 3 reports, 2 not AI-related) |
| **Records in incidents.json** | **107** (22 merged with earlier events; no splits) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 34 | AI-Confirmed-in-text 23 · AI-Suspected 10 · No-AI-Evidence 1 |
| AI Misinformation | 34 | Political Deepfake 22 · Hoax 10 · Issue-Based 2 |
| Public Panic | 1 | Issue-Based 1 |
| AI Harassment & Abuse | 13 | Non-Consensual Intimate Deepfake 10 · AI-Enabled Harassment 3 |
| Unverified Claims | 3 | none |
| Out of Scope | 22 | none |

Victims: 68 of 117 victim objects have a stated gender and 15 have a stated age. The event registry now has 333 events.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (34)
├─ AI-Confirmed-in-text (23)
│  ├─ Relationship-Based (11): Sextortion 10 · Romance 1
│  ├─ Impersonation (8): Individual 8
│  ├─ Financial (7): Investment 6 · Banking & Payment 1
│  ├─ Commerce & Platform (6): E-Commerce 3 · Fake Platform 3
│  ├─ Examination Fraud (2): Exam Malpractice / Fake Paper Sale 2 (MP university AI answers; merged Indore fake NEET papers)
│  ├─ Others (2): AI Persona Monetisation 1 (merged Babydoll Archi) · Occult / Spiritual Healer 1
│  ├─ Identity & Account (1): Identity Theft 1
│  └─ harms: ReputationalHarm 13 · FinancialLoss 10 · Extortion 10 · IdentityTheft 1
├─ AI-Suspected (10): Authority Impersonation 10 (digital arrests; Shivpuri gang also Sextortion)
├─ AI-as-Lure (0)
└─ No-AI-Evidence (1): Kannauj teacher-video phishing links (Identity Theft)
AI Misinformation (34)
├─ Political Deepfake / Manipulated Media (22): Kerala @valiant_Raju PM-ECI video, Goyal/Modi FIR, Hyderabad FIR vs Meta India head, Yogi resignation, Sheikh Hasina, Punjab CM Mann,
│    Tharoor, Gambhir, Naga Chaitanya, Mohanlal, Allu Arjun, Aman Gupta, Ajay Devgn, Chiranjeevi, Girija Oak, Anasuya Bharadwaj, Payal Gaming, Rukmini Vasanth,
│    + merged Vidya Balan, Khaira, Rashmika 2023, Bratya Basu
├─ Fabricated Event / Hoax (10): lion, Chandrapur tiger, Sawai Madhopur flood, Mahabalipuram temple, cloudburst, Uttarkashi, Khesari Lal house, UP cash truck, woman firing at stalker, + merged Jagannath
├─ Issue-Based Disinformation (2): Samreen Ayoub (rev 1), + merged Kancha Gachibowli
└─ harms: PublicDeception 26 · ReputationalHarm 24
Public Panic (1): Damoh AI shoe-garland image → caste humiliation and unrest
AI Harassment & Abuse (13)
├─ Non-Consensual Intimate Deepfake (10): Sumit Sharma/Ahmedabad (merged), Ruchi Kokcha/Grok, Grok 'bikini' (Nisha), Palam ex-girlfriend, Vadodara teacher (feature),
│    Karad doctors, Sonarpur Class 10 suicide, Coimbatore colleague, Chennai ex-employee, Coimbatore college (24 girls)
├─ AI-Enabled Harassment (3): trans woman filmed with Meta AI glasses + AI content, casteist AI videos of Lakhshay Lakey, Bhopal matrimonial rejection (AI wedding photos, 500 cabs)
└─ harms: ReputationalHarm 13
Unverified Claims (3) · Out of Scope (22): see below
```

## Merges by event_id (22)
| Record | event_id | Batch 05 articles added | Earlier record(s) |
|---|---|---|---|
| INC-001 AI Trump video investment scam, Karnataka | EV-0023 | 3927 | B01-023, B03-003 |
| INC-002 Sadhguru deepfake, Bengaluru woman Rs 3.75 cr | EV-0070 | 3929 | B03-021 |
| INC-003 Kerala Rs 40k deepfake video call | EV-0013 | 3956, 3959 | B01-013, B03-002, B04-002 |
| INC-004 Maharashtra matrimonial AI voice-clone scam | EV-0082 | 3987 | B03-033 |
| INC-005 Rajasthan AI 'tantrik' | EV-0088 | 4021 | B03-039 |
| INC-006 Indore ChatGPT fake NEET papers (now Exam Malpractice + E-Commerce) | EV-0170 | 4052 | B04-025 |
| INC-007 Hyderabad doctor, FM deepfake ad | EV-0024 | 4058 | B01-024, B03-007 |
| INC-008 Madhusudan Kela deepfake | EV-0205 | 4097 | B04-060 |
| INC-009 Nikhil Singh AI-image extortion | EV-0189 | 4158 | B04-044 |
| INC-010 Sadhguru Delhi HC case | EV-0073 | 4162 | B03-024, B04-014 |
| **INC-011 Air India cabin crew AI nudes (rev 1)** | EV-0066 | 4292, 4309, 4310 | B03-017 |
| **INC-012 Pratim Bora 'Babydoll Archi' (rev 1)** | EV-0047 | 4210 | B02-001, B03-009, B04-008 |
| INC-035 Vidya Balan AI videos | EV-0220 | 3942, 4001 | B04-077 |
| INC-036 Jagannath AI visuals | EV-0209 | 4003 | B04-066 |
| INC-037 Khaira AI video (court ordered 72-hour takedown) | EV-0223 | 4004 | B04-080 |
| INC-038 Rashmika/Zara Patel deepfake (2023) | EV-0224 | 4043 | B04-081 |
| INC-039 Kancha Gachibowli AI clips | EV-0044 | 4059, 4327 | B01-048, B03-069 |
| INC-040 Bratya Basu 'bribe' AI video | EV-0118 | 4089 | B03-070 |
| INC-070 Sumit Sharma AI nudes (now AI Harassment & Abuse) | EV-0238 | 4153, 4154, 4155, 4177 | B04-099 |
| INC-086 Harish Rawat 'spy' AI video (Out of Scope) | EV-0235 | 4088 | B04-096 |
| INC-087 Neal Mohan phishing video (Out of Scope, outside India) | EV-0246 | 4092 | B04-107 |
| INC-088 Congress AI video of Modi's mother (Out of Scope) | EV-0130 | 4109, 4111, 4112, 4113, 4115 | B03-082, B04-091 |

Earlier records stay in place, and each now points to the merged B05 record.

## Unverified Claims (3)
- **INC-083 (4075):** Ajay Rai says a viral clip of him abusing PM Modi is AI-generated; the BJP says it is real.
- **INC-084 (4243):** MLA Fathima Tehlia says she was targeted with AI images; the material was referred to cyber police.
- **INC-085 (4339):** Mamata Banerjee alleges the SIR voter-roll revision is an AI-run 'scam'.

## Out of Scope (22)
- **Party campaign content posted openly (7):** 3930, 4051 (feature), 4091, 4096, 4341 (BJP Assam 'point blank shot'; borderline, communal), plus merged Harish Rawat and Modi's mother.
- **Other AI-related cases, not fraud, misinformation, panic or abuse (5):** 3999 (Odisha AI emblem), 4067 (Squid Game fan video), 4163/4186 (EC SIR AI name errors), 4188/4291 (student suicide after AI-cheating accusation), 4130 (Nagpur robbery after AI WhatsApp statuses).
- **Outside India (10):** 3996 (UK), 4039 (USA), 4053 (Indonesia), 4070 (Brazil), 4094, 4099, 4167 (USA), 4215 (Replika), 4229 (US/UK teachers), plus merged Neal Mohan.

## Removed (22)
- Advisories/statements (9): 3976, 3981, 4073, 4151, 4194, 4272, 4345, 4348, 4374
- Explainers/opinion/features without a qualifying case (8): 4022, 4056, 4082, 4104, 4206, 4208, 4235, 4364
- Reports/surveys (3): 3931, 4093, 4191
- Not AI-related (2): 4077 (misattributed real cheating clip), 4230 (Atul Subhash was an 'AI engineer')

## Ambiguous cases
1. **Punjab CM Mann deepfake (4012, 4016)** is a new AI Misinformation event, EV-0293 (it was EV-0294 before the rev 1 renumbering). It may be the same video as B04's Unverified EV-0230; that is noted as a link to check.
2. **Threats without a money demand coded as Sextortion:** 4302/4307 and 4181. Without the threats, these would now be Non-Consensual Intimate Deepfake.
3. **AI only alleged by the family or complainant** but bucketed AI-Confirmed-in-text: 4123, 4184, 4290.
4. **Celebrity personality-rights suits** are coded Political Deepfake as in the Shilpa Shetty precedent. Public-figure intimate deepfakes (Payal, Rukmini, Girija Oak, Chiranjeevi, Anasuya) stay AI Misinformation under the v5 rule.
5. **Trans woman with AI glasses (4168/4174)** is filed as AI-Enabled Harassment. The secret filming itself is a privacy issue; the AI part is the AI-generated content made from her face.
6. **Possible link, not merged:** the Goyal/Modi FIR in Maharashtra (3984) and the Hyderabad FIR against the Meta India head (4061/4065).

## Proposed new second-level categories
None this run (the three proposals were approved and applied as v5).
