# Taxonomy v6 changes (applied after batch 15)

Applied to all 15 batches (1,451 records). Each changed record has a review_note starting 'Taxonomy v6 retrofit:'. Every batch's taxonomy.json was rewritten as v6, and CLAUDE.md was updated. Domains and buckets are unchanged.

| Change | Where | Records (events) |
|---|---|---|
| Lottery / Prize Fraud | Financial Fraud | 5 (5) |
| Tax / GST Fraud | Financial Fraud | 4 (4) |
| Virtual Kidnapping | Impersonation Fraud | 17 (13) |
| AI-Assisted Cyber Intrusion | Cyber Intrusion (new category) | 15 (14) |
| personality_rights_case = true | new field, after abuse_type | 49 (33) |

## AI-Assisted Cyber Intrusion
- B02-INC-021 · EV-0152 · Out of Scope · Threat actors ran Facebook ads and hijacked pages offering early access to 'Midjourney, Sora, ChatGPT-5, DALL-E' to spre
- B02-INC-030 · EV-0161 · Out of Scope · An unidentified hacker prompted Anthropic's Claude (and ChatGPT) in Spanish to find vulnerabilities, write exploits and 
- B02-INC-031 · EV-0162 · Out of Scope · Vercel disclosed unauthorised access to internal systems after a third-party AI tool (Context.ai) used by an employee wa
- B03-INC-084 · EV-0132 · Out of Scope · Google sued the Chinese 'Outsider Enterprise', which used Gemini to build 131 phishing kits, 9,000 fake sites and 2.5 mi
- B06-INC-102 · EV-0412 · Out of Scope · An IIT Kanpur/IIT Madras panel reportedly found AI tools including Anthropic's Claude were used to find vulnerabilities 
- B06-INC-103 · EV-0413 · Out of Scope · Bitdefender says Pakistan-aligned Transparent Tribe used AI coding tools to mass-produce malware implants against Indian
- B06-INC-110 · EV-0420 · Out of Scope · Iranian hackers reportedly used ChatGPT and Gemini to build malware, phishing and fake personas against US and Israeli t
- B06-INC-111 · EV-0421 · Out of Scope · Sysdig documented 'JadePuffer', an AI agent that autonomously breached a server, stole credentials, encrypted a database
- B06-INC-112 · EV-0422 · Out of Scope · Amazon said a lone attacker used commercial AI tools to compromise 600+ organisations' FortiGate firewalls in five weeks
- B06-INC-113 · EV-0423 · Out of Scope · Anthropic said Chinese state-sponsored hackers tricked Claude into automating cyber-espionage against about 30 organisat
- B07-INC-080 · EV-0421 · Out of Scope · Sysdig documented 'JadePuffer', an AI agent that autonomously breached a server, stole credentials, encrypted a database
- B07-INC-095 · EV-0495 · Out of Scope · Anthropic said criminals misused Claude to automate ransomware against 17 organisations and North Korean workers used it
- B07-INC-099 · EV-0499 · Out of Scope · Google sued a China-based 'Outsider Enterprise' that used Gemini to build phishing kits and 9,000 fake sites.
- B08-INC-129 · EV-0600 · Out of Scope · AI voice-phishing attacks targeted employees at Citadel, Two Sigma, Point72 and others.
- B15-INC-141 · EV-1132 · Out of Scope · The EvilTokens phishing service steals Microsoft 365 sessions and uses AI to pick fraud targets in compromised mailboxes

## Virtual Kidnapping
- B03-INC-035 · EV-0084 · AI-Aided Fraud · 'Cyber kidnapping' calls in Gujarat used AI-mimicked voices of children with fake police officers demanding Rs 1-5 lakh;
- B03-INC-057 · EV-0106 · AI-Aided Fraud · A fake cop told Laxmi Chand Chawla his nephew Kapil was held in a sexual assault case and put a cloned 'Kapil' on the li
- B04-INC-029 · EV-0174 · AI-Aided Fraud · When a 16-year-old Class 10 boy went missing and his family posted his photo online, extortionists made hours-long video
- B06-INC-011 · EV-0106 · AI-Aided Fraud · A fake cop told Laxmi Chand Chawla his nephew Kapil was held in a sexual assault case and put a cloned 'Kapil' on the li
- B06-INC-014 · EV-0334 · AI-Aided Fraud · A caller told 'Sarita Khanna' (name changed) of Khargone her 19-year-old daughter was kidnapped and played an AI clone o
- B06-INC-015 · EV-0335 · AI-Aided Fraud · 65-year-old Radha Devi of Delhi paid Rs 2 lakh by UPI after a call in an AI clone of her daughter's voice claimed she ha
- B06-INC-058 · EV-0378 · AI-Aided Fraud · A 16-year-old who lost nearly Rs 3 lakh on online games staged his own kidnapping with an AI image of himself bloodied a
- B07-INC-011 · EV-0378 · AI-Aided Fraud · A 16-year-old who lost nearly Rs 3 lakh on online games staged his own kidnapping with an AI image of himself bloodied a
- B08-INC-001 · EV-0174 · AI-Aided Fraud · When a 16-year-old Class 10 boy went missing and his family posted his photo online, extortionists made hours-long video
- B08-INC-085 · EV-0566 · AI-Aided Fraud · A scammer used an AI clone of electrical contractor Jaswant Singh Kalsi's US-based nephew's voice to claim a kidnapping 
- B08-INC-127 · EV-0598 · Out of Scope · Chinese state media exposed live AI deepfake video calls impersonating relatives, including a fake kidnapping call.
- B13-INC-082 · EV-0871 · AI-Aided Fraud · Fake Indian High Commission officials said a couple's London-based daughter was under 'digital arrest' and took Rs 75,00
- B14-INC-079 · EV-0973 · AI-Aided Fraud · A caller from an international number posing as police said a homemaker's son was held in a ganja case, put someone impe
- B14-INC-133 · EV-1026 · Out of Scope · AFP reports AI voice-clone kidnapping scams in the US, e.g. a Buffalo mother who heard her 'son' crying for help.
- B14-INC-134 · EV-1027 · Out of Scope · Scammers used an AI clone of an 86-year-old's granddaughter's voice and a fake lawyer to collect $6,000 in cash.
- B15-INC-101 · EV-1094 · AI-Aided Fraud · A caller said a teacher's daughter was caught in a sex racket and demanded Rs 1 lakh; she died of a heart attack.
- B15-INC-133 · EV-1027 · Out of Scope · Scammers used an AI clone of an 86-year-old's granddaughter's voice and a fake lawyer to collect $6,000 in cash.

## Lottery / Prize Fraud
- B03-INC-042 · EV-0091 · AI-Aided Fraud · CloudSEK found two fake Google Play apps impersonating the Kerala State Lotteries Directorate, with 1 million+ downloads
- B06-INC-046 · EV-0366 · AI-Aided Fraud · A fake Kaun Banega Crorepati page and caller told a 47-year-old homemaker she had won a Rs 8.5 lakh car; she paid Rs 1.1
- B06-INC-048 · EV-0368 · AI-Aided Fraud · Six men including two Nigerians posed online as foreign women promising gifts, then as airport officials demanding relea
- B06-INC-049 · EV-0369 · AI-Aided Fraud · Lottery emails using RBI Governor Raghuram Rajan's name and a fake RBI letterhead told recipients they had unclaimed 'UK
- B06-INC-050 · EV-0370 · AI-Aided Fraud · A 40-year-old woman paid Rs 42.7 lakh in 125 transactions after WhatsApp messages said she won Rs 1.3 crore in a 'KBC lu

## Tax / GST Fraud
- B06-INC-044 · EV-0364 · AI-Aided Fraud · Lucknow police busted a racket that used poor people's IDs to register 15+ bogus firms and sell fake GST input tax credi
- B06-INC-045 · EV-0365 · AI-Aided Fraud · DGGSTI busted a fake-GST-bill scam of about Rs 450 crore input tax credit (bills of Rs 2,500 crore) and a Jaipur gang is
- B07-INC-043 · EV-0457 · AI-Aided Fraud · An income-tax probe found restaurants (notably biryani outlets) suppressed about 27% of sales through billing software, 
- B07-INC-046 · EV-0460 · AI-Aided Fraud · CGST officials found shell firms issued Rs 650 crore of fake invoices enabling about Rs 110 crore of inadmissible input 

## personality_rights_case = true
- B01-INC-028 · EV-0028 · AI-Aided Fraud · Deepfake videos of finance educator Ankur Warikoo lured viewers into WhatsApp stock-tip groups and apps whose 
- B02-INC-011 · EV-0055 · AI Misinformation · Gautam Gambhir sued 16 parties in the Delhi High Court over AI deepfakes falsely showing him making statements
- B02-INC-012 · EV-0056 · AI Misinformation · Cricketer Abhishek Sharma sued in the Delhi High Court over an AI-altered photo of him and his manager circula
- B02-INC-013 · EV-0057 · AI Misinformation · The Bombay High Court granted Akshay Kumar interim protection and ordered takedowns of AI deepfakes and morphe
- B03-INC-005 · EV-0028 · AI-Aided Fraud · Delhi HC granted Ankur Warikoo a John Doe injunction against deepfakes promoting dubious WhatsApp stock-tip gr
- B03-INC-024 · EV-0073 · AI-Aided Fraud · Sadhguru sought Delhi HC protection against AI content using his name and face to push fake investment schemes
- B03-INC-026 · EV-0075 · AI-Aided Fraud · India TV's Rajat Sharma filed a Delhi HC PIL after AI voice-clone ads impersonating him (and other anchors) so
- B04-INC-014 · EV-0073 · AI-Aided Fraud · Sadhguru sought Delhi HC protection against AI content using his name and face to push fake investment schemes
- B04-INC-067 · EV-0210 · AI Misinformation · Shilpa Shetty sued 27 defendants (Meta, Google, X, MeitY, DoT and platforms) in the Bombay HC over AI replicas
- B04-INC-080 · EV-0223 · AI Misinformation · Congress MLA Sukhpal Singh Khaira sued Meta in a Chandigarh court over an allegedly AI-generated morphed video
- B05-INC-010 · EV-0073 · AI-Aided Fraud · Sadhguru sought Delhi HC protection against AI content using his name and face to push fake investment schemes
- B05-INC-037 · EV-0223 · AI Misinformation · Congress MLA Sukhpal Singh Khaira sued Meta in a Chandigarh court over an allegedly AI-generated morphed video
- B05-INC-045 · EV-0275 · AI Misinformation · Naga Chaitanya sued in the Delhi HC over deepfakes, AI-generated pornographic content and misuse of his person
- B05-INC-048 · EV-0278 · AI Misinformation · Shashi Tharoor sued in the Delhi HC over AI deepfake videos cloning his face and voice, including clips showin
- B05-INC-057 · EV-0287 · AI Misinformation · Mohanlal sued in the Delhi HC; his counsel said AI deepfakes were being made to body-shame him and misuse his 
- B05-INC-065 · EV-0295 · AI Misinformation · India coach Gautam Gambhir sued in the Delhi HC for Rs 2.5 crore over AI deepfakes and voice clones, including
- B05-INC-066 · EV-0296 · AI Misinformation · The Delhi HC granted Allu Arjun interim protection of his personality rights against AI deepfakes and fake bra
- B05-INC-067 · EV-0297 · AI Misinformation · The Delhi HC protected boAt co-founder Aman Gupta against fake accounts, AI-generated content, deepfakes and o
- B05-INC-068 · EV-0298 · AI Misinformation · The Delhi HC protected Ajay Devgn's personality rights and ordered removal of obscene AI deepfakes and false p
- B06-INC-065 · EV-0278 · AI Misinformation · Shashi Tharoor sued in the Delhi HC over AI deepfake videos cloning his face and voice, including clips showin
- B06-INC-071 · EV-0385 · AI Misinformation · Raghav Chadha sued in the Delhi HC over AI deepfakes, morphed videos and voice clones on YouTube, X and Instag
- B06-INC-072 · EV-0386 · AI Misinformation · Aishwarya Rai Bachchan won Delhi HC protection against AI deepfakes, morphing and commercial misuse of her ide
- B06-INC-073 · EV-0387 · AI Misinformation · The Delhi HC protected Tabu against AI deepfakes, face morphing and obscene manipulated content and ordered Go
- B06-INC-074 · EV-0388 · AI Misinformation · The Delhi HC upheld podcaster Raj Shamani's personality rights after deepfaked videos, cloned voiceovers and s
- B06-INC-091 · EV-0404 · AI Harassment & Abuse · The Delhi HC ordered Meta and X to remove AI-generated pornographic images of a social media influencer (ident
- B06-INC-115 · EV-0425 · Out of Scope · Labour MP Jess Asato sued xAI after Grok was used to make sexualised 'bikini' images of her.
- B07-INC-052 · EV-0055 · AI Misinformation · Gautam Gambhir sued 16 parties in the Delhi High Court over AI deepfakes falsely showing him making statements
- B07-INC-054 · EV-0275 · AI Misinformation · Naga Chaitanya sued in the Delhi HC over deepfakes, AI-generated pornographic content and misuse of his person
- B07-INC-056 · EV-0056 · AI Misinformation · Cricketer Abhishek Sharma sued in the Delhi High Court over an AI-altered photo of him and his manager circula
- B07-INC-064 · EV-0473 · AI Misinformation · The Delhi HC barred an hour-long AI film by Sambhawaami Studios on YouTube that replicated Akira Nandan (Pawan
- B07-INC-066 · EV-0475 · AI Misinformation · The Delhi HC protected Yuvraj Singh against AI deepfakes (including religiously insensitive and violent ones) 
- B07-INC-067 · EV-0476 · AI Misinformation · The Bombay HC granted Suniel Shetty an injunction against deepfake images and misuse of his name, image and vo
- B07-INC-068 · EV-0477 · AI Misinformation · The Bombay HC protected Asha Bhosle against AI voice-cloning tools and commercial misuse of her persona.
- B07-INC-069 · EV-0478 · AI Misinformation · The Delhi HC ordered platforms and AI tools to stop AI voice clones, deepfakes and merchandise using singer Ju
- B07-INC-070 · EV-0479 · AI Misinformation · The Delhi HC barred AI deepfakes and memes misusing preacher Aniruddhacharya's identity.
- B07-INC-071 · EV-0480 · AI Misinformation · In Arijit Singh v. Codible Ventures, the Bombay HC protected the singer against AI tools synthesising his voic
- B07-INC-072 · EV-0481 · AI Misinformation · The Delhi HC protected Anil Kapoor's personality rights after AI deepfakes and explicit videos misused his lik
- B07-INC-073 · EV-0482 · AI Misinformation · The Delhi HC ordered AI chatbot platforms and websites to remove deepfakes and stop using Sonakshi Sinha's nam
- B08-INC-101 · EV-0476 · AI Misinformation · The Bombay HC granted Suniel Shetty an injunction against deepfake images and misuse of his name, image and vo
- B08-INC-103 · EV-0278 · AI Misinformation · Shashi Tharoor sued in the Delhi HC over AI deepfake videos cloning his face and voice, including clips showin
- B08-INC-104 · EV-0055 · AI Misinformation · Gautam Gambhir sued 16 parties in the Delhi High Court over AI deepfakes falsely showing him making statements
- B08-INC-106 · EV-0582 · AI Misinformation · The Delhi HC protected Kajol against AI chatbots, morphed and pornographic content and unauthorised merchandis
- B08-INC-107 · EV-0583 · AI Misinformation · The Delhi HC ordered takedown of AI voice clones and content imitating singer Kumar Sanu.
- B10-INC-057 · EV-0297 · AI Misinformation · The Delhi HC protected boAt co-founder Aman Gupta against fake accounts, AI-generated content, deepfakes and o
- B10-INC-059 · EV-0473 · AI Misinformation · The Delhi HC barred an hour-long AI film by Sambhawaami Studios on YouTube that replicated Akira Nandan (Pawan
- B10-INC-060 · EV-0055 · AI Misinformation · Gautam Gambhir sued 16 parties in the Delhi High Court over AI deepfakes falsely showing him making statements
- B11-INC-130 · EV-0387 · AI Misinformation · The Delhi HC protected Tabu against AI deepfakes, face morphing and obscene manipulated content and ordered Go
- B14-INC-130 · EV-0055 · AI Misinformation · Gautam Gambhir sued 16 parties in the Delhi High Court over AI deepfakes falsely showing him making statements
- B14-INC-131 · EV-1024 · AI Misinformation · Delhi HC ordered Google to take down a fake YouTube channel using deepfake impersonations of news anchor Anjan

## Judgement calls
- Virtual Kidnapping covers claimed police detention of a relative ('son held in ganja case', 'daughter caught in a raid', 'daughter under digital arrest abroad') as well as kidnapping; the 'son caused an accident in Canada' call (EV-1052) and the 'techie accused of child abduction' digital arrest (EV-1093) were not included.
- 'Others' was replaced where the new type covers it (Tax / GST Fraud ×4 records; the self-staged AI kidnapping EV-0378).
- AI-Assisted Cyber Intrusion is recorded only where AI was used; non-AI APK/phishing frauds (EV-0179, EV-0817) are unchanged. All intrusion records stay Out of Scope.
- personality_rights_case is true for celebrity/influencer suits and court orders, including two fraud-ad suits (Ankur Warikoo, Sadhguru), Rajat Sharma's PIL, an influencer's NCII takedown order and UK MP Jess Asato's suit against xAI. Court cases about AI-fabricated citations, trademark suits (Google v. Outsider Enterprise, Akasa Air) and digital-arrest bail orders are not flagged.
- EV-0368 (gift-parcel 'customs fee' gang) was included under Lottery / Prize Fraud as originally proposed in batch 06.
