# Report: green_highlighted_url_extracted_batch_12_article_text.xlsx

## Counts
| Item | Count |
|---|---|
| Rows / `success` | 105 / 105 (status shows 1 timeout row, but its text was usable; 13173 is short but complete) |
| Articles removed | **2** (1 charts roundup, 1 land-title scam) |
| **Records in incidents.json** | **67** (26 merged with earlier events covering 61 articles; article 13144 split into two cases) |

| Top-level domain | Records | Breakdown |
|---|---|---|
| AI-Aided Fraud | 66 | AI-Suspected 64 · No-AI-Evidence 2 · AI-Confirmed-in-text 0 · AI-as-Lure 0 |
| Out of Scope | 1 | USA (FBI most-wanted Kalpesh Patel) |
| AI Misinformation / Public Panic / AI Harassment & Abuse / Unverified Claims | 0 | |

Victims: 62 of 78 victim objects have a stated gender and 29 a stated age. The event registry now has 819 events (41 new). This batch is digital arrests only. **No article states AI use**; the only AI matches were "Summarized by AI" site banners (13116, 13117, 13124), which were ignored.

## Taxonomy tree (v5, counts in this file)
```
AI-Aided Fraud (66)
├─ AI-Suspected (64): Authority Impersonation 64 (digital arrests)
│    New: Gujarat Rafiqul Alam network (Rs 1,071 cr, 1,758 accounts, crypto to China) · Rajkot 'Operation Mule Hunt' (20 held, Rs 2,500 cr transactions) ·
│    Hyderabad 'Operation Octopus 3.0' ghost-SIM network (66 held, Rs 101.87 cr) · Ahmedabad professor couple Rs 11.4 cr · Gurugram executive Rs 5.85 cr ·
│    Raipur Sonia Hanspal Rs 2.83 cr (49 days) · Lucknow Dr Ruchika Tandon Rs 2.8 cr · Noida Rs 2.10 cr · Goa Rohan Jhadav Rs 2.14 cr · Surat Rs 1.71 cr ·
│    Vizag couple Rs 1.5 cr · Machilipatnam Rs 1.43 cr · Bhubaneswar Rs 1.38 cr · Valsad Rs 1.11 cr · Pune PFI Rs 1 cr · Gandhinagar teacher Rs 99 lakh ·
│    Padma Bhushan scientist T Ramasamy Rs 57 lakh · Sydney NRI Rs 49 lakh · Eluru lawyer (11 held) · Bijnor mother of two (suicide) · Surat Amit Desai (attempt) ...
│    + merged Chakra-VI (9 articles), Rs 1.6 cr CBI AP-Telangana (5), Delhi Rs 23 cr Naresh Malhotra (5), Goa ED Rs 400 cr network (5), Munirka colonel (5),
│      Bengaluru Rs 24 cr (3), Canacona (3), Belagavi Saraf, Greater Kailash Rs 6.9 cr, Rohini Rs 10 cr, Taneja Rs 14.85 cr, Gandhinagar Rs 19.24 cr, ...
└─ No-AI-Evidence (2): Goa gas-bill APK malware (Rs 3.25 lakh) · Gurugram mule-account suppliers (fraud type not stated)
Out of Scope (1): Kalpesh Patel, US-based 'digital arrest' wire fraud on elderly Americans (FBI)
```

## Merges by event_id (26)
- **EV-0092 Operation Chakra-VI (9 articles):** 12875, 12886, 12899, 13013, 13014, 13080, 13104, 13117, 13130. The two arrested are named as B Naresh and Sanjib Saha.
- **EV-0359 CBI AP-Telangana Rs 1.6 cr (5):** 12879, 12881, 12882, 12887, 12888 · **EV-0254** Pulwama firm / Axis Bank charge sheet (13070)
- **EV-0762 Delhi Rs 23 cr (5):** 13045, 13086, 13097, 13106, 13109. These name the victim as Naresh Malhotra, 78, and report the CBI charge sheet against Sagnik Roy, the RBI ombudsman's Rs 1.31 cr award and the HC bail denial.
- **EV-0455 Goa ED network (5):** 13164, 13177, 13178, 13179, 13180 (two ED arrests; 330 complaints; losses above Rs 400 cr)
- **EV-0614 Munirka colonel (5):** 13024, 13071, 13078, 13079, 13089 (four account suppliers arrested)
- EV-0003 Bengaluru Rs 24 cr (13017, 13025, 13036) · EV-0615 Canacona (13087, 13163, 13176) · EV-0701 Chandigarh Rs 46 lakh (13060, 13123) · EV-0740 Maninagar (13124, 13125)
- EV-0504 Bhopal couple (12870) · EV-0613 Belagavi Saraf (13026) · EV-0728 Jalandhar Rs 2.07 cr (12878) · EV-0732 Bathinda (13041) · EV-0105 Greater Kailash (13042)
- EV-0673 Nagpur nurse (13058) · EV-0705 Bengaluru techie (13063) · EV-0610 Rohini Pakistan link (13108) · EV-0677 Pune Rs 10.75 cr (13116) · EV-0702 Ahmedabad Rs 1.43 cr (13129)
- EV-0113 Gandhinagar doctor Rs 19.24 cr (13144, part) · EV-0007 Taneja couple (13158) · EV-0626 Kottayam (13165, 13167) · EV-0630 Yamunanagar (13184)
- EV-0516 Rohini engineer Rs 10 cr (13090) · **EV-0110 Vadodara Rs 1.47 cr (13127; link to check)**

## Split
- **13144** (CBI takes over two Gujarat cases): Gandhinagar doctor (merged into EV-0113) · Ahmedabad retired professor and husband Rs 11.4 cr (new)

## Removed (2)
- 13020 (Hindu weekly charts roundup), 13175 (Goa land-title scam; not cyber or AI fraud)

## Ambiguous cases
1. **13127 → EV-0110:** a Gujarat 72-year-old losing Rs 1.47 crore matches Vadodara on amount and state, but the duration differs (28 vs 18 days). Merged with a note.
2. **13045 group → EV-0762:** B11's 12866 ("Delhi's biggest digital arrest case, Rs 23 crore", NGO accounts) gives no victim name; these articles name Naresh Malhotra and a trust account. Merged as the same case.
3. **13144 Ahmedabad couple Rs 11.4 cr** may be the case behind EV-0669 (gang bust that "extorted Rs 11.42 crore"), but that article lists victims elsewhere. Kept separate, with a note.
4. **13174 Goa Rohan Jhadav (25, Nashik)** vs **13116 Pune influencer Rohan Jadhav**: similar names, different cities and cases. Not merged.
5. **13157/13160/13161 Sydney NRI:** victim lives abroad, but the complaint is in Ahmedabad and Indian numbers and accounts were used, so in scope.
6. **13153 Kalpesh Patel:** Gujarat-born, but he lives in the US and the victims are Americans, so Out of Scope.
7. **13186 Gurugram:** the article only says "digital scam", so it is No-AI-Evidence Banking & Payment, not a digital arrest.
8. **13150 Rajkot Mule Hunt:** the accounts were used for digital arrests and other frauds; coded as a digital arrest. Rs 2,500 crore is suspicious transactions, not losses.

## Proposed new second-level categories
None new. Still open from earlier batches: Lottery / Prize Fraud, Virtual Kidnapping, Tax / GST Fraud, AI-Assisted Cyber Intrusion, Personality-rights court-action flag.
