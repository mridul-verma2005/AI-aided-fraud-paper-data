# yellow_batch_22 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_22_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 50. 44 are identical to yellow_batch_01 rows (same row_id, URL and text); 6 new rows (7, 18, 53, 74, 127, 160) failed fetch (http_404 / http_403 / block page) and are kept as no_text.
- Stage 2: 12 hits carry batch 01 labels; 1 new hit (22, `sextortion`) labelled NOT_AI.
- Eligible for extraction: 3 rows (2 and 117 AI_SUSPECTED, 164 AI_LURE). UNCLEAR: 65 (still pending since batch 01).
- Not extracted: 9 NOT_AI; 31 no-hit (recall sample 30: no suspected-AI pattern); 6 no_text.

## Advisory / non-incident articles removed: 0

## Output: 0 records (no merges, no new events)
| Row | Already recorded as | Reason not re-added |
|---|---|---|
| 2 | EV-0001 (latest record supersedes Y01-001) | same article already a source |
| 117 | EV-0002 (Y01-002) | same article already a source |
| 164 | EV-0003 (latest record supersedes Y01-003) | same article already a source |

- `incidents.json` is an empty list. Event registry unchanged at 183 events.

## Ambiguities to check
1. **Row 22** (Chhattisgarh SIM retailers' Aadhaar e-KYC misuse) looks like the same case as EV-0154 (Y10-016), a non-AI record; not extracted because it is NOT_AI.
2. **Row 65** remains UNCLEAR, awaiting your decision.

## Proposed taxonomy changes
- None.
