# yellow_batch_08_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_08_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 08 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`; `blackmail*` applies to this batch for the first time. The original `output_json/yellow_batch_08/` is unchanged.

## Input
- Rows: 171. Hits: 28; 7 new.
- New hits sent to extraction: 3 AI_SUSPECTED (5622, 5647, 5732).
- UNCLEAR: 5542 (Bhopal job-offer sex racket with photo blackmail; same question as 1504) — awaiting your decision.
- New hits not extracted: 3 NOT_AI (5428, 5522, 6263).
- Recall: 29 of 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 3 records (3 new events EV-0210 to EV-0212), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y08R-001 (EV-0210) | fake ID | Adilabad fake Aadhaar/residence certificates sold for CISF/army jobs (5622) |
| Y08R-002 (EV-0211) | fake ID | UP constable exam impersonators with forged Aadhaar (5647) |
| Y08R-003 (EV-0212) | fake ID | Noida GST fraud, 250 fake firms on forged Aadhaar; 29 held (5732, 2023) |

## Merges
- None.

## Ambiguities to check
1. All three are document-forgery cases with complicit buyers or government victims; kept only under the fake-ID rule.
2. **Y08R-002** combines two impersonation cases from one exam-day round-up.

## Proposed taxonomy changes
- None.
