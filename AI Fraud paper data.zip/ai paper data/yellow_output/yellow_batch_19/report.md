# yellow_batch_19 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_19_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 181 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 4 rows (2 AI_INVOLVED, 2 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 3 NOT_AI; 174 no-hit (recall sample: 1 of 30 fake-ID pattern, row 15962; not extracted because the term is not on the keyword list).

## Advisory / non-incident articles removed: 0

## Output: 4 records (1 merge, 3 new events EV-0176 to EV-0178), all AI-Aided Fraud
| Bucket | Incident |
|---|---|
| AI-Confirmed-in-text | ED chargesheets WinZO for rigging real-money games with bots and AI; users lost ~Rs 734 cr (15314, new EV-0176) |
| AI-Confirmed-in-text | Nilgiris woman, 45, lost Rs 25 lakh to UK "marriage" suitor using AI and fake documents (15820, new EV-0177) |
| AI-Suspected | Indore student: fake refund link, Rs 2.99 lakh withdrawn, then sextortion over claimed obscene photos (15650, new EV-0178) |
| AI-Suspected | Anand Kumar 500-women romance/blackmail case merged into EV-0143 (15443) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0143 Anand Kumar | Y19-001 | Y-15443 (arrest date 2026-03-22, seized items) | Y16-001 |

## Ambiguities to check
1. **WinZO (15314)**: typed Fake Platform Fraud (rigged platform); these are ED allegations in a PMLA complaint, not yet tried. victim_count left null.
2. **Nilgiris (15820)**: the article doesn't say what the AI was used for.
3. **Indore (15650)**: unclear whether the Rs 30,000 extortion payment is part of the Rs 2.99 lakh figure.

## Proposed taxonomy changes
- New ai_capabilities label **"AI Game Bots"** (WinZO). No existing label fits; tell me if you'd rather reuse one (e.g. "AI Apps (unspecified)").
