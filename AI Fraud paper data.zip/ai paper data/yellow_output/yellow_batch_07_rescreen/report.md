# yellow_batch_07_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_07_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 07 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`; `blackmail*` applies to this batch for the first time. The original `output_json/yellow_batch_07/` is unchanged.

## Input
- Rows: 177. Hits: 19; 6 new.
- New hits sent to extraction: 2 AI_SUSPECTED (4935, 5228). No UNCLEAR rows.
- New hits not extracted: 4 NOT_AI (4890, 4955, 5005, 5360).
- Recall: 28 of 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 2 records (2 new events EV-0208, EV-0209), both AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y07R-001 (EV-0208) | digital arrest | Gujarat fake-firm mule-account racket, Rs 2.9 cr; accused linked to a Rs 38 lakh digital arrest (4935) |
| Y07R-002 (EV-0209) | sextortion | Chennai techie's fake-HR nude-photo blackmail of ~600 women (5228, 2019) |

## Merges
- None.

## Ambiguities to check
1. **Y07R-001** is mainly a mule-account case; kept because one accused is tied to a specific digital-arrest fraud (as with Y21-004 Noida).

## Proposed taxonomy changes
- None.
