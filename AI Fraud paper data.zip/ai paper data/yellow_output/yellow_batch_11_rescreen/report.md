# yellow_batch_11_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_11_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 11 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_11/` is unchanged.

## Input
- Rows: 172. Hits: 35; 29 new.
- New hits sent to extraction: 13 AI_SUSPECTED. No UNCLEAR rows.
- New hits not extracted: 16 NOT_AI (monthly police round-ups, statistics, mule-account crackdowns, generic SIM-swap explainers, sidebars).
- Recall: 23 of 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 11 records (2 merges, 9 new events EV-0225 to EV-0233), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y11R-001 (EV-0159) | merge | MP Kalyan Banerjee Rs 56.39 lakh forged-KYC account takeover (8999) |
| Y11R-002 (EV-0202) | merge | Retired IAF radiologist's 27-day digital arrest; 7 held (9176) |
| Y11R-003 (EV-0225) | digital arrest | Chandigarh resident Rs 85 lakh, "Priority Innocence Certificate" (8998) |
| Y11R-004 (EV-0226) | digital arrest | Visakhapatnam retiree Rs 1.46 cr, fake ED (9017) |
| Y11R-005 (EV-0227) | digital arrest | Gurugram virtual SIM box for China-based callers (9066) |
| Y11R-006 (EV-0228) | fake ID | Jamtara APK modules; forged ID card sent to senior citizen (8981) |
| Y11R-007 (EV-0229) | fake ID | Devarakonda SBI insider fraud, Rs 2.66 cr (9127) |
| Y11R-008 (EV-0230) | fake ID | Assam SIM retailers issuing SIMs on fake IDs (9258, 2023) |
| Y11R-009 (EV-0231) | fake ID | Surat 165-account racket for overseas gangs (9318 + 9356 + 9350) |
| Y11R-010 (EV-0232) | fake ID | Ahmedabad forged-Aadhaar account racket, 11 held (9347) |
| Y11R-011 (EV-0233) | digital arrest | Noida eye specialist Rs 45 lakh, Skype "digital surveillance" (9396) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0159 Kalyan Banerjee | Y11R-001 | Y-8999 (KYC change date, exact loss) | Y11-001 |
| EV-0202 Gwalior radiologist | Y11R-002 | Y-9176 (3 more arrests, victim name/age) | Y05R-003 |

## Ambiguities to check
1. Police monthly round-ups listing digital-arrest counts (9229-9253, 9381/9382) were left NOT_AI for lack of case detail.
2. **Y11R-005/008/009/010** are infrastructure or mule-account cases without a specific victim.
3. **Y11R-011** records one case from a five-victim feature.

## Proposed taxonomy changes
- None.
