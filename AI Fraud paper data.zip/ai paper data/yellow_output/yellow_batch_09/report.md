# yellow_batch_09 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_09_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02, with "blackmail*" added to the keyword list on approval)

## Input
- Rows: 178 (all success; 0 no_text).
- **Truncated text: row 7237 is exactly 32,767 characters** (Washington Blade feature on LGBTQ dating-app scams); later cases in it are cut off.
- Keyword list: original 16 terms + `sextort*` + `blackmail*` (new); GujaratSamachar "Summarized by AI" header stripped. The re-screen raised hits from 26 to 30; new hits 7016, 7216, 7295 labelled AI_SUSPECTED (sextortion), 7296 NOT_AI ("emotional blackmail" only).
- `recall_check.csv` reflects the sample drawn before "blackmail" was added (7016 and 7216 were the misses that prompted it).
- Sent to extraction: 16 rows (8 AI_INVOLVED, 5 AI_SUSPECTED, 3 AI_LURE).
- Not extracted: 13 NOT_AI; 148 no-hit; **UNCLEAR row 6887 (same Upendra/Priyanka case as batch 07 UNCLEAR 4995) waiting for your decision.**

## Advisory / non-incident articles removed: 1
| Row | Reason |
|---|---|
| 7024 | News18 explainer on Cambodia's scam industry |

## Output: 14 records (3 merges, 11 new events EV-0134 to EV-0144)
| Domain | Count |
|---|---|
| AI-Aided Fraud | 11 |
| Unverified Claims | 1 (Khandwa water award AI photos, 7442) |
| Out of Scope | 2 (Shreya Datta deepfake romance scam, USA, 7049; Europol Operation Borrelli, Spain, 7060) |

| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 3 | Rent Boyfriend merged (EV-0035); Sonbhadra AI-photo blackmail (6968); Jasdan farmer AI-Hindi gift-parcel scam (7377+7378) |
| AI-Suspected | 4 | Sextortion rule: Shahdara (6963), Vizag (7216), Anand Kumar 500 women (7016), Manikonda (7295) |
| AI-as-Lure | 3 | Retired IAS merged (EV-0024), TRD-NFT merged (EV-0003), Margao "AI Trading" platform (7722) |
| No-AI-Evidence | 1 | Mumbai gay man's fake-customs romance scam (lead case of 7237) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0035 Rent Boyfriend | Y09-001 | Y-7107 | Y04-006 |
| EV-0024 retired IAS officer | Y09-002 | Y-7717 | Y04-005 |
| EV-0003 TRD-NFT | Y09-003 | Y-7721 | Y01-003 |
| New: Jasdan farmer | Y09-006 | Y-7377 + Y-7378 | — |

## Ambiguities to check
1. **Y-7237 (truncated feature)**: sent for a one-line Ghaziabad sextortion mention (Rs 1.4 lakh), not recorded under the feature rule; the lead Mumbai case is recorded as No-AI-Evidence.
2. **Khandwa (7442)**: 20 AI photos on the awareness portal are admitted; whether they helped win the award is disputed, so Unverified Claims (claimed type Public-Works / Government Reporting Fraud).
3. **Jasdan farmer (7377+7378)**: "gift with fees" typed as Lottery / Prize Fraud; nationality details conflict between the two reports.
4. **Shahdara (6963)** vs batch 05 EV-0089: both Mewat/Deeg video-call sextortion rings with a mastermind named Armaan/Arman; different dates and ages, link to check.
5. **Europol (7060)**: AI mentions are trend statements, not tied to this case.

## Proposed taxonomy changes
- None. No new ai_capabilities labels.
- Batches 05-08 were screened without `blackmail*` (and 01-04 without `sextort*` too); a re-screen would likely add more AI-Suspected sextortion rows.
