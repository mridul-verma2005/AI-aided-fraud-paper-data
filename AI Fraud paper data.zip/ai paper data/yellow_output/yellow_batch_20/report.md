# yellow_batch_20 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_20_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 190 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 0 rows. No UNCLEAR rows.
- Not extracted: 1 NOT_AI (16210, "morph" matched the alias "Dr. Morphine"); 189 no-hit (recall sample: 1 of 30 digital-arrest pattern, row 16243; not extracted because the term is not on the keyword list).

## Advisory / non-incident articles removed: 0

## Output: 0 records (no merges, no new events)
- `incidents.json` is an empty list. Event registry unchanged at 178 events.

## Ambiguities to check
- None.

## Proposed taxonomy changes
- None.
