# yellow_batch_10 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_10_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 167 (166 success; 1 no_text: row 8841, status "timeout", title = Borkotoky Rs 34.33 cr case, i.e. EV-0001; kept in screen.csv). Truncated texts: none.
- Sent to extraction: 16 rows (2 AI_INVOLVED, 10 AI_SUSPECTED, 4 AI_LURE).
- Not extracted: 10 NOT_AI; 139 no-hit (incl. 14 that mention "digital arrest"; see below); **UNCLEAR row 8214 (Upendra/Priyanka, same as 4995/6887) waiting for your decision.**

## Advisory / non-incident articles removed: 1
| Row | Reason |
|---|---|
| 8329 | UK phishing/vishing trend report |

## Output: 20 records (6 merges into earlier events, 14 new events EV-0145 to EV-0158), all AI-Aided Fraud
| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 1 | Rent Boyfriend merged (EV-0035) |
| AI-Suspected | 12 | Sextortion rule: Narela (8104), Santacruz (8199), Goregaon (8230), Banjara Hills (8261), CISF official (8266), Asifnagar (8280), Gurugram attempt (8306), Gariaband morphed video (8880), Nagpur minor (8303); digital-arrest rule: TN/Delhi SIM-box network (8268), LB Nagar merged (EV-0126); Borkotoky merged (EV-0001) |
| AI-as-Lure | 4 | TRD-NFT merged (EV-0003), Kukatpally merged (EV-0125), Udupi "AI-based trading" (7763), Trimulgherry "AI-driven mutual funds" (7821) |
| No-AI-Evidence | 3 | Ramachandrapuram merged (EV-0127); KBC prize call and SIM-agent biometric duplication split from 8880 |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0003 TRD-NFT | Y10-001 | Y-7756 | Y09-003 |
| EV-0001 Borkotoky | Y10-002 | Y-8835 (and no_text Y-8841 noted) | Y06-001 |
| EV-0035 Rent Boyfriend | Y10-003 | Y-8303 (24 complaints, Rs 3.5 lakh) | Y09-001 |
| EV-0125 / EV-0126 / EV-0127 Hyderabad seniors | Y10-004 / 005 / 006 | Y-7829 | Y06-032 / 033 / 034 |

Splits: Y-8303 (merge + Nagpur minor), Y-8880 (3 records).

## Ambiguities to check
1. **Sextortion-only AI-Suspected records (9)**: none mention AI; 8266 and 8880 involve edited/morphed clips not called AI.
2. **Nagpur minor (8303)**: threats with private photos but no money stated; recorded as Sextortion.
3. **SIM-agent biometric duplication (8880)**: typed Identity Theft + Document & Credential Forgery, No-AI.
4. **QuantsAIS (7744)**: left NOT_AI as screened (AI only in an app name, no AI claim); you did not rule on the app-name question.

## Screening note (not applied)
- 14 no-hit rows in this batch mention "digital arrest" (7729, 7737, 8091, 8139, 8163, 8183, 8202, 8679, 8786, 8816, 8821, 8840, 8843, 8866); three were confirmed digital-arrest cases in the recall sample. They are not extracted because the keyword was not added.

## Proposed taxonomy changes
- None. No new ai_capabilities labels.
