# yellow_batch_14 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_14_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 103 (all success; 0 no_text). Truncated texts: none.
- No article in this batch mentions AI; all 3 hits came from "sextortion"/"blackmail".
- Sent to extraction: 2 rows (both AI_SUSPECTED, same event). No UNCLEAR rows.
- Not extracted: 1 NOT_AI; 100 no-hit.

## Advisory / non-incident articles removed: 0

## Output: 1 record (new event EV-0168), AI-Aided Fraud
| Bucket | Incident |
|---|---|
| AI-Suspected | Mawkyrwat (Meghalaya) woman died by suicide after blackmail with private photos/videos; Sachin Nishad (22, UP) arrested in Surat (Y-10742 + Y-10739) |

## Ambiguities to check
1. AI-Suspected only under the sextortion rule; the accused's demands are not specified (no money stated).
2. The two reports differ on the complainant (sister vs brother).

## Proposed taxonomy changes
- None.
