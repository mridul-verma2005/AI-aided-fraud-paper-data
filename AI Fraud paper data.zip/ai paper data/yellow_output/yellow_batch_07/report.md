# yellow_batch_07 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_07_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02)

## Input
- Rows: 177 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 4 rows (2 AI_INVOLVED, 2 AI_LURE).
- Not extracted: 19 NOT_AI (12 of them only the GujaratSamachar "Summarized by AI" header); 153 no-hit; **UNCLEAR row 4995 (Upendra/Priyanka WhatsApp hijack + AI voice-dub remark) waiting for your decision.**

## Advisory / non-incident articles removed: 1
| Row | Reason |
|---|---|
| 4984 | I4C general warning on deepfake investment ads using the PM's and ministers' images; no specific ad |

## Output: 3 records (1 merge, 2 new events EV-0128, EV-0129)
| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 1 | Rajasthan youths trafficked to Cambodia and trained with AI voice software (5184) |
| AI-as-Lure | 2 | FM-speech "AI trading" mule network merged (EV-0114), fake "DAIWA SECURITIES AI Smart Demat" platform (5097) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0114 A. Srinivasan / Delhi mule network | Y07-001 | Y-4900 (names the 11 accused; Cambodia link) | Y06-021 |

## Links to check
- Recall row Y-5031 (Interpol notice for Lavish Chaudhary, Rs 3,200 cr) relates to the QFX/BotBro campaign EV-0020 but has no AI mention and was not extracted.
- Y-5184 (Cambodia scam centres) is similar to other trafficking records (EV-0034, EV-0081); no shared names.

## Ambiguities to check
1. **Y-5097**: AI-as-Lure only through the platform name; it also uses a real brokerage brand (Daiwa).
2. **Y-5184**: AI evidence is second-hand (embassy officials via police).

## Proposed taxonomy changes
- No new ai_capabilities labels (Y-5184 uses the existing Voice Cloning label). Running total: 21.
- Screening: strip the GujaratSamachar "Summarized by AI; it may make mistakes" header before the keyword search (caused 12 of 24 hits this batch).
