# yellow_batch_05 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_05_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02, with "sextort*" added to the keyword list)

## Input
- Rows: 173 (all success; 0 no_text). Truncated texts: none.
- Keyword list: original 16 terms + `sextort*` (added on approval). The re-screen raised hits from 38 to 48; the 10 new hits (3699, 3700, 3705, 3706, 3707, 3713, 3714, 3715, 3716, 3877) were labelled AI_SUSPECTED under the sextortion rule.
- `recall_check.csv` reflects the sample drawn **before** the term was added; two sampled rows (3706, 3707) are now hits.
- Sent to extraction: 32 rows (15 AI_INVOLVED, 15 AI_SUSPECTED, 2 AI_LURE).
- Not extracted: 15 NOT_AI; 125 no-hit; **UNCLEAR row 3870 (Bhagwant Mann forensic-report case) waiting for your decision.**

## Advisory / non-incident articles removed: 3
| Row | Reason |
|---|---|
| 3234 | Guardian global exam-protest trend piece (AI cheating abroad; India only for a paper leak) |
| 3806 | SEBI Boss Scam warning |
| 3759 | Newschecker FedEx-scam explainer; cases are pseudonymous attempts with no stated loss |

## Output: 32 records (2 merges, 30 new events EV-0069 to EV-0098)
| Domain | Count |
|---|---|
| AI-Aided Fraud | 29 |
| AI Harassment & Abuse | 1 (yoga guru's AI-morphed nudes, 3115; Non-Consensual Intimate Deepfake) |
| AI Misinformation | 1 (Madhavan shared AI Ronaldo video, 3781) |
| Out of Scope | 1 (Guernsey teen AI-image sextortion, 3711) |

| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 9 | Fake PSI merged (EV-0027), 126 AI-photo religious-stay sites (3095), Aadhaar AI-video biometric loan (3110), AI-ID tender scam (3112), fake astrologer sextortion with AI-edited images (3124), Mohali AI-video extortion (3564), AI-edited co-pilot photos (3589), phishing videos with AI audio (3841), Myanmar trafficking syndicate with AI videos (3851) |
| AI-Suspected | 13 | Sextortion rule: 3701, 3718, 3881, 3699, 3700, 3705-07, 3713, 3714 (x2), 3715, 3716, 3877; fake-ID rule: MP exam Aadhaar photo swap (3387) |
| AI-as-Lure | 2 | Saharanpur merged (EV-0048), Goa BotBro complaint (3057) |
| No-AI-Evidence | 5 | Split-off cases: Shahdara trading (3110), Bengaluru matrimonial trading and Horamavu dating agency and Chennai Grindr gang (3718), Nuh fake debit SMS (3713) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0027 fake PSI Panchal | Y05-001 | Y-3055, Y-3105 | Y02-011 |
| EV-0048 Saharanpur "AI-enabled platform" | Y05-002 | Y-3203 | Y04-007 |
| New: J&K cricketer sextortion | Y05-025 | Y-3705, Y-3706, Y-3707 | — |

Splits: Y-3110 (2), Y-3718 (4), Y-3713 (2), Y-3714 (2).

## Links to check (not merged)
1. **Y-3110 (AI-video Aadhaar/DigiLocker loan, Ahmedabad, four arrested) ↔ batch 01 UNCLEAR Y-65** (Ahmedabad Aadhaar/DigiLocker misuse, four arrested). Very likely the same case; if you resolve Y-65 as AI_INVOLVED it can be merged into EV-0071.
2. **Y-3124 (accused Rajnish Govindlal Bhargav, Bikaner) ↔ batch 04 recall miss Y-2829** ("love guru" Rajnish Bhargava, 23, Bikaner). Likely the same racket; Y-2829 was never labelled.
3. **Y-3095 (126 fake religious sites) ↔ batch 04 no_text Y-2651** (same headline, text not fetched).
4. **Y-3057 Goa BotBro ↔ EV-0020** QFX/BotBro campaign (and Assam EV-0021, Dehradun EV-0022).
5. **Y-3714**: two Pune suicides two days apart may involve the same gang.

## Ambiguities to check
1. **Sextortion-only AI-Suspected records (13)**: none mention AI. Y-3881 describes face transposition into porn clips (labelled "Face Swap (suspected)").
2. **Y-3124**: AI evidence is the officials' description ("AI-edited imagery"), not a specific tool.
3. **Y-3564**: victim was in Canada but perpetrators were in Mohali, so in scope.
4. **Y-3841**: specific-ad rule; AI evidence from detector tools only.
5. **Y-3387**: fake-ID rule applied to Aadhaar photo tampering for exam proxies.

## Proposed taxonomy changes
- None to the second level.
- New ai_capabilities labels: AI-Generated Audio (3841), Face Swap (suspected) (3881). Running total: 19.
- Earlier batches (01-04) were screened without `sextort*`; re-screening them would likely add more AI-Suspected sextortion rows.
