# yellow_batch_25_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_25_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits; labels reused from `yellow_batch_01_rescreen`), `recall_check.csv`
The original `output_json/yellow_batch_25/` is unchanged.

## Input
- Rows: 50 (42 identical to batch 01; 8 no_text). Hits: 9; 1 new (680), already labelled in the batch 01 re-screen.
- Recall: 29 of 30 original sample rows still no-hit; no suspected misses (former miss 680 now caught).

## Output: 0 records (no merges, no new events)
| Row | Already recorded as |
|---|---|
| 680 | EV-0186 (Y01R-003) |

- `incidents.json` is an empty list. Event registry unchanged at 291 events.

## Proposed taxonomy changes
- None.
