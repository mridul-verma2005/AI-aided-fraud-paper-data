# yellow_batch_22_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_22_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits; labels reused from `yellow_batch_01_rescreen`), `recall_check.csv`
The original `output_json/yellow_batch_22/` is unchanged.

## Input
- Rows: 50 (44 identical to batch 01; 6 no_text). Hits: 19; 6 new, all batch 01 rows already labelled in the batch 01 re-screen.
- Eligible: 73, 165, 173 (AI_SUSPECTED). NOT_AI: 11, 134, 162.
- Recall: 24 of 30 original sample rows still no-hit; no suspected misses.

## Output: 0 records (no merges, no new events)
| Row | Already recorded as |
|---|---|
| 73 | EV-0184 (Y01R-001) |
| 165, 173 | EV-0189 (Y01R-006) |

- `incidents.json` is an empty list. Event registry unchanged at 291 events.

## Proposed taxonomy changes
- None.
