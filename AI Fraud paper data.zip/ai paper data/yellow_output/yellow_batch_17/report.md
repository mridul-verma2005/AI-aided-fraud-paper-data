# yellow_batch_17 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_17_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 168 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 3 rows (1 AI_INVOLVED, 2 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 0 NOT_AI; 165 no-hit.

## Advisory / non-incident articles removed: 1
| Row | Reason |
|---|---|
| 12310 | CBI advisory on fake "WhatsApp-CBI" scams using AI-generated summons and deepfake voices/videos; no specific case |

## Output: 2 records (2 new events EV-0173, EV-0174; no merges), both AI-Aided Fraud / AI-Suspected
| Incident | Basis |
|---|---|
| Deeg police arrest 55 for impersonating acquaintances on WhatsApp calls, sextortion and fake-job scams, ~Rs 3.10 cr (11986) | voice-impersonation and sextortion rules |
| Puttur man lost Rs 40 lakh to digital-arrest video call; two Belagavi mule-account suppliers to a Jamtara gang arrested (12702) | digital-arrest rule |

## Links to check
- EV-0173 (Deeg) with other Deeg/Mewat sextortion events: EV-0089, EV-0135, EV-0167.

## Ambiguities to check
1. Both records rest only on the suspected-AI pattern rules; no AI stated.
2. EV-0173 is an aggregate police operation (55 arrests, 91 complaints), recorded as one event.

## Proposed taxonomy changes
- None.
