# yellow_batch_02_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_02_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 02 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`; `sextort*` and `blackmail*` apply to this batch for the first time. The original `output_json/yellow_batch_02/` is unchanged.

## Input
- Rows: 165. Hits: 59; 8 new (3 from the new terms, 5 from sextort*/blackmail*).
- New hits sent to extraction: 3 AI_SUSPECTED (1046, 1123, 1593).
- UNCLEAR: 1504 (ex-MLA Rega Kantha Rao FIR; private-photo blackmail within a relationship) — awaiting your decision.
- New hits not extracted: 4 NOT_AI (846, 954, 983, 1565).
- Recall: all 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 3 records (3 new events EV-0190 to EV-0192), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y02R-001 (EV-0190) | fake ID | Kota WFH job scam, Rs 2 cr from 8,500 people; mastermind used fake Aadhaar cards (1046) |
| Y02R-002 (EV-0191) | digital arrest | Goa villa cyber-fraud centre, 12 held, ~Rs 500 cr transactions (1123) |
| Y02R-003 (EV-0192) | fake ID | Sambhal fake UIDAI/Passport Seva sites, 1,500+ Aadhaar records altered (1593) |

## Merges
- None.

## Ambiguities to check
1. **Y02R-001**: fake Aadhaar used only to hide the accused's identity, not on victims.
2. **Y02R-002**: Rs 500 cr is transactions under scrutiny; amount_lost left null.

## Proposed taxonomy changes
- None.
