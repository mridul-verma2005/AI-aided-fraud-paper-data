# yellow_batch_15_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_15_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 15 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_15/` is unchanged.

## Input
- Rows: 167. Hits: 34; 27 new.
- New hits sent to extraction: 13 AI_SUSPECTED. No UNCLEAR rows.
- New hits not extracted: 14 NOT_AI (round-ups, mule suppliers, trafficking, online-persona "fake IDs", a bail order without fraud type).
- Recall: 23 of 30 original sample rows still no-hit; 1 remaining suspected miss (11134, copy of the Operation Octopus 3.0 ghost-SIM case already hit as 11165).

## Advisory / non-incident articles removed: 0

## Output: 13 records (1 merge, 12 new events EV-0254 to EV-0265), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y15R-001 (EV-0222) | merge | ED Rs 260 cr global fraud raids (11269) |
| Y15R-002 (EV-0254) | digital arrest | Alwar woman, 76, Rs 1.25 cr (11009) |
| Y15R-003 (EV-0255) | digital arrest | Kapra retiree, 71, Rs 1.17 cr (11147) |
| Y15R-004 (EV-0256) | digital arrest | Kashipur resident Rs 45 lakh; Lucknow arrest (11251) |
| Y15R-005 (EV-0257) | digital arrest | Bhubaneswar Rs 1.06 cr; six held (10888) |
| Y15R-006 (EV-0258) | digital arrest | Delhi Crime Branch syndicate raids; Rs 5 cr USDT (10941) |
| Y15R-007 (EV-0259) | digital arrest | Malkajgiri couple Rs 71.25 lakh, fake CBI (11123) |
| Y15R-008 (EV-0260) | digital arrest | Ameenpur retired teacher Rs 25 lakh, fake ATS (11143) |
| Y15R-009 (EV-0261) | digital arrest | Malkajgiri victim Rs 7.80 cr, fake Data Protection Board (11152) |
| Y15R-010 (EV-0262) | digital arrest | Delhi elderly couple Rs 20 lakh (11192) |
| Y15R-011 (EV-0263) | digital arrest | 11 Indians arrested in Nepal (11191) |
| Y15R-012 (EV-0264) | fake ID | "DITIGAMAX" fake trading app kingpin (11248) |
| Y15R-013 (EV-0265) | fake ID | Fake HDFC Securities IPO scam, Rs 1.36 cr (11258) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0222 ED Rs 260 cr fraud | Y15R-001 | Y-11269 | Y10R-005 |

## Ambiguities to check
1. Y15R-005, 007, 008, 009, 010 each record one case from multi-case round-ups.
2. **Y15R-011**: the Mangaluru complainant's case type is not stated; the network ran digital-arrest frauds.
3. **Y15R-012/013** qualify only under the broad fake-ID rule.

## Proposed taxonomy changes
- None.
