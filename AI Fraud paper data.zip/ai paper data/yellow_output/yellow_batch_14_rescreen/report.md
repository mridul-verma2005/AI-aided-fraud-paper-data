# yellow_batch_14_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_14_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 14 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_14/` is unchanged.

## Input
- Rows: 103. Hits: 8; 5 new.
- New hits sent to extraction: 5 AI_SUSPECTED (10764, 10797, 10799, 10803, 10839). No UNCLEAR or NOT_AI new hits.
- Recall: 27 of 30 original sample rows still no-hit; 1 remaining suspected miss (10828, Odisha Rs 1.38 cr fake Mumbai cyber officers — likely EV-0240 — without the phrase "digital arrest").

## Advisory / non-incident articles removed: 0

## Output: 3 records (1 merge, 2 new events EV-0252, EV-0253), all AI-Aided Fraud / AI-Suspected
| Record | Incident |
|---|---|
| Y14R-001 (EV-0227) | Gurugram virtual SIM box (10797 + 10799 + 10803) — merge |
| Y14R-002 (EV-0252) | Varanasi Operation Vajra forged-Aadhaar account gang (10764) |
| Y14R-003 (EV-0253) | Bhubaneswar retired professor Rs 2.45 cr; Rs 1.10 cr recovered (10839) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0227 Gurugram SIM box | Y14R-001 | Y-10797, Y-10799, Y-10803 | Y11R-005 |

## Ambiguities to check
- None new.

## Proposed taxonomy changes
- None.
