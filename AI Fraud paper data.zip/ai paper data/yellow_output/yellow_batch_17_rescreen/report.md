# yellow_batch_17_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_17_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 17 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_17/` is unchanged.

## Input
- Rows: 168. Hits: 24; 21 new.
- New hits sent to extraction: 14 AI_SUSPECTED. No UNCLEAR rows.
- New hits not extracted: 7 NOT_AI (statistics, trafficking, mule crackdowns, share-trading ring, fake trading app, chairman WhatsApp-profile impersonation).
- Recall: 29 of 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 13 records (2 merges, 11 new events EV-0270 to EV-0280), all AI-Aided Fraud / AI-Suspected
| Record | Incident |
|---|---|
| Y17R-001 (EV-0215) | Rafiqul Alam network (13010, 13011) — merge |
| Y17R-002 (EV-0227) | Gurugram SIM box (11871) — merge |
| Y17R-003 (EV-0270) | Gulmohar Park retired banker, Rs 23 cr (13430) |
| Y17R-004 (EV-0271) | Kandivali man, 77, Rs 2.25 cr; Sadanand Date name forged (13410) |
| Y17R-005 (EV-0272) | Pimpri Chinchwad two cases, Rs 2.8 cr; linked to EV-0218 (13273) |
| Y17R-006 (EV-0273) | Kadapa advocate Rs 72.68 lakh; 9 held (12920) |
| Y17R-007 (EV-0274) | Jamshedpur fake "IPS Vijay Khanna", Rs 56 lakh (13035) |
| Y17R-008 (EV-0275) | Munirka couple Rs 15.5 lakh, Naresh Goyal pretext (13069) |
| Y17R-009 (EV-0276) | Kalyan West man Rs 27.9 lakh (13392) |
| Y17R-010 (EV-0277) | Jaipur man, 75, Rs 23.56 lakh; Goa arrest (13182) |
| Y17R-011 (EV-0278) | Gurugram woman Rs 8.30 lakh (12130) |
| Y17R-012 (EV-0279) | Ranchi hotel agents of Chinese syndicates (13243) |
| Y17R-013 (EV-0280) | Surat betting hub, forged PAN/Aadhaar (13894) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0215 Rafiqul Alam network | Y17R-001 | Y-13010, Y-13011 | Y16R-001 |
| EV-0227 Gurugram SIM box | Y17R-002 | Y-11871 | Y14R-001 |

## Ambiguities to check
1. **Y17R-005** kept separate from EV-0218 though the accused are linked to it.
2. **Y17R-003** (Rs 23 cr) is the case Y-10803 cited as Rs 22.92 cr.
3. **Y17R-012/013** have no specific victim.

## Proposed taxonomy changes
- None.
