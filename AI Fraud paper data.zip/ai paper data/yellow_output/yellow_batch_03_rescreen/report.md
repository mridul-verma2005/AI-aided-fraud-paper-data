# yellow_batch_03_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_03_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 03 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`; `sextort*` and `blackmail*` apply to this batch for the first time. The original `output_json/yellow_batch_03/` is unchanged.

## Input
- Rows: 134. Hits: 40; 9 new.
- New hits sent to extraction: 5 AI_SUSPECTED (1703, 1705, 1706, 1711, 2098). No UNCLEAR rows.
- New hits not extracted: 4 NOT_AI (1775, 1797, 2031, 2040).
- Recall: 27 of 30 original sample rows still no-hit; 1 remaining suspected miss (2138, fake audio clip of CM Naidu; "fake audio" not a keyword).

## Advisory / non-incident articles removed: 0

## Output: 2 records (2 new events EV-0193, EV-0194), both AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y03R-001 (EV-0193) | fake ID | Bengaluru Chilume voter-data theft with fake BBMP booth-level-officer ID cards (1705, 1703, 1706, 1711) |
| Y03R-002 (EV-0194) | fake ID | Patna "call boy" job extortion gang with forged ID cards (2098) |

## Merges
- None.

## Ambiguities to check
1. **Y03R-001** is a political data-collection case (2022) with no financial loss, recorded only under the fake-ID rule.
2. **Y03R-002**: amount not stated.

## Proposed taxonomy changes
- None.
