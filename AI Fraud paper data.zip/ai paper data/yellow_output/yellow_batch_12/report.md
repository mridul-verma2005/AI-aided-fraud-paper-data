# yellow_batch_12 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_12_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 162 (all success; 0 no_text). Truncated texts: none.
- No article in this batch mentions AI; all 6 hits came from "sextortion", "blackmail" or "morph".
- Sent to extraction: 3 rows (all AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 3 NOT_AI; 156 no-hit.

## Advisory / non-incident articles removed: 0

## Output: 6 records (6 new events EV-0162 to EV-0167; no merges), all AI-Aided Fraud
| Bucket | Count | Incidents |
|---|---|---|
| AI-Suspected | 3 | Hyderabad techie loan-app morphed-nude extortion (9815); Raipur Vishal Gupta loan-app morphed photos, Rs 6 lakh (10007); Ganga Vihar K.L. Tripathi video-call sextortion, Rs 5.8 lakh (10101) |
| No-AI-Evidence | 3 | Split-off cases: Kadiri mule supplier / fake trading app (9815); Army Subedar reward-points phishing and fruit trader fake insurance call (10007) |

Splits: Y-9815 (2), Y-10007 (3).

## Links to check
- EV-0167 (Mewat syndicate) with EV-0089 and EV-0135 (other Mewat video-call sextortion rings).
- EV-0162 / EV-0164 (loan-app morphed-image extortion) follow the same pattern as EV-0133 (Kapashera loan-app syndicate); no shared names.

## Ambiguities to check
1. All three AI-Suspected records rest on the sextortion rule; morphed images are not stated to be AI.

## Proposed taxonomy changes
- None. No new ai_capabilities labels.
