# yellow_batch_13_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_13_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 13 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_13/` is unchanged.

## Input
- Rows: 152. Hits: 34; 25 new.
- New hits sent to extraction: 11 AI_SUSPECTED. No UNCLEAR rows.
- New hits not extracted: 14 NOT_AI (round-ups, mule crackdowns, trafficking features, statistics, fake online profiles).
- Recall: 28 of 30 original sample rows still no-hit; 2 remaining suspected misses (10222 Goa fake-Mumbai-police parcel scam; 10501 copy of EV-0100 Kerala MLA case) without the phrase "digital arrest".

## Advisory / non-incident articles removed: 0

## Output: 10 records (2 merges, 8 new events EV-0244 to EV-0251), all AI-Aided Fraud / AI-Suspected
| Record | Incident |
|---|---|
| Y13R-001 (EV-0191) | Goa villa centre follow-up (10229) — merge |
| Y13R-002 (EV-0208) | Gujarat fake-firm mule racket, Rs 2.86 cr (10340) — merge |
| Y13R-003 (EV-0244) | Panchkula elderly woman Rs 2.98 cr, fake courtroom; 4 held (10292) |
| Y13R-004 (EV-0245) | CBI Rs 25.65 lakh case, Bhopal retiree (10363) |
| Y13R-005 (EV-0246) | Retired Rohilkhand VC Rs 1.47 cr; 3 held (10390) |
| Y13R-006 (EV-0247) | Hamirpur retired HAS officer Rs 73 lakh (10391) |
| Y13R-007 (EV-0248) | Hyderabad 62-year-old Rs 1.07 cr; 3 Delhi men held (10396 + 10404 + 10420) |
| Y13R-008 (EV-0249) | Chennai retired engineer Rs 4.67 cr; 16th accused (10402) |
| Y13R-009 (EV-0250) | Hyderabad senior woman Rs 5.66 cr, Skype surveillance (10503, case 1) |
| Y13R-010 (EV-0251) | Hyderabad senior man Rs 7.12 cr, fake Blue Dart parcel (10503, case 2) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0191 Goa villa centre | Y13R-001 | Y-10229 | Y12R-002 |
| EV-0208 Gujarat fake-firm racket | Y13R-002 | Y-10340 | Y07R-001 |

## Ambiguities to check
1. **Y13R-009/010** are two events from one article (row 10503).
2. **Y13R-008** is a one-line mention at the end of an article about a different case.

## Proposed taxonomy changes
- None.
