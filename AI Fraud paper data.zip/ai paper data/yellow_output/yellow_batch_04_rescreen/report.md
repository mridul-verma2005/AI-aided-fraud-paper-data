# yellow_batch_04_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_04_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 04 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`; `sextort*` and `blackmail*` apply to this batch for the first time. The original `output_json/yellow_batch_04/` is unchanged.

## Input
- Rows: 171. Hits: 50; 12 new.
- New hits sent to extraction: 7 AI_SUSPECTED (2455, 2571, 2619, 2745, 2800, 2829, 2856). No UNCLEAR rows.
- New hits not extracted: 5 NOT_AI (2443, 2518, 2566, 2847, 3005).
- Recall: 26 of 30 original sample rows still no-hit; no suspected misses (former miss 2829 now caught).

## Advisory / non-incident articles removed: 0

## Output: 7 records (2 merges, 5 new events EV-0195 to EV-0199), all AI-Aided Fraud
| Record | Rule | Incident |
|---|---|---|
| Y04R-001 (EV-0075) | merge | "Love guru" Pooja Kinnar racket (2829); EV-0075 keeps its AI-Confirmed bucket |
| Y04R-002 (EV-0143) | merge | Anand Kumar 500-women case (2619) |
| Y04R-003 (EV-0195) | fake ID | Navi Mumbai "ISRO scientist" romance con man, 12 fake identities, ~Rs 1 cr (2800) |
| Y04R-004 (EV-0196) | fake ID | Delhi fake hotel-booking site, forged Aadhaar (2455) |
| Y04R-005 (EV-0197) | fake ID | Lucknow "Lotus Gaming" betting-app gang, Rs 1.07 cr seized (2571) |
| Y04R-006 (EV-0198) | fake ID | Nurpur call-centre gang, Rs 80 lakh from retired engineer (2745, 2018) |
| Y04R-007 (EV-0199) | fake ID | Mathura village raids, 34 held (2856) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0075 love-guru sextortion | Y04R-001 | Y-2829 (voice modulation, recorded ritual video calls, two absconding associates) | Y18-001 |
| EV-0143 Anand Kumar | Y04R-002 | Y-2619 (no new facts) | Y19-001 |

## Ambiguities to check
1. **Broad fake-ID cases**: Y04R-004/005/006/007 qualify only because fake Aadhaar was recovered or used for SIMs/accounts, not to deceive victims.
2. **Y04R-007**: fraud types not stated in the article.

## Proposed taxonomy changes
- None.
