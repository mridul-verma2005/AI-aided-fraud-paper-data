# yellow_batch_18_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_18_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 18 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_18/` is unchanged.

## Input
- Rows: 171. Hits: 11; 8 new.
- New hits sent to extraction: 6 AI_SUSPECTED (14319, 14567, 14630, 14737, 14841, 14956). No UNCLEAR rows.
- New hits not extracted: 2 NOT_AI (14119, 14282).
- Recall: all 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 6 records (6 new events EV-0281 to EV-0286), all AI-Aided Fraud / AI-Suspected (fake-ID rule)
| Record | Incident |
|---|---|
| Y18R-001 (EV-0281) | Jaipur Imran Ali Rs 26 cr trading fraud under fake Aadhaar identity (14319) |
| Y18R-002 (EV-0282) | Bengaluru fake KPCC leader job fraud, Rs 5.3 cr (14567) |
| Y18R-003 (EV-0283) | Hyderabad Sanaullah fake joining letters, 42 youths (14630, 2022) |
| Y18R-004 (EV-0284) | Delhi fake ADM, Rs 60 lakh (14737) |
| Y18R-005 (EV-0285) | Gandhinagar fake government officers, 80+ aspirants (14841, 2021) |
| Y18R-006 (EV-0286) | Ghaziabad fake job call centre, SIMs on fake IDs (14956) |

## Merges
- None.

## Ambiguities to check
1. Y18R-002 to 005 use fake ID cards shown to victims; Y18R-006 is the broad reading (SIMs on fake IDs).

## Proposed taxonomy changes
- None.
