# Final taxonomy tree (green + yellow)

Counts are records using the name: G = green (1136 events, one record each, from 1451 batch records), Y = yellow (291 events). A record can carry several categories, types, harms and capabilities. "[green only]" / "[yellow only]" = used in one dataset only.

```
incident_domain
├── AI-Aided Fraud (G 837 / Y 267)
│   ├── ai_bucket
│   │   ├── AI-Confirmed-in-text (G 164 / Y 40)
│   │   ├── AI-Suspected (G 531 / Y 166)
│   │   ├── AI-as-Lure (G 12 / Y 25)
│   │   ├── No-AI-Evidence (G 130 / Y 36)
│   └── scam_categories -> fraud_types
│       ├── Financial Fraud (G 145 / Y 91)
│       │   ├── Investment Fraud (G 118 / Y 66)
│       │   ├── Banking & Payment Fraud (G 25 / Y 14)
│       │   ├── Loan Fraud (G 10 / Y 9)
│       │   ├── Insurance Fraud (G 5 / Y 4)
│       │   ├── Counterfeiting (G 1 / Y 0) [green only]
│       │   ├── Lottery / Prize Fraud (G 5 / Y 3)
│       │   ├── Tax / GST Fraud (G 4 / Y 2)
│       ├── Charity / Donation Fraud (G 1 / Y 1)
│       │   ├── Charity / Donation Fraud (G 3 / Y 1)
│       ├── Identity & Account Fraud (G 36 / Y 85)
│       │   ├── Identity Theft (G 16 / Y 17)
│       │   ├── Account Takeover (G 15 / Y 13)
│       │   ├── Document & Credential Forgery (G 26 / Y 70)
│       │   ├── Fake Identity Document Service (G 0 / Y 12) [yellow only]
│       ├── Cyber Intrusion (G 0 / Y 3) [yellow only]
│       │   ├── AI-Assisted Cyber Intrusion (G 14 / Y 5)
│       ├── Commerce & Platform Fraud (G 71 / Y 29)
│       │   ├── E-Commerce Fraud (G 25 / Y 7)
│       │   ├── Fake Platform Fraud (G 48 / Y 25)
│       │   ├── Counterfeit Ticket Fraud (G 3 / Y 0) [green only]
│       ├── Relationship-Based Fraud (G 100 / Y 83)
│       │   ├── Romance Fraud (G 37 / Y 21)
│       │   ├── Recruitment Fraud (G 28 / Y 22)
│       │   ├── Political Post / Ticket Fraud (G 4 / Y 0) [green only] (subtype of Recruitment Fraud)
│       │   ├── Sextortion (G 59 / Y 49)
│       ├── Impersonation Fraud (G 692 / Y 158)
│       │   ├── Individual Impersonation (G 158 / Y 28)
│       │   ├── Authority Impersonation (G 541 / Y 103)
│       │   ├── Organization Impersonation (G 38 / Y 41)
│       │   ├── Exam Proxy Fraud (G 7 / Y 3)
│       │   ├── Virtual Kidnapping (G 13 / Y 0) [green only]
│       ├── Examination Fraud (G 6 / Y 3)
│       │   ├── Exam Malpractice / Fake Paper Sale (G 6 / Y 3)
│       ├── Others (G 16 / Y 8)
│       │   ├── AI Persona Monetisation (G 2 / Y 0) [green only]
│       │   ├── Occult / Spiritual Healer Fraud (G 3 / Y 3)
│       │   ├── Public-Works / Government Reporting Fraud (G 6 / Y 2)
│       │   ├── Others (G 8 / Y 4)
├── AI Misinformation (G 117 / Y 4)
│   └── misinformation_type (list below)
├── Public Panic (G 4 / Y 0) [green only]
│   └── misinformation_type (list below)
├── AI Harassment & Abuse (G 19 / Y 1)
│   └── abuse_type
│       ├── Non-Consensual Intimate Deepfake (G 16 / Y 1)
│       ├── AI-Enabled Harassment (G 3 / Y 0) [green only]
├── Unverified Claims (G 19 / Y 4)
│   └── fraud_types / misinformation_type give the claimed type
├── Out of Scope (G 140 / Y 15)
misinformation_type (AI Misinformation, Public Panic; claimed type for Unverified Claims)
├── Fabricated Event / Hoax (G 31 / Y 1)
├── Political Deepfake / Manipulated Media of Public Figures (G 91 / Y 4)
├── Issue-Based Disinformation (G 13 / Y 0) [green only]
├── AI-Fabricated Data / Citations (G 6 / Y 0) [green only]
harms
├── FinancialLoss (G 736 / Y 248)
├── IdentityTheft (G 13 / Y 18)
├── ReputationalHarm (G 213 / Y 14)
├── Extortion (G 571 / Y 118)
├── HumanTrafficking (G 5 / Y 5)
├── IdentityFraudEnablement (G 7 / Y 27)
├── PublicDeception (G 108 / Y 6)
ai_capabilities (free text; 190 distinct labels after merges)
├── Synthetic Identity Documents (suspected) (G 0 / Y 40) [yellow only]
├── AI-Generated Video (G 8 / Y 12)
├── AI-generated video/image/audio (G 18 / Y 0) [green only]
├── AI-Generated Images (G 3 / Y 14)
├── Deepfake video of public figure (G 17 / Y 0) [green only]
├── Voice cloning (G 7 / Y 4)
├── Deepfake Video (G 1 / Y 9)
├── AI-generated obscene images (G 9 / Y 0) [green only]
├── Manipulated Images (G 0 / Y 9) [yellow only]
├── AI voice cloning (G 6 / Y 0) [green only]
├── AI Chatbot (G 0 / Y 5) [yellow only]
├── AI-Generated Documents (G 0 / Y 5) [yellow only]
├── AI Image Editing (G 0 / Y 3) [yellow only]
├── AI voice clone of public figure (G 3 / Y 0) [green only]
├── AI-Generated Images (suspected) (G 0 / Y 3) [yellow only]
├── Deepfake Images (G 0 / Y 3) [yellow only]
├── Deepfake video of Narayana Murthy (G 3 / Y 0) [green only]
├── Deepfake video of celebrity (G 3 / Y 0) [green only]
├── Voice Cloning (suspected) (G 0 / Y 3) [yellow only]
├── AI Apps (unspecified) (G 0 / Y 2) [yellow only]
├── AI image manipulation (G 2 / Y 0) [green only]
├── AI voice cloning of relative (G 2 / Y 0) [green only]
├── AI-Assisted Conversation (G 0 / Y 2) [yellow only]
├── AI-Generated Audio (G 1 / Y 1)
├── AI-Generated Code / Malware (G 0 / Y 2) [yellow only]
├── AI-generated explicit video (G 2 / Y 0) [green only]
├── AI-generated image (G 2 / Y 0) [green only]
├── AI-generated obscene video (G 2 / Y 0) [green only]
├── AI-generated photos (G 2 / Y 0) [green only]
├── AI-generated videos (G 2 / Y 0) [green only]
├── Conversational AI persona (G 2 / Y 0) [green only]
├── Deepfake Video (suspected) (G 0 / Y 2) [yellow only]
├── Deepfake video of Mukesh Ambani (G 2 / Y 0) [green only]
├── Deepfake video of public figures (G 2 / Y 0) [green only]
├── Deepfake video of the President (G 2 / Y 0) [green only]
├── Deepfake videos of public figures (G 2 / Y 0) [green only]
├── AI Game Bots (G 0 / Y 1) [yellow only]
├── AI bots manipulating game outcomes (G 1 / Y 0) [green only]
├── AI companion chatbot app used as lure (G 1 / Y 0) [green only]
├── AI deepfake explicit images (G 1 / Y 0) [green only]
├── AI deepfake nude images (G 1 / Y 0) [green only]
├── AI face morphing of ID photos (G 1 / Y 0) [green only]
├── AI face-similarity matching (G 1 / Y 0) [green only]
├── AI image editing (ChatGPT-guided) (G 1 / Y 0) [green only]
├── AI image editing of QR codes (G 1 / Y 0) [green only]
├── AI image generation (G 1 / Y 0) [green only]
├── AI image generation (Midjourney, Desire AI, OpenArt AI) (G 1 / Y 0) [green only]
├── AI on mobile phones to write answers (G 1 / Y 0) [green only]
├── AI photo editing (G 1 / Y 0) [green only]
├── AI recruiting chatbot (G 1 / Y 0) [green only]
├── AI training-data collection via wearable cameras (G 1 / Y 0) [green only]
├── AI voice clone of MLC (G 1 / Y 0) [green only]
├── AI voice clone of a Union minister (G 1 / Y 0) [green only]
├── AI voice clone of a friend (G 1 / Y 0) [green only]
├── AI voice clone of celebrity (G 1 / Y 0) [green only]
├── AI voice clone of journalist (G 1 / Y 0) [green only]
├── AI voice clones of celebrities (G 1 / Y 0) [green only]
├── AI voice clones of public figures (G 1 / Y 0) [green only]
├── AI voice cloning / voice changing (G 1 / Y 0) [green only]
├── AI voice cloning of child (G 1 / Y 0) [green only]
├── AI voice impersonation of friends/relatives (G 1 / Y 0) [green only]
├── AI voice modulation / AI tools (G 1 / Y 0) [green only]
├── AI voice/audio manipulation of video (G 1 / Y 0) [green only]
├── AI voiceover (G 1 / Y 0) [green only]
├── AI-Automated Phishing (G 0 / Y 1) [yellow only]
├── AI-Generated Content (G 0 / Y 1) [yellow only]
├── AI-Generated Documents (suspected) (G 0 / Y 1) [yellow only]
├── AI-assisted design of counterfeit notes (G 1 / Y 0) [green only]
├── AI-assisted malware/app development (G 1 / Y 0) [green only]
├── AI-built fake persona (G 1 / Y 0) [green only]
├── AI-edited photographs on admit cards (G 1 / Y 0) [green only]
├── AI-fabricated bank remittance records (G 1 / Y 0) [green only]
├── AI-forged documents (G 1 / Y 0) [green only]
├── AI-generated (hallucinated) case law (G 1 / Y 0) [green only]
├── AI-generated (hallucinated) judgments (G 1 / Y 0) [green only]
├── AI-generated ID cards/documents (Gemini) (G 1 / Y 0) [green only]
├── AI-generated ads featuring influencers (G 1 / Y 0) [green only]
├── AI-generated audio/video of wildlife (G 1 / Y 0) [green only]
├── AI-generated content using his name/face (G 1 / Y 0) [green only]
├── AI-generated deepfake videos used as bait (G 1 / Y 0) [green only]
├── AI-generated documents, newspaper clippings and photos (G 1 / Y 0) [green only]
├── AI-generated exam answers (G 1 / Y 0) [green only]
├── AI-generated explicit images (G 1 / Y 0) [green only]
├── AI-generated explicit images/videos (G 1 / Y 0) [green only]
├── AI-generated fake OMR sheets (G 1 / Y 0) [green only]
├── AI-generated fake crash report (G 1 / Y 0) [green only]
├── AI-generated fake documents/images (G 1 / Y 0) [green only]
├── AI-generated fake pass (G 1 / Y 0) [green only]
├── AI-generated female models for video calls (G 1 / Y 0) [green only]
├── AI-generated forged government documents (G 1 / Y 0) [green only]
├── AI-generated ghost/ritual images and videos (G 1 / Y 0) [green only]
├── AI-generated identity documents (G 1 / Y 0) [green only]
├── AI-generated image of fake injuries (G 1 / Y 0) [green only]
├── AI-generated images of works (G 1 / Y 0) [green only]
├── AI-generated images/video of Donald Trump (G 1 / Y 0) [green only]
├── AI-generated images/video of public figures (G 1 / Y 0) [green only]
├── AI-generated likeness of public figure (G 1 / Y 0) [green only]
├── AI-generated male voice (G 1 / Y 0) [green only]
├── AI-generated news article (G 1 / Y 0) [green only]
├── AI-generated nude photos and videos (G 1 / Y 0) [green only]
├── AI-generated obscene photos and videos (G 1 / Y 0) [green only]
├── AI-generated obscene videos (G 1 / Y 0) [green only]
├── AI-generated obscene videos and images (G 1 / Y 0) [green only]
├── AI-generated owner images and backstories (G 1 / Y 0) [green only]
├── AI-generated persona images (G 1 / Y 0) [green only]
├── AI-generated photos in army uniform (G 1 / Y 0) [green only]
├── AI-generated photos of 'brides' (G 1 / Y 0) [green only]
├── AI-generated promotional video (G 1 / Y 0) [green only]
├── AI-generated sexual videos and images (G 1 / Y 0) [green only]
├── AI-generated shop persona (G 1 / Y 0) [green only]
├── AI-generated songs (G 1 / Y 0) [green only]
├── AI-generated uniform photos (G 1 / Y 0) [green only]
├── AI-generated video and audio (G 1 / Y 0) [green only]
├── AI-generated video avatar (G 1 / Y 0) [green only]
├── AI-generated video of public figure (G 1 / Y 0) [green only]
├── AI-generated video persona (synthetic model) (G 1 / Y 0) [green only]
├── AI-generated video song (G 1 / Y 0) [green only]
├── AI-generated videos and audio (G 1 / Y 0) [green only]
├── AI-generated voice of Seema Haider (G 1 / Y 0) [green only]
├── AI-made fake courtrooms and police stations on video calls (G 1 / Y 0) [green only]
├── AI-made fake videos of business tycoons (G 1 / Y 0) [green only]
├── AI-manipulated clips/thumbnails (G 1 / Y 0) [green only]
├── AI-morphed images (G 1 / Y 0) [green only]
├── AI-morphed videos of public figures (G 1 / Y 0) [green only]
├── Autonomous AI model behaviour (G 1 / Y 0) [green only]
├── Bait links (G 1 / Y 0) [green only]
├── Bot streams (G 1 / Y 0) [green only]
├── ChatGPT used to learn police procedures (G 1 / Y 0) [green only]
├── ChatGPT-generated answers (G 1 / Y 0) [green only]
├── ChatGPT-generated answers relayed to candidates (G 1 / Y 0) [green only]
├── ChatGPT-generated fake question papers (G 1 / Y 0) [green only]
├── Cloned news-site pages (G 1 / Y 0) [green only]
├── Compromised third-party AI tool (vector) (G 1 / Y 0) [green only]
├── Deepfake / morphed live video call (G 1 / Y 0) [green only]
├── Deepfake audio of Chief Minister (G 1 / Y 0) [green only]
├── Deepfake eye-blink video (Gemini) (G 1 / Y 0) [green only]
├── Deepfake face-swap video call (G 1 / Y 0) [green only]
├── Deepfake testimonials (G 1 / Y 0) [green only]
├── Deepfake video / AI voice clones of public figures (G 1 / Y 0) [green only]
├── Deepfake video / AI voice of Sadhguru (G 1 / Y 0) [green only]
├── Deepfake video / AI voice of news anchor (G 1 / Y 0) [green only]
├── Deepfake video and voice of NSE CEO (G 1 / Y 0) [green only]
├── Deepfake video and voice of a police officer (G 1 / Y 0) [green only]
├── Deepfake video and voice of public figure (G 1 / Y 0) [green only]
├── Deepfake video conference (G 1 / Y 0) [green only]
├── Deepfake video generated from a person's photo and voice (G 1 / Y 0) [green only]
├── Deepfake video messages (G 1 / Y 0) [green only]
├── Deepfake video of BSE CEO (G 1 / Y 0) [green only]
├── Deepfake video of Nirmala Sitharaman (G 1 / Y 0) [green only]
├── Deepfake video of PM Mark Carney (G 1 / Y 0) [green only]
├── Deepfake video of PM Modi and FM Sitharaman (G 1 / Y 0) [green only]
├── Deepfake video of Rachana Ranade (G 1 / Y 0) [green only]
├── Deepfake video of journalist and doctor (G 1 / Y 0) [green only]
├── Deepfake video of police chief (G 1 / Y 0) [green only]
├── Deepfake video of retired ADG (G 1 / Y 0) [green only]
├── Deepfake video/images of chief minister (G 1 / Y 0) [green only]
├── Deepfake video/voice of public figure (G 1 / Y 0) [green only]
├── Deepfake videos (G 1 / Y 0) [green only]
├── Deepfake videos (Google Gemini) for identity verification (G 1 / Y 0) [green only]
├── Deepfake videos of MS Dhoni, Virat Kohli, Anant Ambani (G 1 / Y 0) [green only]
├── Deepfake videos of Narayana Murthy and Mukesh Ambani (G 1 / Y 0) [green only]
├── Deepfake videos of celebrities (G 1 / Y 0) [green only]
├── Deepfake videos of market experts/anchors (G 1 / Y 0) [green only]
├── Deepfake videos/images (G 1 / Y 0) [green only]
├── Deepfake voice of a friend (G 1 / Y 0) [green only]
├── Deepfake voice of spiritual leader (G 1 / Y 0) [green only]
├── Deepfake voiceover/video (G 1 / Y 0) [green only]
├── Deepfake/AI-generated crash visuals (G 1 / Y 0) [green only]
├── Deepfakes for calls (G 1 / Y 0) [green only]
├── Digital impersonation of Chief Justice in fake court hearing (G 1 / Y 0) [green only]
├── Face Swap (suspected) (G 0 / Y 1) [yellow only]
├── Face replacement (G 1 / Y 0) [green only]
├── Face-swap video call (G 1 / Y 0) [green only]
├── Face-swapping (G 1 / Y 0) [green only]
├── Gemini-built phishing kits and sites (G 1 / Y 0) [green only]
├── LLM chat assistance and translation (ChatGPT) (G 1 / Y 0) [green only]
├── LLM text generation (G 1 / Y 0) [green only]
├── LLM text generation/translation (G 1 / Y 0) [green only]
├── LLM-assisted counterfeit design research (G 1 / Y 0) [green only]
├── LLM-assisted hacking / exploit generation (G 1 / Y 0) [green only]
├── LLM-powered chat/translation tooling (G 1 / Y 0) [green only]
├── Morphed photos (G 1 / Y 0) [green only]
├── Morphed video / AI software to pass video KYC (G 1 / Y 0) [green only]
├── Multi-profile automation (G 1 / Y 0) [green only]
├── Suspected LLM-generated content (hallucinated citations) (G 1 / Y 0) [green only]
├── Suspected deepfake video (G 1 / Y 0) [green only]
├── Suspected face cloning / deepfake for liveness bypass (G 1 / Y 0) [green only]
├── Voice cloning of relatives (G 1 / Y 0) [green only]
├── Voice-changing app (G 1 / Y 0) [green only]
├── Voice-changing software (G 1 / Y 0) [green only]
```
