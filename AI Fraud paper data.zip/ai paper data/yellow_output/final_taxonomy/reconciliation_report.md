# Final taxonomy — reconciliation report

Built from existing files only: green per-batch `taxonomy.json` / `incidents.json` in `fraud-dataset-claude_for_green.zip` (taxonomy v6, identical in all 15 batches) and `output_json/yellow_combined/yellow_taxonomy.json` / `yellow_incidents.json`. After approval, the 6 merged names were applied to the source files (see "Applied changes"); no other field was changed.

## Counts
- Green: 1136 events (latest record per event from the green event registry; 1451 batch records in total). Yellow: 291 events.
- domains: 6
- ai_buckets: 4
- scam_categories: 9
- harms: 7
- misinformation_types: 4
- abuse_types: 2
- ai_capabilities (distinct labels): 190
- fraud_types: 30
- Merges: **6** (1 fraud_type, 5 ai_capabilities)
- Conflicts (value in incident data but not in the taxonomy): **0**
- Unused taxonomy entries: **0**

## Inventory with counts (G = green records, Y = yellow records)

### incident_domain
| name | G | Y | used in |
|---|---|---|---|
| AI-Aided Fraud | 837 | 267 | both |
| AI Misinformation | 117 | 4 | both |
| Public Panic | 4 | 0 | green |
| AI Harassment & Abuse | 19 | 1 | both |
| Unverified Claims | 19 | 4 | both |
| Out of Scope | 140 | 15 | both |

### ai_bucket
| name | G | Y | used in |
|---|---|---|---|
| AI-Confirmed-in-text | 164 | 40 | both |
| AI-Suspected | 531 | 166 | both |
| AI-as-Lure | 12 | 25 | both |
| No-AI-Evidence | 130 | 36 | both |

### harms
| name | G | Y | used in |
|---|---|---|---|
| FinancialLoss | 736 | 248 | both |
| IdentityTheft | 13 | 18 | both |
| ReputationalHarm | 213 | 14 | both |
| Extortion | 571 | 118 | both |
| HumanTrafficking | 5 | 5 | both |
| IdentityFraudEnablement | 7 | 27 | both |
| PublicDeception | 108 | 6 | both |

### misinformation_type
| name | G | Y | used in |
|---|---|---|---|
| Fabricated Event / Hoax | 31 | 1 | both |
| Political Deepfake / Manipulated Media of Public Figures | 91 | 4 | both |
| Issue-Based Disinformation | 13 | 0 | green |
| AI-Fabricated Data / Citations | 6 | 0 | green |

### abuse_type
| name | G | Y | used in |
|---|---|---|---|
| Non-Consensual Intimate Deepfake | 16 | 1 | both |
| AI-Enabled Harassment | 3 | 0 | green |

### scam_categories and fraud_types
| scam_category | fraud_type | G | Y | used in |
|---|---|---|---|---|
| **Financial Fraud** | (category) | 145 | 91 | both |
| Financial Fraud | Investment Fraud | 118 | 66 | both |
| Financial Fraud | Banking & Payment Fraud | 25 | 14 | both |
| Financial Fraud | Loan Fraud | 10 | 9 | both |
| Financial Fraud | Insurance Fraud | 5 | 4 | both |
| Financial Fraud | Counterfeiting | 1 | 0 | green |
| Financial Fraud | Lottery / Prize Fraud | 5 | 3 | both |
| Financial Fraud | Tax / GST Fraud | 4 | 2 | both |
| **Charity / Donation Fraud** | (category) | 1 | 1 | both |
| Charity / Donation Fraud | Charity / Donation Fraud | 3 | 1 | both |
| **Identity & Account Fraud** | (category) | 36 | 85 | both |
| Identity & Account Fraud | Identity Theft | 16 | 17 | both |
| Identity & Account Fraud | Account Takeover | 15 | 13 | both |
| Identity & Account Fraud | Document & Credential Forgery | 26 | 70 | both |
| Identity & Account Fraud | Fake Identity Document Service | 0 | 12 | yellow |
| **Cyber Intrusion** | (category) | 0 | 3 | yellow |
| Cyber Intrusion | AI-Assisted Cyber Intrusion | 14 | 5 | both |
| **Commerce & Platform Fraud** | (category) | 71 | 29 | both |
| Commerce & Platform Fraud | E-Commerce Fraud | 25 | 7 | both |
| Commerce & Platform Fraud | Fake Platform Fraud | 48 | 25 | both |
| Commerce & Platform Fraud | Counterfeit Ticket Fraud | 3 | 0 | green |
| **Relationship-Based Fraud** | (category) | 100 | 83 | both |
| Relationship-Based Fraud | Romance Fraud | 37 | 21 | both |
| Relationship-Based Fraud | Recruitment Fraud | 28 | 22 | both |
| Relationship-Based Fraud | Political Post / Ticket Fraud | 4 | 0 | green |
| Relationship-Based Fraud | Sextortion | 59 | 49 | both |
| **Impersonation Fraud** | (category) | 692 | 158 | both |
| Impersonation Fraud | Individual Impersonation | 158 | 28 | both |
| Impersonation Fraud | Authority Impersonation | 541 | 103 | both |
| Impersonation Fraud | Organization Impersonation | 38 | 41 | both |
| Impersonation Fraud | Exam Proxy Fraud | 7 | 3 | both |
| Impersonation Fraud | Virtual Kidnapping | 13 | 0 | green |
| **Examination Fraud** | (category) | 6 | 3 | both |
| Examination Fraud | Exam Malpractice / Fake Paper Sale | 6 | 3 | both |
| **Others** | (category) | 16 | 8 | both |
| Others | AI Persona Monetisation | 2 | 0 | green |
| Others | Occult / Spiritual Healer Fraud | 3 | 3 | both |
| Others | Public-Works / Government Reporting Fraud | 6 | 2 | both |
| Others | Others | 8 | 4 | both |

### ai_capabilities
| label | G | Y | used in |
|---|---|---|---|
| Synthetic Identity Documents (suspected) | 0 | 40 | yellow |
| AI-Generated Video | 8 | 12 | both |
| AI-generated video/image/audio | 18 | 0 | green |
| AI-Generated Images | 3 | 14 | both |
| Deepfake video of public figure | 17 | 0 | green |
| Voice cloning | 7 | 4 | both |
| Deepfake Video | 1 | 9 | both |
| AI-generated obscene images | 9 | 0 | green |
| Manipulated Images | 0 | 9 | yellow |
| AI voice cloning | 6 | 0 | green |
| AI Chatbot | 0 | 5 | yellow |
| AI-Generated Documents | 0 | 5 | yellow |
| AI Image Editing | 0 | 3 | yellow |
| AI voice clone of public figure | 3 | 0 | green |
| AI-Generated Images (suspected) | 0 | 3 | yellow |
| Deepfake Images | 0 | 3 | yellow |
| Deepfake video of Narayana Murthy | 3 | 0 | green |
| Deepfake video of celebrity | 3 | 0 | green |
| Voice Cloning (suspected) | 0 | 3 | yellow |
| AI Apps (unspecified) | 0 | 2 | yellow |
| AI image manipulation | 2 | 0 | green |
| AI voice cloning of relative | 2 | 0 | green |
| AI-Assisted Conversation | 0 | 2 | yellow |
| AI-Generated Audio | 1 | 1 | both |
| AI-Generated Code / Malware | 0 | 2 | yellow |
| AI-generated explicit video | 2 | 0 | green |
| AI-generated image | 2 | 0 | green |
| AI-generated obscene video | 2 | 0 | green |
| AI-generated photos | 2 | 0 | green |
| AI-generated videos | 2 | 0 | green |
| Conversational AI persona | 2 | 0 | green |
| Deepfake Video (suspected) | 0 | 2 | yellow |
| Deepfake video of Mukesh Ambani | 2 | 0 | green |
| Deepfake video of public figures | 2 | 0 | green |
| Deepfake video of the President | 2 | 0 | green |
| Deepfake videos of public figures | 2 | 0 | green |
| AI Game Bots | 0 | 1 | yellow |
| AI bots manipulating game outcomes | 1 | 0 | green |
| AI companion chatbot app used as lure | 1 | 0 | green |
| AI deepfake explicit images | 1 | 0 | green |
| AI deepfake nude images | 1 | 0 | green |
| AI face morphing of ID photos | 1 | 0 | green |
| AI face-similarity matching | 1 | 0 | green |
| AI image editing (ChatGPT-guided) | 1 | 0 | green |
| AI image editing of QR codes | 1 | 0 | green |
| AI image generation | 1 | 0 | green |
| AI image generation (Midjourney, Desire AI, OpenArt AI) | 1 | 0 | green |
| AI on mobile phones to write answers | 1 | 0 | green |
| AI photo editing | 1 | 0 | green |
| AI recruiting chatbot | 1 | 0 | green |
| AI training-data collection via wearable cameras | 1 | 0 | green |
| AI voice clone of MLC | 1 | 0 | green |
| AI voice clone of a Union minister | 1 | 0 | green |
| AI voice clone of a friend | 1 | 0 | green |
| AI voice clone of celebrity | 1 | 0 | green |
| AI voice clone of journalist | 1 | 0 | green |
| AI voice clones of celebrities | 1 | 0 | green |
| AI voice clones of public figures | 1 | 0 | green |
| AI voice cloning / voice changing | 1 | 0 | green |
| AI voice cloning of child | 1 | 0 | green |
| AI voice impersonation of friends/relatives | 1 | 0 | green |
| AI voice modulation / AI tools | 1 | 0 | green |
| AI voice/audio manipulation of video | 1 | 0 | green |
| AI voiceover | 1 | 0 | green |
| AI-Automated Phishing | 0 | 1 | yellow |
| AI-Generated Content | 0 | 1 | yellow |
| AI-Generated Documents (suspected) | 0 | 1 | yellow |
| AI-assisted design of counterfeit notes | 1 | 0 | green |
| AI-assisted malware/app development | 1 | 0 | green |
| AI-built fake persona | 1 | 0 | green |
| AI-edited photographs on admit cards | 1 | 0 | green |
| AI-fabricated bank remittance records | 1 | 0 | green |
| AI-forged documents | 1 | 0 | green |
| AI-generated (hallucinated) case law | 1 | 0 | green |
| AI-generated (hallucinated) judgments | 1 | 0 | green |
| AI-generated ID cards/documents (Gemini) | 1 | 0 | green |
| AI-generated ads featuring influencers | 1 | 0 | green |
| AI-generated audio/video of wildlife | 1 | 0 | green |
| AI-generated content using his name/face | 1 | 0 | green |
| AI-generated deepfake videos used as bait | 1 | 0 | green |
| AI-generated documents, newspaper clippings and photos | 1 | 0 | green |
| AI-generated exam answers | 1 | 0 | green |
| AI-generated explicit images | 1 | 0 | green |
| AI-generated explicit images/videos | 1 | 0 | green |
| AI-generated fake OMR sheets | 1 | 0 | green |
| AI-generated fake crash report | 1 | 0 | green |
| AI-generated fake documents/images | 1 | 0 | green |
| AI-generated fake pass | 1 | 0 | green |
| AI-generated female models for video calls | 1 | 0 | green |
| AI-generated forged government documents | 1 | 0 | green |
| AI-generated ghost/ritual images and videos | 1 | 0 | green |
| AI-generated identity documents | 1 | 0 | green |
| AI-generated image of fake injuries | 1 | 0 | green |
| AI-generated images of works | 1 | 0 | green |
| AI-generated images/video of Donald Trump | 1 | 0 | green |
| AI-generated images/video of public figures | 1 | 0 | green |
| AI-generated likeness of public figure | 1 | 0 | green |
| AI-generated male voice | 1 | 0 | green |
| AI-generated news article | 1 | 0 | green |
| AI-generated nude photos and videos | 1 | 0 | green |
| AI-generated obscene photos and videos | 1 | 0 | green |
| AI-generated obscene videos | 1 | 0 | green |
| AI-generated obscene videos and images | 1 | 0 | green |
| AI-generated owner images and backstories | 1 | 0 | green |
| AI-generated persona images | 1 | 0 | green |
| AI-generated photos in army uniform | 1 | 0 | green |
| AI-generated photos of 'brides' | 1 | 0 | green |
| AI-generated promotional video | 1 | 0 | green |
| AI-generated sexual videos and images | 1 | 0 | green |
| AI-generated shop persona | 1 | 0 | green |
| AI-generated songs | 1 | 0 | green |
| AI-generated uniform photos | 1 | 0 | green |
| AI-generated video and audio | 1 | 0 | green |
| AI-generated video avatar | 1 | 0 | green |
| AI-generated video of public figure | 1 | 0 | green |
| AI-generated video persona (synthetic model) | 1 | 0 | green |
| AI-generated video song | 1 | 0 | green |
| AI-generated videos and audio | 1 | 0 | green |
| AI-generated voice of Seema Haider | 1 | 0 | green |
| AI-made fake courtrooms and police stations on video calls | 1 | 0 | green |
| AI-made fake videos of business tycoons | 1 | 0 | green |
| AI-manipulated clips/thumbnails | 1 | 0 | green |
| AI-morphed images | 1 | 0 | green |
| AI-morphed videos of public figures | 1 | 0 | green |
| Autonomous AI model behaviour | 1 | 0 | green |
| Bait links | 1 | 0 | green |
| Bot streams | 1 | 0 | green |
| ChatGPT used to learn police procedures | 1 | 0 | green |
| ChatGPT-generated answers | 1 | 0 | green |
| ChatGPT-generated answers relayed to candidates | 1 | 0 | green |
| ChatGPT-generated fake question papers | 1 | 0 | green |
| Cloned news-site pages | 1 | 0 | green |
| Compromised third-party AI tool (vector) | 1 | 0 | green |
| Deepfake / morphed live video call | 1 | 0 | green |
| Deepfake audio of Chief Minister | 1 | 0 | green |
| Deepfake eye-blink video (Gemini) | 1 | 0 | green |
| Deepfake face-swap video call | 1 | 0 | green |
| Deepfake testimonials | 1 | 0 | green |
| Deepfake video / AI voice clones of public figures | 1 | 0 | green |
| Deepfake video / AI voice of Sadhguru | 1 | 0 | green |
| Deepfake video / AI voice of news anchor | 1 | 0 | green |
| Deepfake video and voice of NSE CEO | 1 | 0 | green |
| Deepfake video and voice of a police officer | 1 | 0 | green |
| Deepfake video and voice of public figure | 1 | 0 | green |
| Deepfake video conference | 1 | 0 | green |
| Deepfake video generated from a person's photo and voice | 1 | 0 | green |
| Deepfake video messages | 1 | 0 | green |
| Deepfake video of BSE CEO | 1 | 0 | green |
| Deepfake video of Nirmala Sitharaman | 1 | 0 | green |
| Deepfake video of PM Mark Carney | 1 | 0 | green |
| Deepfake video of PM Modi and FM Sitharaman | 1 | 0 | green |
| Deepfake video of Rachana Ranade | 1 | 0 | green |
| Deepfake video of journalist and doctor | 1 | 0 | green |
| Deepfake video of police chief | 1 | 0 | green |
| Deepfake video of retired ADG | 1 | 0 | green |
| Deepfake video/images of chief minister | 1 | 0 | green |
| Deepfake video/voice of public figure | 1 | 0 | green |
| Deepfake videos | 1 | 0 | green |
| Deepfake videos (Google Gemini) for identity verification | 1 | 0 | green |
| Deepfake videos of MS Dhoni, Virat Kohli, Anant Ambani | 1 | 0 | green |
| Deepfake videos of Narayana Murthy and Mukesh Ambani | 1 | 0 | green |
| Deepfake videos of celebrities | 1 | 0 | green |
| Deepfake videos of market experts/anchors | 1 | 0 | green |
| Deepfake videos/images | 1 | 0 | green |
| Deepfake voice of a friend | 1 | 0 | green |
| Deepfake voice of spiritual leader | 1 | 0 | green |
| Deepfake voiceover/video | 1 | 0 | green |
| Deepfake/AI-generated crash visuals | 1 | 0 | green |
| Deepfakes for calls | 1 | 0 | green |
| Digital impersonation of Chief Justice in fake court hearing | 1 | 0 | green |
| Face Swap (suspected) | 0 | 1 | yellow |
| Face replacement | 1 | 0 | green |
| Face-swap video call | 1 | 0 | green |
| Face-swapping | 1 | 0 | green |
| Gemini-built phishing kits and sites | 1 | 0 | green |
| LLM chat assistance and translation (ChatGPT) | 1 | 0 | green |
| LLM text generation | 1 | 0 | green |
| LLM text generation/translation | 1 | 0 | green |
| LLM-assisted counterfeit design research | 1 | 0 | green |
| LLM-assisted hacking / exploit generation | 1 | 0 | green |
| LLM-powered chat/translation tooling | 1 | 0 | green |
| Morphed photos | 1 | 0 | green |
| Morphed video / AI software to pass video KYC | 1 | 0 | green |
| Multi-profile automation | 1 | 0 | green |
| Suspected LLM-generated content (hallucinated citations) | 1 | 0 | green |
| Suspected deepfake video | 1 | 0 | green |
| Suspected face cloning / deepfake for liveness bypass | 1 | 0 | green |
| Voice cloning of relatives | 1 | 0 | green |
| Voice-changing app | 1 | 0 | green |
| Voice-changing software | 1 | 0 | green |

## Merges (names differing only in case, punctuation or spacing)
Canonical form = the one used by most records; on a tie, the green taxonomy form.

| field | canonical | variant | G | Y | defined in taxonomy |
|---|---|---|---|---|---|
| fraud_type | Occult / Spiritual Healer Fraud | Occult / "Spiritual Healer" Fraud | 0 | 3 | yellow |
| fraud_type | Occult / Spiritual Healer Fraud | Occult / Spiritual Healer Fraud | 3 | 0 | green |
| ai_capability | Voice cloning | Voice Cloning | 0 | 4 | - |
| ai_capability | Voice cloning | Voice cloning | 7 | 0 | - |
| ai_capability | AI-Generated Images | AI-Generated Images | 0 | 14 | - |
| ai_capability | AI-Generated Images | AI-generated images | 3 | 0 | - |
| ai_capability | AI-Generated Video | AI-Generated Video | 0 | 12 | - |
| ai_capability | AI-Generated Video | AI-generated video | 8 | 0 | - |
| ai_capability | AI-Generated Audio | AI-Generated Audio | 0 | 1 | - |
| ai_capability | AI-Generated Audio | AI-generated audio | 1 | 0 | - |
| ai_capability | Deepfake Video | Deepfake Video | 0 | 9 | - |
| ai_capability | Deepfake Video | Deepfake video | 1 | 0 | - |

## Types used in one dataset only (kept, marked)
- domains: **Public Panic** — green only
- misinformation_types: **Issue-Based Disinformation** — green only
- misinformation_types: **AI-Fabricated Data / Citations** — green only
- abuse_types: **AI-Enabled Harassment** — green only
- fraud_type: **Counterfeiting** (Financial Fraud) — green only
- fraud_type: **Fake Identity Document Service** (Identity & Account Fraud) — yellow only
- scam_category: **Cyber Intrusion** — yellow only
- fraud_type: **Counterfeit Ticket Fraud** (Commerce & Platform Fraud) — green only
- fraud_type: **Political Post / Ticket Fraud** (Relationship-Based Fraud) — green only
- fraud_type: **Virtual Kidnapping** (Impersonation Fraud) — green only
- fraud_type: **AI Persona Monetisation** (Others) — green only
- ai_capabilities: 168 labels green only, 17 yellow only, 5 in both (see inventory).

## Unused taxonomy entries (defined but used by zero records)
- None. Every domain, ai_bucket, scam_category, fraud_type, harm, misinformation_type and abuse_type defined in either taxonomy.json is used by at least one green or yellow record.

## Conflicts (in incident data but not in the taxonomy)
- None after the merges above. Every incident_domain, ai_bucket, scam_categories, fraud_types, harms, misinformation_type and abuse_type value in both datasets matches a taxonomy entry. ai_capabilities is free text in both taxonomies, so it cannot conflict.

### Related check: fraud_types in records with no scam_category (not counted as conflicts)
- 123 green and 23 yellow fraud_type uses sit in records whose scam_categories is null. All are Out of Scope (green 72 records, yellow 13) or Unverified Claims (green 3, yellow 2), where the record rules set scam_categories to null but keep the claimed fraud type. No AI-Aided Fraud record lacks a category, and no fraud type is filed under a category it does not belong to.

## Name changes in incident records (approved and applied 2026-11-03)
| field | current value | change to | green records | yellow records |
|---|---|---|---|---|
| fraud_type | Occult / "Spiritual Healer" Fraud | Occult / Spiritual Healer Fraud | 0 | 3 |
| ai_capability | Voice Cloning | Voice cloning | 0 | 4 |
| ai_capability | AI-generated images | AI-Generated Images | 3 | 0 |
| ai_capability | AI-generated video | AI-Generated Video | 8 | 0 |
| ai_capability | AI-generated audio | AI-Generated Audio | 1 | 0 |
| ai_capability | Deepfake video | Deepfake Video | 1 | 0 |
- yellow_taxonomy.json would also change `Occult / "Spiritual Healer" Fraud` to `Occult / Spiritual Healer Fraud`.

## Near-variants NOT merged (plural or "(suspected)" differences; for your review)
These differ by more than case or punctuation, so they were left separate. "(suspected)" is a deliberate marker for AI-Suspected records and should probably stay distinct; the plural pairs look like the same label.
- ai_capability: AI-Generated Documents | AI-Generated Documents (suspected)
- ai_capability: AI-Generated Images | AI-Generated Images (suspected) | AI-generated image
- ai_capability: AI-Generated Video | AI-generated videos
- ai_capability: AI-generated obscene video | AI-generated obscene videos
- ai_capability: Deepfake Video | Deepfake Video (suspected) | Deepfake videos
- ai_capability: Deepfake video of public figure | Deepfake video of public figures
- ai_capability: Voice Cloning (suspected) | Voice cloning

## Applied changes (2026-11-03, after approval)
Exact quoted values replaced; a check confirmed that only `fraud_types` / `ai_capabilities` values changed in any record.

| dataset / files | old | new | occurrences |
|---|---|---|---|
| yellow combined (`yellow_incidents.json`, `yellow_taxonomy.json`) | Occult / "Spiritual Healer" Fraud | Occult / Spiritual Healer Fraud | 5 (3 records + taxonomy lists) |
| yellow combined | Voice Cloning | Voice cloning | 5 (4 records + taxonomy list) |
| yellow per-batch `incidents.json` / `taxonomy.json` (batches 01-25 and re-screens) | Occult / "Spiritual Healer" Fraud | Occult / Spiritual Healer Fraud | 57 (records incl. superseded versions, and every batch taxonomy) |
| yellow per-batch | Voice Cloning | Voice cloning | 8 |
| green per-batch `incidents.json` in `fraud-dataset-claude_for_green.zip` (batches 01-06) | AI-generated video | AI-Generated Video | 13 (all record versions; 8 latest-per-event) |
| green zip | AI-generated images | AI-Generated Images | 3 |
| green zip | AI-generated audio | AI-Generated Audio | 1 |
| green zip | Deepfake video | Deepfake Video | 1 |

- Original green zip kept as `fraud-dataset-claude_for_green.zip.bak`.
- Not changed: `all_incidents_combined.xlsx` and the nested `output_json.zip` inside the green zip still carry the old spellings.
- Re-running the build after the changes gives 0 remaining variants and identical usage counts.
