# yellow_batch_25 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_25_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 50. 42 are identical to yellow_batch_01 rows (same row_id, URL and text); 8 new rows (572, 576, 582, 591, 592, 599, 627, 660) failed fetch (http_403 / http_404) and are kept as no_text.
- Stage 2: all 8 hits carry batch 01 labels; no new hits.
- Eligible for extraction: 3 rows (all AI_LURE). No UNCLEAR rows.
- Not extracted: 5 NOT_AI; 34 no-hit (recall sample 30: 1 digital-arrest pattern, row 680; not on the keyword list); 8 no_text.

## Advisory / non-incident articles removed: 0

## Output: 0 records (no merges, no new events)
| Row | Already recorded as |
|---|---|
| 574 | EV-0006 (Cambodian call-centre gang, "AI-powered" stock apps) |
| 657 | EV-0007 (Ojasvi Foundation / Ojasvi AI forex scheme) |
| 685 | EV-0008 (Telegram "AI stock recommendations" group) |

- `incidents.json` is an empty list. Event registry unchanged at 183 events.

## Ambiguities to check
- None new.

## Proposed taxonomy changes
- None.
