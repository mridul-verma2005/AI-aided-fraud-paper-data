# yellow_batch_05_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_05_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 05 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`; `blackmail*` applies to this batch for the first time. The original `output_json/yellow_batch_05/` is unchanged.

## Input
- Rows: 173. Hits: 53; 9 new.
- New hits sent to extraction: 5 AI_SUSPECTED (3064, 3090, 3378, 3582, 3660). No UNCLEAR rows.
- New hits not extracted: 4 NOT_AI (3080, 3229, 3704, 3879).
- Recall: 28 of 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 5 records (5 new events EV-0200 to EV-0204), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y05R-001 (EV-0200) | digital arrest | Goa woman's Rs 2.6 cr digital arrest; ED arrests two, network with 163 FIRs (3064) |
| Y05R-002 (EV-0201) | digital arrest | Mumbai West: Rs 1.67 cr to fake police with forged Supreme Court papers; 7 held (3090) |
| Y05R-003 (EV-0202) | digital arrest | Retired IAF radiologist, 27-day digital arrest, Rs 2.52 cr; 4 held (3378) |
| Y05R-004 (EV-0203) | sextortion | Canada-based Punjabi blackmailed over "ardas" video; 3 held in Punjab (3582) |
| Y05R-005 (EV-0204) | fake ID | Uttarakhand SSC exam cheating racket; fake ID cards seized (3660) |

## Merges
- None.

## Ambiguities to check
1. **Y05R-004**: only the specific case is recorded from a statistics round-up; the video's content is not described; amount is the recovery.
2. **Y05R-005**: exam-cheating case kept only under the broad fake-ID rule.

## Proposed taxonomy changes
- None.
