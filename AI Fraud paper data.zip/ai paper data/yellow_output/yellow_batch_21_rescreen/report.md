# yellow_batch_21_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_21_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 21 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_21/` is unchanged.

## Input
- Rows: 114. Hits: 19; 3 new.
- New hits sent to extraction: 1 AI_SUSPECTED (16653). No UNCLEAR rows.
- New hits not extracted: 2 NOT_AI (16526 round-up; 16850 viral audio anecdote).
- Recall: all 30 original sample rows still no-hit; 4 suspected misses remain (16827, 16832, 16826, 16774 — fake CBI/police video calls without the phrase "digital arrest").

## Advisory / non-incident articles removed: 0

## Output: 2 records (2 new events EV-0290, EV-0291), both AI-Aided Fraud / AI-Suspected
| Record | Incident |
|---|---|
| Y21R-001 (EV-0290) | Coimbatore retired woman, 69, Rs 19 lakh, fake CBI video call (16653, case 1) |
| Y21R-002 (EV-0291) | Coimbatore Dr Rangaraj, 80, Rs 31.55 lakh (16653, case 2) |

## Merges
- None.

## Ambiguities to check
1. Two events from one five-case article.

## Proposed taxonomy changes
- None.
