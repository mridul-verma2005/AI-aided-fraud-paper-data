# yellow_batch_19_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_19_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 19 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_19/` is unchanged.

## Input
- Rows: 181. Hits: 13; 6 new.
- New hits sent to extraction: 3 AI_SUSPECTED (15635, 15666, 15962). No UNCLEAR rows.
- New hits not extracted: 3 NOT_AI (15326 matrimonial "fake ID profile"; 15703, 15753 sidebar links).
- Recall: 29 of 30 original sample rows still no-hit; no suspected misses (former miss 15962 now caught).

## Advisory / non-incident articles removed: 0

## Output: 3 records (3 new events EV-0287 to EV-0289), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y19R-001 (EV-0287) | digital arrest | Indore share trader Rs 1.6 cr; 6 held (15635) |
| Y19R-002 (EV-0288) | digital arrest | Pune IT executive Rs 6.29 cr (15666, 2024) |
| Y19R-003 (EV-0289) | fake ID | Lucknow "Bhavika Shetty" Rs 1.92 cr romance-investment fraud (15962) |

## Merges
- None.

## Ambiguities to check
- None new.

## Proposed taxonomy changes
- None.
