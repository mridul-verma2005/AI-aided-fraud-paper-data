# yellow_batch_06_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_06_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 06 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`; `blackmail*` applies to this batch for the first time. The original `output_json/yellow_batch_06/` is unchanged.

## Input
- Rows: 171. Hits: 58; 11 new.
- New hits sent to extraction: 4 AI_SUSPECTED (3982, 4036, 4552, 4595). No UNCLEAR rows.
- New hits not extracted: 7 NOT_AI (4029, 4071, 4554, 4701, 4704, 4730, 4861).
- Recall: 29 of 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 4 records (1 merge, 3 new events EV-0205 to EV-0207), all AI-Aided Fraud
| Record | Rule | Incident |
|---|---|---|
| Y06R-001 (EV-0075) | merge | "Love guru" Pooja Kinnar racket (4036); keeps AI-Confirmed bucket |
| Y06R-002 (EV-0205) | sextortion | Chhatrapati Sambhaji Nagar elderly man, Rs 14.67 lakh (3982) |
| Y06R-003 (EV-0206) | digital arrest | Bowenpally man, fake "IPS Daya Nayak", Rs 33.4 lakh (4552) |
| Y06R-004 (EV-0207) | fake ID | Gurugram fake insurance-ombudsman scam, Rs 1.19 cr; forged Aadhaar/PAN; 4 held (4595) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0075 love-guru sextortion | Y06R-001 | Y-4036 (DCP quote: edited photos, screen-recorded "shudhikaran" calls) | Y04R-001 |

## Ambiguities to check
- None new.

## Proposed taxonomy changes
- None.
