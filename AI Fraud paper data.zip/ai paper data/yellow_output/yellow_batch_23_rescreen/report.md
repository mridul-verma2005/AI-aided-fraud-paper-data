# yellow_batch_23_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_23_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits; labels reused from `yellow_batch_01_rescreen`), `recall_check.csv`
The original `output_json/yellow_batch_23/` is unchanged.

## Input
- Rows: 50 (44 identical to batch 01; 6 no_text). Hits: 23; 5 new, all batch 01 rows already labelled in the batch 01 re-screen.
- Eligible: 409 (AI_SUSPECTED). NOT_AI: 177, 180, 184, 294.
- Recall: 21 of 30 original sample rows still no-hit; 1 suspected miss (187, fake Mumbai police video call, no "digital arrest" phrase).

## Output: 0 records (no merges, no new events)
| Row | Already recorded as |
|---|---|
| 409 | EV-0185 (Y01R-002) |

- `incidents.json` is an empty list. Event registry unchanged at 291 events.

## Proposed taxonomy changes
- None.
