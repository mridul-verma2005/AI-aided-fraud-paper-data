# yellow_batch_03 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_03_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02)

## Input
- Rows: 134 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 15 rows (13 AI_INVOLVED, 2 AI_LURE). No UNCLEAR rows.
- Not extracted: 16 NOT_AI; 103 no-hit (recall miss 2138 not labelled, so not extracted).

## Advisory / non-incident articles removed: 9
| Row | Reason |
|---|---|
| 1936 | McAfee festive-scam survey |
| 1987 | Deloitte interview on festive scams |
| 2056 | Hyderabad Police advisory on AI biometric capture |
| 2115 | Boss Scam explainer (I4C advisory; $25M case abroad only cited) |
| 2209 | SEBI Boss Scam caution |
| 2220 | I4C Boss Scam advisory |
| 2241 | 2025 year-end scam-type round-up |
| 2260 | Dubai Police job-scam advisory (UAE) |
| 2263 | SEBI Boss Scam warning |

## Output: 11 records
| Domain | Count |
|---|---|
| AI-Aided Fraud | 7 |
| AI Misinformation | 1 |
| Out of Scope | 3 |

| Bucket (AI-Aided Fraud) | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 1 | Fake IAS Gaurav Kumar Singh, merged into EV-0014 (Y-453 + Y-2076) |
| AI-as-Lure | 1 | SchoolPad "AI-enabled Robotics Lab" fee scam (1859) |
| No-AI-Evidence | 5 | Split-off cases: Delhi delivery agent Kishan (1935); Pushpesh Singh UPSC/LBSNAA, Khurja fake constable letter, Vivek Mishra Rs 80 cr, Delhi "gigolo job" (all 2076) |

AI Misinformation: Aishwarya Rai Delhi HC personality-rights order (1948+1958), misinformation_type Political Deepfake / Manipulated Media of Public Figures, personality_rights_case = true.

Out of Scope: Chinese teen refund fraud (1935, China); Chinese buyer refund fraud with false images (1935, China); iLearningEngines AI-revenue fraud (2242, USA).

## Merges across batches
- **EV-0014 (fake IAS officer, Gorakhpur)**: Y-2076 merged with batch 01's Y-453 into new record Y03-006. Batch 01 record Y01-014 kept with a pointer. Y-2076 does not name the accused; the match (Gorakhpur, beacon SUV, fake IAS for ~3 years, AI-generated documents, UP/Bihar/Jharkhand/MP) is strong but should be confirmed.

## Not extracted from round-up Y-2076
- Diptendu Bag (Kolkata, posed as CID inspector at a police station) and two Lucknow men claiming IPS rank in tea-stall disputes: impersonation with no fraud victim and no AI.

## Ambiguities to check
1. **EV-0014 merge** relies on matching details, not a name.
2. **Aishwarya Rai**: the fake "Aishwarya Nation Wealth" fund soliciting money is a fraud element inside a personality-rights case; kept in the AI Misinformation record per the celebrity-suit rule.
3. **SchoolPad (1859)**: AI-as-Lure only because the bogus fee was for an "AI-enabled Robotics Lab"; could reasonably be No-AI-Evidence.
4. **Chinese refund case (1935)**: AI-generated images are tied to the case only by context.
5. **Vivek Mishra (2076)**: two different hometowns and an amount that does not match the per-victim fees; kept as reported.

## Proposed taxonomy changes
- None. No new ai_capabilities labels this batch.
