# yellow_batch_24_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_24_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits; labels reused from `yellow_batch_01_rescreen`), `recall_check.csv`
The original `output_json/yellow_batch_24/` is unchanged.

## Input
- Rows: 50 (41 identical to batch 01; 9 no_text). Hits: 10; 3 new, all batch 01 rows already labelled in the batch 01 re-screen.
- Eligible: 470, 535 (AI_SUSPECTED). NOT_AI: 436.
- Recall: 27 of 30 original sample rows still no-hit; 1 suspected miss (416, relative's-voice impersonation in loose wording).

## Output: 0 records (no merges, no new events)
| Row | Already recorded as |
|---|---|
| 470 | EV-0187 (Y01R-004) |
| 535 | EV-0188 (Y01R-005) |

- `incidents.json` is an empty list. Event registry unchanged at 291 events.

## Proposed taxonomy changes
- None.
