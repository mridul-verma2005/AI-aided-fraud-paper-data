# yellow_batch_02 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_02_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02)

## Input
- Rows: 165 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 30 rows (14 AI_INVOLVED, 16 AI_LURE).
- Not extracted: 18 NOT_AI; 114 no-hit; **UNCLEAR rows 1003, 1071, 1548 waiting for your decision.**

## Advisory / non-incident articles removed: 8
| Row | Reason |
|---|---|
| 948 | Romance-scam trend piece; only case cited is a French victim |
| 949 | Romance-scam explainer with survey data |
| 964 | Valentine's advisory on AI video calls |
| 973 | Kaspersky blog on AI and dating |
| 981 | McAfee health-scam survey |
| 1023 | UNODC regional scam-loss report |
| 1279 | TN Police warning on fake "Ghibli AI art" sites; no specific case or ad |
| 1319 | Op-ed on AI financial scams |

## Output: 21 records
| Domain | Count |
|---|---|
| AI-Aided Fraud | 18 |
| Out of Scope | 3 |

| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 5 | Bogus PSI Panchal (831), Chennai Tinder AI-bot attempt (905), Bhopal AI chatbot romance (991), Pune AI-girlfriend app sextortion (991), Rent Boyfriend AI-photo ads (1014+1019) |
| AI-Suspected | 2 | Two Chennai dating-app sextortions (905), via the sextortion rule |
| AI-as-Lure | 7 | AV Solutions merged (EV-0004), Naka Solutions (748), QFX/BotBro campaign (774+931+1043+1148), Assam Bot-Bro (934+1147), Dehradun Botbro (1198), retired IAS Rs 3.37 cr (856+1249+1266), Cyberabad AI trading/IPO (1255) |
| No-AI-Evidence | 4 | Split-off cases: 5 Paisa impersonation (748), Bengaluru task-crypto (1198), Cyberabad job fraud (1255), Neel Vijay trafficked to Myanmar (995) |

Out of Scope (outside India): Sri Lankan "Ravi" in Myanmar compound (995); US cyberstalker James Florence Jr. (1539); Life2vec fake AI sites, Denmark/online (1320).

## Merges across batches
- **EV-0004 (AV Solutions)**: Y-736 and Y-1274 merged with batch 01's Y-295/Y-302 into new record Y02-001. Batch 01 record Y01-004 is kept with a review_note pointing to Y02-001; the registry lists both. Y-736 adds a third arrestee (Gaddam Venkatarao); retained amount updated to Rs 232.36 cr.

## Merges and splits within the batch
- Merged: 856+1249+1266 (retired IAS officer); 774+931+1043+1148 (QFX/BotBro campaign); 934+1147 (Assam Bot-Bro); 1014+1019 (Rent Boyfriend).
- Split: 748 (2), 905 (3), 991 (2), 995 (2), 1198 (2), 1255 (2).

## Ambiguities to check
1. **BotBro network**: the ED campaign (QFX/YFX/BotBro), the Assam Bot-Bro case and the Dehradun case are three events, with links to check in review_note. Under the "coordinated campaign is one event" rule they could be one; Dehradun has a named victim, so it stays separate either way. Amounts conflict (ED Rs 500-600 cr vs Crypto Times Rs 3,200 cr).
2. **Y-931** calls Harinder Pal Singh the mastermind; the other three articles call him the top agent under Lavish Choudhary.
3. **Chennai sextortions (905)**: AI-Suspected only by the sextortion rule; no AI in either case.
4. **Rent Boyfriend (1014+1019)**: kept under the specific-ad rule; no named victim or loss. Typed as E-Commerce Fraud (fake paid service).
5. **Neel Vijay (995)**: in scope under the trafficked-from-India rule, but No-AI-Evidence; AI apps were mentioned only for the Sri Lankan victim's camp.
6. **Pune AI-girlfriend app (991)**: typed as Sextortion + AI-Assisted Cyber Intrusion and kept in AI-Aided Fraud because of the extortion.
7. **Pseudonymous feature cases** kept (Anil S*, Shubham S*, Ravi).
8. **Sri Lankan rupees**: Y-995 Ravi amounts are not recorded (amount_lost null).

## Proposed taxonomy changes
- None to the second level.
- New `ai_capabilities` labels this batch: AI Chatbot, AI-Assisted Conversation, Deepfake Images, Manipulated Images, AI Apps (unspecified). Combined with batch 01 these would form the fixed list proposed last time.
