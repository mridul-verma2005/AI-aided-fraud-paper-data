# yellow_batch_04 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_04_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02)

## Input
- Rows: 171 (170 success; 1 no_text: row 2651, status "timeout", title "2-member gang created 126 fake websites, duped 21,985 devotees" — kept in screen.csv, not extracted). Truncated texts: none.
- Sent to extraction: 24 rows (14 AI_INVOLVED, 4 AI_SUSPECTED, 6 AI_LURE). No UNCLEAR rows.
- Not extracted: 14 NOT_AI; 132 no-hit (recall miss 2829 not labelled).

## Advisory / non-incident articles removed: 2
| Row | Reason |
|---|---|
| 2718 | ACI Worldwide FIFA World Cup ticket-fraud report (global trend) |
| 2726 | Same report (DD News) |

## Output: 27 records (6 merges into earlier events, 21 new events EV-0048 to EV-0068)
| Domain | Count |
|---|---|
| AI-Aided Fraud | 26 |
| Out of Scope | 1 (Treasure NFT, mainly Pakistan) |

| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 10 | Dilsukhnagar deepfake FM ad (2632), Kumbalam doctor deepfake FM ad (2777), PIB FM AI pitch (2731), Modi AI-voice prize ads (2762), Bihar AI fake residence certificates (2680), Bhaskar reporter AI nude-video sextortion (2681), Somnath AI fake booking sites (2850+2863+2879), Jaipur AI-altered QR codes (2903), Chhattisgarh matrimony AI photos (2995), Rent Boyfriend merged (EV-0035) |
| AI-Suspected | 6 | Borkotoky merged (EV-0001), fake ID-printing sites (2607), Saidabad "fake video" FM ad (2631), South Dinajpur morphed-photo sextortion (2873), two digital-arrest cases from 2457 |
| AI-as-Lure | 4 | AV Solutions merged (EV-0004), Naka Solutions merged (EV-0018), retired IAS merged (EV-0024), Saharanpur "AI-enabled trading platform" (2457) |
| No-AI-Evidence | 6 | 5 Paisa merged (EV-0019); split-off cases: Agra, Meerut, Kanpur, Mahoba (2457), Sultan Shahi (2631) |

## Merges across batches
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0001 Borkotoky | Y04-002 | Y-2912 | Y01-001 |
| EV-0004 AV Solutions | Y04-001 | Y-2667 | Y02-001 |
| EV-0018 Naka Solutions | Y04-003 | Y-2633 | Y02-002 |
| EV-0019 5 Paisa | Y04-004 | Y-2633 | Y02-003 |
| EV-0024 retired IAS officer | Y04-005 | Y-2636, Y-2648 (victim named: Kaza Ratna Kishore) | Y02-008 |
| EV-0035 Rent Boyfriend | Y04-006 | Y-2836 | Y02-019 |

## Splits within the batch
- Y-2457 (Delhi Police round-up) split into 7 records. Facilitator Anil (Jalandhar, mule accounts, no linked victim) not recorded separately.
- Y-2631 split into 2 records.
- Merged: Somnath racket Y-2863 + Y-2850 + Y-2879.

## Ambiguities to check
1. **Digital-arrest cases in 2457** (south Delhi Rs 42.49 lakh; Una Rs 30 lakh) are AI-Suspected only by the digital-arrest rule; no AI in the text.
2. **Saidabad "fake video" of FM Sitharaman (2631)**: kept AI-Suspected; the text never says AI, but two other FM video ads this batch are stated as AI-generated.
3. **Fact-check / alert records** (2731 PIB, 2762 NewsMeter) kept under the specific-ad rule with no victims or loss (harms empty). 2762's AI evidence comes from a detector tool.
4. **Chhattisgarh matrimony (2995)**: AI-Confirmed though the police say "stolen or AI-generated" photos.
5. **Bhaskar reporter (2681)**: attempt only (undercover reporter, no payment).
6. **Treasure NFT (2624)**: Out of Scope (Pakistan), but Indian/WB authorities are investigating; may need an in-scope record if Indian victims appear.
7. **Retired IAS officer (EV-0024)**: start date differs between reports (March vs early May 2025).

## Proposed taxonomy changes
- None to the second level.
- New ai_capabilities labels this batch: AI-Generated Content (unspecified AI content, PIB alert), AI Image Editing (QR-code alteration), Deepfake Video, Deepfake Video (suspected). Running total across batches: 17 labels; proposal to fix a list still stands.
