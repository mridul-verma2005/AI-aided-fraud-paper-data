# yellow_batch_01 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_01_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02)

## Input
- Rows: 171 (all `extraction_status == success`; 0 no_text)
- Truncated texts (32,767 chars): none
- Row 683 has status success but its text is only Moneylife subscription boilerplate (NOT screened as a hit; no content).
- Article IDs are the sheet row IDs prefixed `Y-`. Yellow batches 22–25 reuse IDs 2–685 and mostly repeat batch 01 articles (41–44 of 50 rows each share ID and URL), so later runs should reuse these event_ids.

## Rows sent to extraction
| Screen label | Rows | Count |
|---|---|---|
| AI_INVOLVED | 202, 204, 233, 256, 296, 328, 410, 414, 453, 489, 520 | 11 |
| AI_SUSPECTED | 2, 117, 191 | 3 |
| AI_LURE | 164, 295, 302, 427, 574, 657, 685 | 7 |
| **Total** | | **21** |

Not extracted: 22 NOT_AI rows; 127 no-hit rows; **row 65 (UNCLEAR) is waiting for your decision.**

## Advisory / non-incident articles removed: 5
| Row | Reason |
|---|---|
| 191 | Telangana/ISB study on fake-Aadhaar SIM fraud; no incident |
| 233 | Trend feature on AI and identity theft; no named case |
| 256 | Dutch DPA breach report (Netherlands); trend report, no AI incident |
| 410 | Seqrite/Quick Heal Bihar scam report; deepfake-relative cases are anonymous one-liners |
| 414 | Same Seqrite/Quick Heal release as 410; anonymous cases |

## Output: 17 incident records (EV-0001 to EV-0017)
| Domain | Count |
|---|---|
| AI-Aided Fraud | 15 |
| Out of Scope | 2 |

| AI bucket (AI-Aided Fraud) | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 5 | voice clone Annamayya (296), Rohit Shakya AI-built APKs (328), fake IAS officer (453), matrimonial AI images (489), Trump Hotel Rental app (520) |
| AI-Suspected | 2 | Borkotoky / CM voice (2), PrintSteal fake KYC documents (117) |
| AI-as-Lure | 5 | TRD-NFT (164), AV Solutions Ponzi (295+302), Cambodian call centre (574), Ojasvi AI (657), Nayan Saxena Telegram group (685) |
| No-AI-Evidence | 3 | Split-off cases: Shankar Rao APSPDCL (296), 8th CPC app (296), CyHawk 4.0 mule crackdown (489) |

Out of Scope:
- Y-427 — Kathmandu, Nepal: fake survey-link / "Nepse AI" app ring (Banking & Payment Fraud).
- Y-202 + Y-204 — Nithin Kamath X account, "fully AI-automated" phishing (AI-Assisted Cyber Intrusion, Account Takeover).

Locations outside India: Kathmandu, Nepal (Y-427). Y-574 kept in scope (Kerala victim and accused; call centre in Cambodia).

## Merges and splits
- Merged: Y-295 + Y-302 (same Cyberabad AV Solutions Ponzi; Rs 850.59 cr collected vs Rs 232 cr retained — amount_lost uses Rs 232 cr).
- Merged: Y-202 + Y-204 (same Kamath phishing event).
- Split: Y-296 into 3 records (AI voice clone; APSPDCL link fraud; 8th CPC app). Generic "digital arrest" and temple-room mentions in that article have no specific case and were not extracted.
- Split: Y-489 into 2 records (matrimonial AI-image fraud; overall CyHawk 4.0 mule crackdown).

## Ambiguities to check
1. **Y-202/204 Kamath** — put in Out of Scope under the Cyber Intrusion rule; AI evidence is only the victim's impression. Could instead be AI-Aided Fraud / Account Takeover.
2. **Y-328 Rohit Shakya** — AI-built malware is a Cyber Intrusion type ("usually Out of Scope"), but kept in AI-Aided Fraud because it caused Rs 64.38 cr of direct losses to Indian victims.
3. **Y-117 PrintSteal** — AI-Suspected only via the fake-ID rule; the text says templates, not AI. amount_lost is the network's profit (Rs 40 lakh), not victim loss.
4. **Y-2 Borkotoky** — Authority Impersonation chosen for posing as speaking for the Assam CM; Individual Impersonation also fits.
5. **Y-453 fake IAS** — Romance Fraud not added (no loss stated for the four women); amount_lost uses the one stated loss (Rs 5 cr+).
6. **Y-489 matrimonial case** — a single sentence; no victim, loss or harm stated (harms left empty).
7. **No-AI-Evidence records** (3) were created only because they share an article with an AI case, to follow the split rule. Say if you would rather not record non-AI split cases.
8. **Recall misses not extracted**: rows 409 (digital-arrest pattern), 416 (relative-voice impersonation), 535 (fabricated Aadhaar) are AI-Suspected by pattern but had no keyword hit, so they were not labelled or extracted.

## Proposed taxonomy changes
- None to the second level.
- `ai_capabilities` has no fixed list yet. Labels used this batch: AI-Automated Phishing, AI-Generated Code / Malware, AI-Generated Documents, AI-Generated Images, AI-Generated Video, Synthetic Identity Documents (suspected), Voice Cloning, Voice Cloning (suspected). Proposal: adopt these as a fixed list.
- Screening: add "digital arrest", "impersonat*", "posing as … officer/police/agency" and "fake/forged/fabricated Aadhaar/PAN/ID" to the keyword list to catch AI-Suspected patterns (35 of 127 no-hit rows would match and need reading).
