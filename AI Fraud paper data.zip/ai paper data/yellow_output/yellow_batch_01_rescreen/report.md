# yellow_batch_01_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_01_article_text.xlsx` (re-screen)
Screening: `screen.csv` (column `new_in_rescreen` marks rows that hit only under the added terms), `recall_check.csv` (original batch 01 sample rows still no-hit)
Keywords added for the re-screen (approved): `digital arrest`, `fake ID` (fake/forged/forging/fabricat*/counterfeit*/morphed/bogus + Aadhaar/PAN/identity/ID), `voice impersonation`; `sextort*` and `blackmail*` also apply for the first time to this batch.
The original `output_json/yellow_batch_01/` is unchanged.

## Input
- Rows: 171 (same as batch 01). Hits: 61 (was 46); 17 new.
- New hits sent to extraction: 7 AI_SUSPECTED (73, 165, 173, 409, 470, 535, 680). No UNCLEAR rows.
- New hits not extracted: 10 NOT_AI (11, 22, 134, 162, 177, 180, 184, 192, 294, 436 — digital arrest only in lists, statistics or advisories).
- Recall: 28 of the original 30 sample rows still no-hit; 1 remaining suspected miss (416, voice impersonation in loose wording).

## Advisory / non-incident articles removed: 0

## Output: 6 records (6 new events EV-0184 to EV-0189), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y01R-001 (EV-0184) | digital arrest / fake ID | Gurugram police arrest 27 for Rs 157 cr frauds (73) |
| Y01R-002 (EV-0185) | digital arrest | Ramgarh elderly man lost Rs 10 lakh to fake enforcement officers; Bihar SIM supplier held (409) |
| Y01R-003 (EV-0186) | digital arrest | Bareilly firm account rented to fraudsters; IVRI scientist lost Rs 1.1 cr (680) |
| Y01R-004 (EV-0187) | fake ID | Delhi vehicle-loan syndicate with forged Aadhaar/PAN and fake identities (470) |
| Y01R-005 (EV-0188) | fake ID | Kailash Bishnoi fake GST firms via fabricated Aadhaar; Rs 39 cr ITC (535) |
| Y01R-006 (EV-0189) | fake ID | IndusInd Nippon Life employees' Rs 58 lakh policy fraud with forged Aadhaar/PAN (165 + 173) |

## Merges
- None (no earlier record of these events).

## Ambiguities to check
1. **Fake-ID rule scope**: Y01R-004/005/006 are document-forgery cases (two by insiders); recorded AI-Suspected under the CLAUDE.md "fake IDs" rule. Say "revise" if you want such cases treated as NOT_AI.
2. **Y01R-001** is an aggregate police operation (27 arrests, 611 cases).

## Proposed taxonomy changes
- None. "Synthetic Identity Documents (suspected)" reused for the fake-ID cases.
