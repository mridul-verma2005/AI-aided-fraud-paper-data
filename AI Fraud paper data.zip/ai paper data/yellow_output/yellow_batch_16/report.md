# yellow_batch_16 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_16_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 159 (158 success; 1 no_text: row 11535, status "timeout", "Indian Police Arrest Seven in Cyber Fraud Sweep" — kept in screen.csv). Truncated texts: none.
- Sent to extraction: 3 rows (1 AI_INVOLVED, 2 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 1 NOT_AI; 154 no-hit (recall sample: 3 of 30 digital-arrest pattern; not extracted because the term is not on the keyword list).

## Advisory / non-incident articles removed: 0

## Output: 4 records (3 merges, 1 new event EV-0172), all AI-Aided Fraud
| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 1 | Hyderabad July cyber patrol removed 128 deepfake ad profiles (11332, new) |
| AI-Suspected | 2 | Anand Kumar 500-women romance/blackmail merged (EV-0143); Nuh sextortion arrest merged (EV-0092) |
| No-AI-Evidence | 1 | Nuh fake debit SMS merged (EV-0093) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0143 Anand Kumar | Y16-001 | Y-11287 (age 35; fake profile "Vaibhav Arora") | Y09-013 |
| EV-0092 Nuh sextortion arrest | Y16-002 | Y-11599 | Y05-026 |
| EV-0093 Nuh fake debit SMS | Y16-003 | Y-11599 | Y05-027 |

## Ambiguities to check
1. **Deepfake ad profiles (11332)**: kept under the specific-ad rule; recorded as a separate event from June's EV-0160 (different month and count).

## Proposed taxonomy changes
- None.
