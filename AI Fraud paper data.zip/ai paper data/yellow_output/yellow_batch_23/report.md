# yellow_batch_23 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_23_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 50. 44 are identical to yellow_batch_01 rows (same row_id, URL and text); 6 new rows (212, 279, 292, 373, 402, 411) failed fetch (http_404 / http_403 / extraction_failed) and are kept as no_text.
- Stage 2: 17 hits carry batch 01 labels; 1 new hit (192, `blackmail`) labelled NOT_AI.
- Eligible for extraction: 11 rows (8 AI_INVOLVED, 2 AI_LURE, 1 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 7 NOT_AI; 26 no-hit (recall: 2 digital-arrest pattern, rows 187 and 409; not on the keyword list); 6 no_text.

## Advisory / non-incident articles removed: 5 (same decision as batch 01)
| Row | Reason |
|---|---|
| 191 | Telangana/ISB study on fake-Aadhaar SIM fraud; no incident |
| 233 | Trend piece on AI/GenAI in identity theft and phishing; no case |
| 256 | Dutch DPA report on AI phishing kits (Netherlands); trend report |
| 410 | Seqrite report on Bihar scams incl. deepfake relatives; trend report |
| 414 | Quick Heal/Seqrite release, same source as 410; trend report |

## Output: 0 records (no merges, no new events)
| Row | Already recorded as |
|---|---|
| 202, 204 | EV-0009 (Nithin Kamath X-account phishing) |
| 295, 302 | EV-0004 (AV Solutions AI-prediction Ponzi) |
| 296 | EV-0010, EV-0011, EV-0012 |
| 328 | EV-0013 |

- `incidents.json` is an empty list. Event registry unchanged at 183 events.

## Ambiguities to check
- None new.

## Proposed taxonomy changes
- None.
