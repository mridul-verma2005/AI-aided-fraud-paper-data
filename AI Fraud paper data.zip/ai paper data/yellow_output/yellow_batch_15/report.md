# yellow_batch_15 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_15_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 167 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 6 rows (1 AI_INVOLVED, 5 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 1 NOT_AI; 160 no-hit (recall sample found 6 of 30 matching digital-arrest/fake-ID patterns; not extracted because those terms are not on the keyword list).

## Advisory / non-incident articles removed: 0

## Output: 5 records (2 merges, 3 new events EV-0169 to EV-0171), all AI-Aided Fraud
| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 1 | Hyderabad 280 deepfake ad profiles merged (EV-0160) |
| AI-Suspected | 3 | "Operation Octopus 3.0" ghost-SIM network (11165); Kanpur fake-CBI child-porn extortion gang, Rs 2 cr (11208); Rs 750 cr Chinese loan-app racket (11247+11264+11273) |
| No-AI-Evidence | 1 | Hyderabad Rs 1.22 cr trading fraud merged (EV-0161) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0160 deepfake ad profiles | Y15-001 | Y-11127 | Y11-002 |
| EV-0161 Rs 1.22 cr trading fraud | Y15-002 | Y-11127 | Y11-003 |
| New: Rs 750 cr loan-app racket | Y15-005 | Y-11273 + Y-11247 + Y-11264 | — |

## Links to check
- EV-0169 (ghost SIMs via biometric duplication) with EV-0155 (Raipur POS agents, same method). No-hit row Y-11134 is a copy of EV-0169.
- EV-0171 (Chinese loan apps) with EV-0133, EV-0162, EV-0164 (other loan-app morphed-image extortion).
- EV-0170 (Kanpur) with an April 2026 Kanpur SIM case mentioned in the article (not recorded).

## Ambiguities to check
1. All three new AI-Suspected records rest on the sextortion/digital-arrest rules; no AI stated.
2. Rs 750 cr (EV-0171) and Rs 101.87 cr (EV-0169) are transaction/linked-case totals, not stated victim losses; EV-0171 amount_lost left null.

## Proposed taxonomy changes
- None.
