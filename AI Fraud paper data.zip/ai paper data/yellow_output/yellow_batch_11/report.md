# yellow_batch_11 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_11_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 172 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 2 rows (1 AI_INVOLVED, 1 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 4 NOT_AI; 166 no-hit.

## Advisory / non-incident articles removed: 0

## Output: 3 records (3 new events EV-0159 to EV-0161; no merges), all AI-Aided Fraud
| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 1 | Hyderabad cyber patrol removed 280 fake profiles running deepfake celebrity ads (9252) |
| AI-Suspected | 1 | TMC MP Kalyan Banerjee's dormant SBI account reactivated with forged KYC and morphed photo, Rs 56 lakh (9180) |
| No-AI-Evidence | 1 | Hyderabad Rs 1.22 cr WhatsApp trading/IPO fraud, split from 9252 |

## Ambiguities to check
1. **Kalyan Banerjee (9180)**: AI-Suspected only under the fake-ID rule; morphed photo not stated as AI.
2. **Deepfake ad profiles (9252)**: kept under the specific-ad rule; no victims or loss stated; "Others" used for illegal betting.

## Screening note (not applied)
- Recall sample found 4 of 30 no-hit rows matching AI-Suspected patterns (2 digital arrest, 2 fake ID). Across all 166 no-hit rows, "digital arrest" appears in 22 and fake/forged Aadhaar/ID/KYC in 19. Not extracted because those terms are not on the keyword list.

## Proposed taxonomy changes
- None. No new ai_capabilities labels.
