# yellow_batch_08 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_08_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02; GujaratSamachar "Summarized by AI" header stripped before the keyword search; `sextort*` included)

## Input
- Rows: 171 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 8 rows (5 AI_INVOLVED, 3 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 13 NOT_AI; 150 no-hit.

## Advisory / non-incident articles removed: 2
| Row | Reason |
|---|---|
| 5465 | Feature on Nuh teen "startup" scammers using ChatGPT; anonymous, no specific case |
| 5763 | Quick Heal / Seqrite loan-app blackmail advisory |

## Output: 4 records (4 new events EV-0130 to EV-0133; no merges with earlier batches)
| Domain | Count |
|---|---|
| AI-Aided Fraud | 3 |
| Out of Scope | 1 (Transparent Tribe AI/LLM-built spyware, 6034+6158) |

| Bucket | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 1 | RPSC portal tampered with AI chatbots to delete rival candidates (5570) |
| AI-Suspected | 2 | Gowliguda video-call sextortion (5621); Kapashera fake loan-app morphed-image extortion (5711+5712) |

Merged within the batch: Y-6034 + Y-6158; Y-5711 + Y-5712.

## Links to check
- EV-0133 (fake loan-app syndicate) was busted under Delhi Police Operation CyHawk 4.0; link to the CyHawk crackdown record EV-0016.

## Ambiguities to check
1. **RPSC tampering (5570)**: AI-assisted intrusion, "usually Out of Scope", kept in AI-Aided Fraud because it manipulated a recruitment exam against named Indian candidates; typed Exam Malpractice + Document & Credential Forgery (fake SSO ID) + AI-Assisted Cyber Intrusion. No money involved.
2. **Loan-app extortion (5711+5712)**: morphed-image threats treated as Sextortion (AI-Suspected); morphing not stated as AI.
3. **Transparent Tribe (6034+6158)**: espionage, no harm category fits; harms left empty.

## Proposed taxonomy changes
- None. No new ai_capabilities labels.
