# yellow_batch_09_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_09_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 09 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_09/` is unchanged.

## Input
- Rows: 178. Hits: 39; 9 new.
- New hits sent to extraction: 5 AI_SUSPECTED (6878, 7075, 7386, 7478, 7510). No UNCLEAR rows.
- New hits not extracted: 4 NOT_AI (6511, 7022, 7395, 7605).
- Recall: 28 of 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 5 records (5 new events EV-0213 to EV-0217), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y09R-001 (EV-0213) | digital arrest | Greater Kailash Taneja couple, Rs 14.85 cr; 3 mule handlers held (6878) |
| Y09R-002 (EV-0214) | fake ID | Himmat Singh Lodha pharma fraud under fake identity, Rs 98 lakh (7075) |
| Y09R-003 (EV-0215) | digital arrest | Gujarat CCoE live sting; Assam account holder; Rs 1,000+ cr network (7386) |
| Y09R-004 (EV-0216) | digital arrest | CBI arrests three; retired public servant lost Rs 2.07 cr (7478) |
| Y09R-005 (EV-0217) | digital arrest | Mumbai designer Rs 33.5 lakh; Tripura WhatsApp-cloning gang (7510) |

## Merges
- None.

## Ambiguities to check
1. **Y09R-003**: attempt_only=true for the complainant (loss averted); other victims of the same account did lose money.
2. **Y09R-002** is an offline 2012-13 business fraud, kept only under the fake-ID rule.
3. **6511** (forged IDs for infiltrators) labelled NOT_AI as an immigration case.

## Proposed taxonomy changes
- None.
