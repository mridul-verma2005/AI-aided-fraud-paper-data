# yellow_batch_24 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_24_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 50. 41 are identical to yellow_batch_01 rows (same row_id, URL and text); 9 new rows (437, 441, 442, 472, 487, 501, 507, 510, 526) failed fetch (http_403 / http_404 / extraction_failed / review_short) and are kept as no_text.
- Stage 2: all 7 hits carry batch 01 labels; no new hits.
- Eligible for extraction: 4 rows (3 AI_INVOLVED, 1 AI_LURE). No UNCLEAR rows.
- Not extracted: 3 NOT_AI; 34 no-hit (recall sample 30: 3 suspected-AI pattern, rows 535, 416, 470; not on the keyword list); 9 no_text.

## Advisory / non-incident articles removed: 0

## Output: 0 records (no merges, no new events)
| Row | Already recorded as |
|---|---|
| 427 | EV-0005 (Kathmandu "Nepse AI" app; Out of Scope) |
| 453 | EV-0014 (fake IAS officer, AI-generated clippings) |
| 489 | EV-0015, EV-0016 (Delhi Police CyHawk 4.0) |
| 520 | EV-0017 ("Trump Hotel Rental" app) |

- `incidents.json` is an empty list. Event registry unchanged at 183 events.

## Ambiguities to check
- None new.

## Proposed taxonomy changes
- None.
