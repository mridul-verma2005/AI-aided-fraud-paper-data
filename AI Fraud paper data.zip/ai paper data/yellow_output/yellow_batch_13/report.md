# yellow_batch_13 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_13_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 152 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 2 rows (1 AI_SUSPECTED, 1 AI_LURE). No UNCLEAR rows.
- Not extracted: 7 NOT_AI; 143 no-hit.

## Advisory / non-incident articles removed: 0

## Output: 2 records, both merges into earlier events (no new events; registry stays at 167)
| Event | New record | Added rows | Earlier record now pointing to it | Bucket |
|---|---|---|---|---|
| EV-0048 Saharanpur "AI-enabled trading platform" (Rs 29.74 lakh) | Y13-001 | Y-10411 | Y05-002 | AI-as-Lure |
| EV-0100 Kerala MLA K Shantakumari digital-arrest attempt | Y13-002 | Y-10502 (no-hit copy Y-10501 noted) | Y06-007 | AI-Suspected |

## Ambiguities to check
- None new.

## Proposed taxonomy changes
- None.
