# yellow_batch_12_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_12_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 12 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_12/` is unchanged.

## Input
- Rows: 162. Hits: 26; 20 new.
- New hits sent to extraction: 15 AI_SUSPECTED. No UNCLEAR rows.
- New hits not extracted: 5 NOT_AI (10000, 10013, 10098, 10106, 10155).
- Recall: 25 of 30 original sample rows still no-hit; no suspected misses.

## Advisory / non-incident articles removed: 0

## Output: 12 records (2 merges, 10 new events EV-0234 to EV-0243), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y12R-001 (EV-0200) | merge | ED Goa digital-arrest network, 5 held, Rs 27,850 cr transactions (10171, 10166, 10170, 10165) |
| Y12R-002 (EV-0191) | merge | Goa villa cyber-fraud centre, 12 held (10175) |
| Y12R-003 (EV-0234) | digital arrest | TDP MLA Putta Sudhakar Yadav, Rs 1.07 cr (9790) |
| Y12R-004 (EV-0235) | digital arrest | Mohali crypto-alert call centre, ~Rs 50 cr (9873) |
| Y12R-005 (EV-0236) | digital arrest | Raipur call centres duping US citizens; 42 held (10009) |
| Y12R-006 (EV-0237) | digital arrest | Dantewada syndicate, Rs 10 cr; NMDC employee Rs 28 lakh (10015) |
| Y12R-007 (EV-0238) | digital arrest | Motihari gang, money to Pakistan (10027) |
| Y12R-008 (EV-0239) | digital arrest | Karwar MDMA-courier case; Patna mule-account holder, 29 cases (10052) |
| Y12R-009 (EV-0240) | digital arrest | Bhubaneswar Rs 1.38 cr; accused with fake identity (10126) |
| Y12R-010 (EV-0241) | digital arrest | South Goa woman saved by bank manager (10187) |
| Y12R-011 (EV-0242) | fake ID | East Singhbhum PDS grain racket (9491, 2018) |
| Y12R-012 (EV-0243) | fake ID | Shoriful Islam Rs 1 cr loan fraud (9932) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0200 Goa digital-arrest ED probe | Y12R-001 | Y-10171, Y-10166, Y-10170, Y-10165 | Y05R-001 |
| EV-0191 Goa villa centre | Y12R-002 | Y-10175 | Y02R-002 |

## Ambiguities to check
1. **Y12R-005**: India-run operation with US victims; kept in scope.
2. **Y12R-003 / 009 / 010** record one case each from multi-case articles.
3. **Y12R-006** amount_lost is the syndicate total (Rs 10 cr).

## Proposed taxonomy changes
- None.
