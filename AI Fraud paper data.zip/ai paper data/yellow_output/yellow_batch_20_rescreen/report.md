# yellow_batch_20_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_20_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 20 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_20/` is unchanged.

## Input
- Rows: 190. Hits: 2; 1 new (16060, NOT_AI — fake trading group; digital arrest only in "Also read" links).
- Sent to extraction: 0.
- Recall: all 30 original sample rows still no-hit; 1 remaining suspected miss (16243, fake ATS/NIA video calls without the phrase "digital arrest").

## Output: 0 records (no merges, no new events)
- `incidents.json` is an empty list. Event registry unchanged at 289 events.

## Proposed taxonomy changes
- None.
