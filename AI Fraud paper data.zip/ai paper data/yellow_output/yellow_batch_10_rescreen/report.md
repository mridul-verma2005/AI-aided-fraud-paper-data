# yellow_batch_10_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_10_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 10 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_10/` is unchanged.

## Input
- Rows: 167 (1 no_text). Hits: 39; 12 new.
- New hits sent to extraction: 8 AI_SUSPECTED (7729, 8091, 8139, 8163, 8183, 8786, 8843, 8866). No UNCLEAR rows.
- New hits not extracted: 4 NOT_AI (7737, 8816, 8821, 8840).
- Recall: 28 of 30 original sample rows still no-hit; 1 remaining suspected miss (8208, Muzaffarpur fake-police video calls without the phrase "digital arrest").

## Advisory / non-incident articles removed: 0

## Output: 7 records (7 new events EV-0218 to EV-0224), all AI-Aided Fraud / AI-Suspected
| Record | Incident |
|---|---|
| Y10R-001 (EV-0218) | Mumbai businessman's Rs 58 cr digital arrest; 9 arrested (8183 + 7729) |
| Y10R-002 (EV-0219) | Pune NCL scientist, Rs 78 lakh, fake "IPS Navjot Simi" (8091) |
| Y10R-003 (EV-0220) | Gandhinagar retired geologist, Rs 40 lakh, fake Supreme Court hearing (8139) |
| Y10R-004 (EV-0221) | Hauz Khas woman, 82, Rs 1.6 cr; 3 held (8163) |
| Y10R-005 (EV-0222) | ED raids in Rs 260 cr fake law-enforcement / tech-support fraud (8786) |
| Y10R-006 (EV-0223) | Dhubri SIM sellers using forged KYC (8843) |
| Y10R-007 (EV-0224) | CBI Operation Chakra-V, 5 POS agents arrested (8866) |

## Merges
- None.

## Ambiguities to check
1. **Y10R-006/007** are SIM-supply cases without a specific victim.
2. **Y10R-002**: a real IPS officer was impersonated; no deepfake or voice cloning is stated.
3. **Y10R-005** includes foreign victims; kept as an India-based operation.

## Proposed taxonomy changes
- None.
