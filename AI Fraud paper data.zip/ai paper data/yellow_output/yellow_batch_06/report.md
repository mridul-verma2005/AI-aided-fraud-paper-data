# yellow_batch_06 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_06_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved 2026-11-02; keyword list includes `sextort*`)

## Input
- Rows: 171 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 32 rows (18 AI_INVOLVED, 5 AI_SUSPECTED, 9 AI_LURE).
- Not extracted: 14 NOT_AI; 124 no-hit (recall miss 3982 not labelled); **UNCLEAR row 4078 (Rs 8.5 cr Instagram "reveal") waiting for your decision.**

## Advisory / non-incident articles removed: 5
| Row | Reason |
|---|---|
| 3969 | Police warning on fake "viral MMS" links (cites Payal Gaming deepfake, recorded separately via 4430) |
| 4010 | Australian PEXA research on AI property scams |
| 4503 | SEBI Boss Scam advisory |
| 4537 | US diaspora advisory (scammers posing as Indian diplomats; USA) |
| 4547 | Hyderabad romance-scam advisory |

## Output: 34 records (5 merges, 29 new events EV-0099 to EV-0127)
| Domain | Count |
|---|---|
| AI-Aided Fraud | 26 |
| Unverified Claims | 3 (Sule/Patole AI-audio claim 3979; Samra AI-video FIR 4006; Youth Congress AI voter-ID claim 4441) |
| AI Misinformation | 2 (Payal Gaming deepfake 4430; delivery rider's AI police videos 4066) |
| AI Harassment & Abuse | 1 (merged EV-0074) |
| Out of Scope | 2 ("Brad Pitt" France 4049+4520; Alina Amir Pakistan 4239) |

| Bucket (AI-Aided Fraud) | Count | Incidents |
|---|---|---|
| AI-Confirmed-in-text | 5 | Love-guru sextortion merged (EV-0075), PIB Modi deepfake ad (3921), AI reels fake-notes robbery (3978), Rath Yatra AI-video puja ads (4000), CM Naidu deepfake video call (4467) |
| AI-Suspected | 6 | Borkotoky merged (EV-0001); Kerala MLA digital arrest (3948); fake Ayushman cards (4700); Tikal SIM box (4726); Malkajgiri and LB Nagar digital arrests (4843, 4855) |
| AI-as-Lure | 9 | AV Solutions merged (EV-0004), Ojasvi AI merged (EV-0007), FM-speech "AI trading" (4736), **Quantum AI campaign (4750)**, Ahmedabad OCI (4771), "Global AI Smart Trading Competition" (4819), Malkajgiri AI ads (4843), "AI quantification account" (4844), Kukatpally AI trading (4855) |
| No-AI-Evidence | 6 | Split-off cases: Samra 5K crypto/visa (4006); four Malkajgiri cases (4843); Ramachandrapuram (4855) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0001 Borkotoky | Y06-001 | Y-4879 | Y04-002 |
| EV-0004 AV Solutions | Y06-002 | Y-4854 (new complainant B Gowri Shankar) | Y04-001 |
| EV-0007 Ojasvi AI | Y06-003 | Y-4728 (now 8,500 investors) | Y01-007 |
| EV-0074 yoga-guru deepfakes | Y06-004 | Y-4145 | Y05-008 |
| EV-0075 love-guru sextortion | Y06-005 | Y-4033 (third accused Ravi Bhargav absconding) | Y05-009 |
| New: Brad Pitt France | Y06-013 | Y-4049 + Y-4520 | — |

Splits: Y-4006 (2), Y-4843 (6), Y-4855 (3; unrelated Borabanda/Patancheru deaths on the same page not recorded).

## Ambiguities to check
1. **Quantum AI campaign (EV-0115)**: opened from 4750 as the campaign event named in CLAUDE.md. The ad used the FM's photograph, not a stated deepfake, so the bucket is AI-as-Lure; future Quantum AI deepfake reports may justify AI-Confirmed for the campaign.
2. **Payal Gaming (4430)**: intimate deepfake of an influencer placed under AI Misinformation (public figure rule). If influencers are not "public figures", it becomes AI Harassment & Abuse.
3. **Delivery rider (4066)**: AI Misinformation (Fabricated Event / Hoax) rather than Public Panic, since panic was only possible.
4. **Unverified Claims (3)**: Samra's AI video (4006) has no described content; Sule/Patole (3979) and Youth Congress (4441) are political allegations.
5. **Fake-notes reels (3978)**: typed Others/Others (bait-and-robbery, no counterfeiting).
6. **Kerala MLA (3948)**: AI only suspected by her son; attempt only.
7. **Ojasvi (EV-0007)**: accused count differs (10 FIR accused vs 7 trustees).

## Proposed taxonomy changes
- Possible new fraud type under Others: "Bait-and-robbery" (online lure leading to physical robbery), from 3978.
- New ai_capabilities labels: AI-Generated Images (suspected), AI-Generated Documents (suspected). Running total: 21.
