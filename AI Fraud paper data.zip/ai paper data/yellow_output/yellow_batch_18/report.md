# yellow_batch_18 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_18_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 171 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 2 rows (1 AI_INVOLVED, 1 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 1 NOT_AI; 168 no-hit.

## Advisory / non-incident articles removed: 0

## Output: 2 records (1 merge, 1 new event EV-0175), both AI-Aided Fraud
| Bucket | Incident |
|---|---|
| AI-Confirmed-in-text | Lucknow "solver gang" used Remini AI, ChatGPT, Fotor etc. to morph impostors onto IBPS Clerk 2025 admit cards; 10 held (14577, new EV-0175) |
| AI-Confirmed-in-text | "Pooja Kinnar GuruMa" love-guru sextortion racket merged into EV-0075 (15271; complainant lost Rs 1,43,951) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0075 love-guru sextortion | Y18-001 | Y-15271 | Y06-005 |

## Ambiguities to check
1. **IBPS solver gang (14577)**: typed Exam Proxy Fraud + Document & Credential Forgery + Exam Malpractice; candidates were paying clients, so no victim loss recorded. Similar to EV-0082 (MP constable exam photo swap, no AI).

## Proposed taxonomy changes
- None. No new ai_capabilities labels (AI Image Editing reused).
