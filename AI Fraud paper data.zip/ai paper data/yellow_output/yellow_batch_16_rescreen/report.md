# yellow_batch_16_rescreen — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_16_article_text.xlsx` (re-screen)
Screening: `screen.csv` (`new_in_rescreen` marks new hits), `recall_check.csv` (original batch 16 sample rows still no-hit)
Added terms: `digital arrest`, `fake ID`, `voice impersonation`. The original `output_json/yellow_batch_16/` is unchanged.

## Input
- Rows: 159 (1 no_text). Hits: 25; 21 new.
- New hits sent to extraction: 10 AI_SUSPECTED. No UNCLEAR rows.
- New hits not extracted: 11 NOT_AI (Operation Octopus copies, Gujarat mule crackdowns, Pawan Ruia laundering case, fake US-facing call centres with personas).
- Recall: 27 of 30 original sample rows still no-hit; 1 remaining suspected miss (11540, Mapusa man paid Rs 2.8 lakh to a fake official; no "digital arrest" phrase).

## Advisory / non-incident articles removed: 0

## Output: 7 records (3 merges, 4 new events EV-0266 to EV-0269), all AI-Aided Fraud / AI-Suspected
| Record | Rule | Incident |
|---|---|---|
| Y16R-001 (EV-0215) | merge | Rafiqul Alam Rs 1,071.5 cr China-linked network (11571, 11394, 11391, 11420) |
| Y16R-002 (EV-0238) | merge | Motihari gang (11388) |
| Y16R-003 (EV-0208) | merge | Gujarat fake-firm mule racket (11559) |
| Y16R-004 (EV-0266) | digital arrest | Delhi woman Rs 7.22 lakh; 3 WB account suppliers held (11280) |
| Y16R-005 (EV-0267) | digital arrest | Jalpaiguri businessman Rs 15 lakh, Pahalgam claim (11311) |
| Y16R-006 (EV-0268) | digital arrest | Kollam mule supplier to Dubai-led gang (11759) |
| Y16R-007 (EV-0269) | fake ID | Muzaffarnagar villagers' accounts, fake Aadhaar (11339) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0215 Gujarat sting / Rafiqul Alam | Y16R-001 | Y-11571, Y-11394, Y-11391, Y-11420 | Y09R-003 |
| EV-0238 Motihari gang | Y16R-002 | Y-11388 | Y12R-007 |
| EV-0208 Gujarat fake-firm racket | Y16R-003 | Y-11559 | Y13R-002 |

## Ambiguities to check
1. **Y16R-006/007** have no specific victim or amount.

## Proposed taxonomy changes
- None.
