# Yellow combined dataset — report

Built from existing outputs only (no re-extraction): `output_json/event_registry.json`, `yellow_batch_01`–`25` and `yellow_batch_01_rescreen`–`25_rescreen`.
Files: `yellow_incidents.json` (one record per event, green schema and field order), `yellow_taxonomy.json` (single taxonomy used in every batch).

## Totals
- Events (= records): **291**
- Source articles referenced: 384 (some articles feed more than one event; see below)
- Records taken from a re-screen folder: 111; from a base batch folder: 180

## Counts per incident_domain
| incident_domain | events |
|---|---|
| AI-Aided Fraud | 267 |
| Out of Scope | 15 |
| AI Misinformation | 4 |
| Unverified Claims | 4 |
| AI Harassment & Abuse | 1 |

## Counts per ai_bucket (AI-Aided Fraud only; other domains have no bucket)
| ai_bucket | events |
|---|---|
| AI-Suspected | 166 |
| AI-Confirmed-in-text | 40 |
| No-AI-Evidence | 36 |
| AI-as-Lure | 25 |
| (null — non-fraud domains) | 24 |

## Merges made
33 events combine more than one batch record (11 of them via a re-screen record). The latest record is used; earlier records' source_article_ids and source_urls are folded in.

| event_id | record used | from | earlier records | source articles |
|---|---|---|---|---|
| EV-0001 | Y10-002 | yellow_batch_10 | Y01-001, Y04-002, Y06-001 | Y-2, Y-2912, Y-4879, Y-8835 |
| EV-0003 | Y10-001 | yellow_batch_10 | Y01-003, Y09-003 | Y-164, Y-7721, Y-7756 |
| EV-0004 | Y06-002 | yellow_batch_06 | Y01-004, Y02-001, Y04-001 | Y-295, Y-302, Y-736, Y-1274, Y-2667, Y-4854 |
| EV-0007 | Y06-003 | yellow_batch_06 | Y01-007 | Y-657, Y-4728 |
| EV-0014 | Y03-006 | yellow_batch_03 | Y01-014 | Y-453, Y-2076 |
| EV-0018 | Y04-003 | yellow_batch_04 | Y02-002 | Y-748, Y-2633 |
| EV-0019 | Y04-004 | yellow_batch_04 | Y02-003 | Y-748, Y-2633 |
| EV-0024 | Y09-002 | yellow_batch_09 | Y02-008, Y04-005 | Y-856, Y-1249, Y-1266, Y-2636, Y-2648, Y-7717 |
| EV-0027 | Y05-001 | yellow_batch_05 | Y02-011 | Y-831, Y-3055, Y-3105 |
| EV-0035 | Y10-003 | yellow_batch_10 | Y02-019, Y04-006, Y09-001 | Y-1014, Y-1019, Y-2836, Y-7107, Y-8303 |
| EV-0048 | Y13-001 | yellow_batch_13 | Y04-007, Y05-002 | Y-2457, Y-3203, Y-10411 |
| EV-0074 | Y06-004 | yellow_batch_06 | Y05-008 | Y-3115, Y-4145 |
| EV-0075 | Y06R-001 | yellow_batch_06_rescreen | Y04R-001, Y05-009, Y06-005, Y18-001 | Y-3124, Y-4033, Y-15271, Y-2829, Y-4036 |
| EV-0092 | Y16-002 | yellow_batch_16 | Y05-026 | Y-3713, Y-11599 |
| EV-0093 | Y16-003 | yellow_batch_16 | Y05-027 | Y-3713, Y-11599 |
| EV-0100 | Y13-002 | yellow_batch_13 | Y06-007 | Y-3948, Y-10502 |
| EV-0114 | Y07-001 | yellow_batch_07 | Y06-021 | Y-4736, Y-4900 |
| EV-0125 | Y10-004 | yellow_batch_10 | Y06-032 | Y-4855, Y-7829 |
| EV-0126 | Y10-005 | yellow_batch_10 | Y06-033 | Y-4855, Y-7829 |
| EV-0127 | Y10-006 | yellow_batch_10 | Y06-034 | Y-4855, Y-7829 |
| EV-0143 | Y04R-002 | yellow_batch_04_rescreen | Y09-013, Y16-001, Y19-001 | Y-7016, Y-11287, Y-15443, Y-2619 |
| EV-0144 | Y21-001 | yellow_batch_21 | Y09-014 | Y-7295, Y-16815 |
| EV-0159 | Y11R-001 | yellow_batch_11_rescreen | Y11-001 | Y-9180, Y-8999 |
| EV-0160 | Y15-001 | yellow_batch_15 | Y11-002 | Y-9252, Y-11127 |
| EV-0161 | Y15-002 | yellow_batch_15 | Y11-003 | Y-9252, Y-11127 |
| EV-0191 | Y13R-001 | yellow_batch_13_rescreen | Y02R-002, Y12R-002 | Y-1123, Y-10175, Y-10229 |
| EV-0200 | Y12R-001 | yellow_batch_12_rescreen | Y05R-001 | Y-3064, Y-10171, Y-10166, Y-10170, Y-10165 |
| EV-0202 | Y11R-002 | yellow_batch_11_rescreen | Y05R-003 | Y-3378, Y-9176 |
| EV-0208 | Y16R-003 | yellow_batch_16_rescreen | Y07R-001, Y13R-002 | Y-4935, Y-10340, Y-11559 |
| EV-0215 | Y17R-001 | yellow_batch_17_rescreen | Y09R-003, Y16R-001 | Y-7386, Y-11571, Y-11394, Y-11391, Y-11420, Y-13010, Y-13011 |
| EV-0222 | Y15R-001 | yellow_batch_15_rescreen | Y10R-005 | Y-8786, Y-11269 |
| EV-0227 | Y17R-002 | yellow_batch_17_rescreen | Y11R-005, Y14R-001 | Y-9066, Y-10797, Y-10799, Y-10803, Y-11871 |
| EV-0238 | Y16R-002 | yellow_batch_16_rescreen | Y12R-007 | Y-10027, Y-11388 |

## Events dropped as duplicates
- No event in the registry was dropped; all 291 events have exactly one record.
- Not added again (articles already recorded in an earlier event, as decided in the batch 22–25 reports):
  - Batch 22: rows 2 (EV-0001), 117 (EV-0002), 164 (EV-0003)
  - Batch 23: rows 202, 204 (EV-0009), 295, 302 (EV-0004), 296 (EV-0010/11/12), 328 (EV-0013); 191, 233, 256, 410, 414 removed as advisories, as in batch 01
  - Batch 24: rows 427 (EV-0005), 453 (EV-0014), 489 (EV-0015/16), 520 (EV-0017)
  - Batch 25: rows 574 (EV-0006), 657 (EV-0007), 685 (EV-0008)
  - Re-screens 22–25: rows 73 (EV-0184), 165, 173 (EV-0189), 409 (EV-0185), 470 (EV-0187), 535 (EV-0188), 680 (EV-0186)
- Within batches, duplicate articles of the same case were already merged into one event at extraction time (e.g. EV-0215 has 7 articles, EV-0227 has 5).

### One article feeding several events (intentional splits, not duplicates)
| source article | events |
|---|---|
| Y-296 | EV-0010, EV-0011, EV-0012 |
| Y-2076 | EV-0014, EV-0043, EV-0044, EV-0045, EV-0046 |
| Y-489 | EV-0015, EV-0016 |
| Y-748 | EV-0018, EV-0019 |
| Y-2633 | EV-0018, EV-0019 |
| Y-1198 | EV-0022, EV-0023 |
| Y-1255 | EV-0025, EV-0026 |
| Y-905 | EV-0028, EV-0029, EV-0030 |
| Y-991 | EV-0031, EV-0032 |
| Y-995 | EV-0033, EV-0034 |
| Y-8303 | EV-0035, EV-0145 |
| Y-1935 | EV-0039, EV-0040, EV-0041 |
| Y-2457 | EV-0048, EV-0049, EV-0050, EV-0051, EV-0052, EV-0053, EV-0054 |
| Y-2631 | EV-0057, EV-0058 |
| Y-3110 | EV-0071, EV-0072 |
| Y-3718 | EV-0084, EV-0085, EV-0086, EV-0087 |
| Y-3713 | EV-0092, EV-0093 |
| Y-11599 | EV-0092, EV-0093 |
| Y-3714 | EV-0094, EV-0095 |
| Y-4006 | EV-0104, EV-0105 |
| Y-4843 | EV-0118, EV-0119, EV-0120, EV-0121, EV-0122, EV-0123 |
| Y-4855 | EV-0125, EV-0126, EV-0127 |
| Y-7829 | EV-0125, EV-0126, EV-0127 |
| Y-8880 | EV-0153, EV-0154, EV-0155 |
| Y-9252 | EV-0160, EV-0161 |
| Y-11127 | EV-0160, EV-0161 |
| Y-9815 | EV-0162, EV-0163 |
| Y-10007 | EV-0164, EV-0165, EV-0166 |
| Y-16479 | EV-0179, EV-0180 |
| Y-10503 | EV-0250, EV-0251 |
| Y-16653 | EV-0290, EV-0291 |

## Conflicts between base and re-screen records
Only two events have both a base-batch record and a later re-screen record with different values; in both the re-screen record is used:
- **EV-0075**: Y05-009 (yellow_batch_05) vs Y06R-001 (yellow_batch_06_rescreen) — accused_count: 2 → 3
- **EV-0159**: Y11-001 (yellow_batch_11) vs Y11R-001 (yellow_batch_11_rescreen) — amount_lost: 5600000 → 5639000
  - EV-0075: the re-screen articles name two more absconding associates (Vikas and Ravi Bhargava).
  - EV-0159: Y-8999 gives the exact loss (Rs 56.39 lakh) where the base article said "over Rs 56 lakh".
- EV-0075 keeps ai_bucket AI-Confirmed-in-text from the base record (officials described "AI-edited imagery"); re-screen articles that alone would be AI-Suspected did not lower it.

## Pending items (not included as incidents)
### UNCLEAR rows awaiting your decision
- **65** (yellow_batch_01): Trend piece on AI deepfake KYC bypass, but the one concrete Ahmedabad Aadhaar/DigiLocker case is not stated to have used AI.
- **1003** (yellow_batch_02): Matrimonial pig-butchering piece says fraudsters use 'stolen or AI-generated photos' in general, but the Raj case itself does not state AI.
- **1071** (yellow_batch_02): Chef Sumit Kumar lost Rs 38 lakh to impersonators of 360 ONE WAM; experts mention AI deepfake videos, but his case is not stated to use AI.
- **1548** (yellow_batch_02): Cyberbullying feature: Priya Lalwani's photos were morphed into nudes on fake profiles; AI only mentioned generally, not for her case.
- **1504** (yellow_batch_02 re-screen): FIR against ex-MLA Rega Kantha Rao: woman alleges he used her private photos to blackmail her and took Rs 4 lakh; intimate-image blackmail within a personal relationship, not an online sextortion scam; no AI.
- **3870** (yellow_batch_05): Bhagwant Mann video row: two arrested for allegedly forging a forensic report calling the video AI-generated; AI is the disputed claim, not a stated tool.
- **4078** (yellow_batch_06): Masked Instagram account allegedly collected Rs 8.5 cr for a paid 'reveal' that was an AI-generated motivational video; unclear if fraud, amount unverified.
- **4995** (yellow_batch_07): Actor Upendra and Priyanka Rao's phones hijacked via a courier-call dial code; Priyanka separately says she saw someone dub her voice using AI; link to the hack unclear.
- **5542** (yellow_batch_08 re-screen): Bhopal sisters arrested for a job-offer sex racket: victims drugged, raped and blackmailed with compromising photos; offline intimate-image blackmail, not an online sextortion scam (same question as 1504); no AI.
- **6887** (yellow_batch_09): Same Upendra/Priyanka phone-hijack case as batch 07 UNCLEAR row 4995; Priyanka's AI voice-dub remark may be unrelated to the hack.
- **8214** (yellow_batch_10): Daijiworld copy of the Upendra/Priyanka phone-hijack case; Priyanka warns of AI voice scams; same as UNCLEAR rows 4995/6887.
  - Row 65 also appears in batch 22 (same article) and is not included.

### Batch 20 digital-arrest articles missed by the keyword list (need a re-screen; not extracted)
- **16243** — Ex-IPS officer's wife duped of Rs 2.58 crore in online scam in Hyderabad - India Today — "derabad’s Humayun Nagar fell victim to a sophisticated digital fraud in which he was cheated of Rs 26 lakh by criminals impersonating officials from the Anti-Terrorist Squad (ATS), the National Investigation Agency (NIA), and even the Director General of Polic"
- Found by searching batch 20 no-hit rows for officer-impersonation wording plus video-call / warrant / money-laundering context. The article never uses the phrase "digital arrest", so the added keyword does not catch it.
- The same gap exists in other batches (e.g. 187, 8208, 10222, 11540, 16774, 16826, 16827, 16832); not part of this pending list.

## Notes
- Field order matches the green per-batch incidents.json files (30 fields, incident_domain … review_note). No green_incidents.json was found on disk; the green batch files in `fraud-dataset-claude_for_green.zip` were used as the format reference.
- 24 non-fraud records (Out of Scope, AI Misinformation, Unverified Claims, AI Harassment & Abuse) have ai_bucket and scam_categories null, as in the batch outputs.
