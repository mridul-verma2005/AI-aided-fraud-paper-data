# yellow_batch_21 — extraction report

Source: `input_excel/yellow_highlighted_url_extracted_batch_21_article_text.xlsx`
Screening: `screen.csv`, `recall_check.csv` (approved; keywords include `sextort*` and `blackmail*`; GujaratSamachar header stripped)

## Input
- Rows: 114 (all success; 0 no_text). Truncated texts: none.
- Sent to extraction: 12 rows (7 AI_INVOLVED, 5 AI_SUSPECTED). No UNCLEAR rows.
- Not extracted: 4 NOT_AI; 98 no-hit (recall sample: 4 of 30 digital-arrest pattern, rows 16827, 16832, 16826, 16774; not extracted because the term is not on the keyword list).

## Advisory / non-incident articles removed: 7
| Row | Reason |
|---|---|
| 16907 | APG report on Southeast Asian scam hubs; AI chatbots/deepfakes/voice cloning in general; no specific AI case |
| 16909 | Santander warning on AI voice notes in "Hi mum" scams (UK); advisory |
| 16960 | Singapore minister's speech on AI as a scam threat; no case |
| 16982 | NBC poll of US adults on AI/deepfake scams; survey |
| 16992 | Bitdefender guide on AI scams for families; advisory |
| 16994 | Visa report on AI-driven fraud; no case |
| 17131 | Explainer on AI Gmail phishing and digital-arrest scams; advisory |

## Output: 6 records from 5 rows (1 merge, 5 new events EV-0179 to EV-0183), all AI-Aided Fraud
| Bucket | Incident |
|---|---|
| AI-Suspected | Khammam DGM lost Rs 33.5 lakh via Instagram stock ad with fake video of FM Sitharaman (16479, EV-0179) |
| No-AI-Evidence | Khammam businessman lost Rs 2.05 crore in fake crypto/forex platform (16479 second case, EV-0180) |
| AI-Suspected | Noida digital-arrest case (Rs 52.5 lakh); six Rajasthan mule-account suppliers arrested (16791, EV-0181) |
| AI-Suspected | Kokapet techie sextorted of Rs 2.51 lakh after dating-app nude video call (16816, EV-0182) |
| AI-Suspected | Maharashtra man lost Rs 2.01 lakh via malware image; scammers mimicked his voice to the bank (16925, EV-0183) |
| AI-Suspected | Manikonda dating-app sextortion merged into EV-0144 (16815) |

## Merges
| Event | New record | Added rows | Earlier record now pointing to it |
|---|---|---|---|
| EV-0144 Manikonda sextortion | Y21-001 | Y-16815 (call date July 1, BNS 308) | Y09-014 |

## Ambiguities to check
1. **16479** holds two cases; split as in Y04-016 (batch 04). The "fake video" of the FM is not stated to be AI.
2. **16925** "mimicked his voice" is not stated to be AI; kept AI-Suspected under the voice-impersonation rule. Source is a cybersecurity blog; incident_reported left null.
3. **16791** dates from July 2024; the six arrested are mule-account suppliers, not the callers.

## Proposed taxonomy changes
- None. No new ai_capabilities labels (Deepfake Video (suspected), Voice Cloning (suspected) reused).
